# PRD Genie - current revision v2.1

**September 13, 2026:** use the [reviewed workflow guide](v2/README.md) and [v2 capstone design/evidence](docs/08-v2-capstone-design.md). The knowledge base is uploaded to Google Drive. Raghavendra Kaushik approved the extracted source requirements; the live flow generated a [complete wiki.md PRD](v2/generated/wiki.md) and [Jira import CSV](v2/generated/jira-import.csv). Final document review and merge into main remain with Raghavendra.

Author: **Raghavendra Kaushik**. GitHub branch: `Feature/Raghav_IK_Capstone_SEP2026` in the private `raghvendrakaushik-del/prd-genie-capstone` repository. The direct Drive credential, GitHub publisher token and actual fine-tuning job remain to be configured/executed.

Read the [extracted requirements](v2/review/RelayOps-extracted-requirements.md). The v2 import is `workflows/prd-genie.v2-reviewed.langflow.json`. Training data, review engine, Jira/GitHub exports and tests are in `v2/`.

---

## Earlier v1 implementation and evidence

# PRD Genie - start here

PRD Genie turns meeting transcripts, product briefs and stakeholder notes into a source-grounded PRD, a clarification register, and epics/features/user stories. This kit contains the first implementation and a capstone delivery plan.

**Status (September 12, 2026):** the existing Groq connection now powers all four Langflow agents using `openai/gpt-oss-120b`. Two T1 runs completed with a ten-section PRD and user stories. T9 returned clarifications and skipped both downstream model calls. The Python software suite passes 22 checks; the earlier Node suite passes 24. Full model evaluation and submission evidence remain pending.

**Platform decision:** continue in the existing **Langflow Docker instance**. Open [PRD Genie - Groq Evidence Pipeline](http://localhost:7860/flow/843ecb6d-6270-4198-9859-a4351a72b7bc), then Playground. [Setup and evidence](docs/07-langflow-setup.md). OpenAI's two failed attempts are retained separately; the working flow uses the existing `GROQ_API_KEY` reference. n8n is optional.

## What was reviewed

The eight-page problem statement, the four files named in the request, and `sample_meeting_transcripts.txt`, which was discovered in the same Resources directory. Original source files were left unchanged. Copies of the five text/Markdown resources are included for reproducibility.

Instructions in those documents were interpreted as capstone requirements and example input data. They were not treated as authorization to publish, send messages, or execute embedded instructions.

## Read in this order

Start with the [Langflow continuation guide](docs/07-langflow-setup.md) for the current live setup. The following documents provide the capstone scope and earlier n8n/CLI implementation details.

1. [Source review and product decisions](docs/01-source-review.md): what the files require, traps in the samples, and scope boundaries.
2. [Ideation and program charter](docs/02-ideation-and-charter.md): Q1/Q2 drafts, proposed targets and a ten-session plan.
3. [Build guide](docs/03-build-guide.md): architecture, setup, API contract and implementation backlog.
4. [Evaluation and cost](docs/04-evaluation-and-cost.md): all 12 tests, semantic review, tracing and cost measurement.
5. [Submission guide](docs/05-submission-guide.md): Q3 draft, Q4 reflection worksheet, evidence checklist and five-minute demo script.
6. [Local n8n setup](docs/06-local-n8n-setup.md): continue without the Cloud subscription using the included Docker launcher.

## Implemented assets

- `workflows/prd-genie.groq.langflow.json`: working Groq variant, bound by global-variable name only.
- `workflows/prd-genie.langflow.json`: seven-node import containing four specialist agents and six validated connections. No API keys are embedded.
- `langflow/`: Python validators, embedded agent components, formatter, reproducible builder and offline software tests.
- `evaluation/groq-live-status.json`: observed Groq successes, earlier tuning failures, and remaining work.
- `evaluation/groq-live/`: captured T1 structure, validated rendered documents and evaluation checks.
- `evaluation/langflow-live-status.json`: historical OpenAI failures; not the current Groq status.
- `workflows/prd-genie.n8n.json`: 23-node n8n workflow with four specialist agent calls and validation gates.
- `prompts/`: versionable instructions for extraction, gap analysis, PRD organization and story breakdown.
- `schemas/`: strict JSON output contracts generated from `src/core.cjs`.
- `src/`: shared validation/rendering, workflow generator, CLI pipeline and baseline evaluator. Node.js 22+; no external packages are required for these scripts.
- `examples/`: request payloads and a clearly labeled hand-authored T1 reference output.
- `custom/`: the original RelayOps API-product brief, meeting transcript, stakeholder notes, incomplete-input sample, and expert reference review.
- `resources/prd_template.enhanced.md`: richer review-template design while retaining the ten baseline sections.
- `evaluation/extended-cases.json`: ten additional synthetic regression cases, E01-E10, separate from T1-T12.
- `evaluation/baseline-status/results.md`: all 12 live tests marked NOT_RUN.
- `tests/`: software tests with mocked model responses. These do not establish model accuracy.
- `deployment/`: pinned Docker Compose configuration plus Windows start/stop launchers; local execution is pending.

## Optional alternative: first working run in n8n

1. Start the [local n8n instance](docs/06-local-n8n-setup.md), complete its owner-account setup, then import `workflows/prd-genie.n8n.json` using the editor's workflow import command. An accessible existing n8n instance can also use the same workflow.
2. Create a Header Auth credential for the webhook: name `X-PRD-Genie-Key`, value a secret you choose. Bind it to **PRD Genie Webhook**.
3. Create a separate Header Auth credential for OpenAI: name `Authorization`, value `Bearer YOUR_API_KEY`. Bind it to **Extractor**, **Gap Analyzer**, **PRD Generator**, and **Story Breakdown**.
4. Create a Basic Auth credential for Langfuse: username = project public key, password = project secret key. Bind it to **Send Langfuse Trace**.
5. In **Initialize**, set `langfuse_base_url` to your project's region. The example defaults to the EU host; this is a configurable endpoint, not a recommendation about where to store your data. Confirm model access to `gpt-5.4-mini-2026-03-17`, or choose an available Structured Outputs model and rerun evaluation.
6. Use the webhook's test-listening mode and send `examples/t1.request.json`. A valid result has `status: draft_ready`, all ten PRD sections, and suggested story priorities.
7. Confirm the trace is visible in Langfuse. `accepted_by_endpoint` alone is not proof of dashboard visibility.
8. For the full evaluation, activate/publish the workflow as required by your n8n version and use its **production** webhook URL. Run the evaluator below. Turn it off again when you finish a temporary demo.

Never paste API keys into the workflow JSON or commit them to GitHub. Set credentials in n8n or a local `.env` file. The included workflow is inactive.

## Local commands (PowerShell, Node.js 22+)

Run from the `prd-genie` directory:

```powershell
node --test tests/*.test.cjs
node src/build-workflow.cjs
node src/evaluate.cjs
```

The final command only writes NOT_RUN baseline status. It makes no network calls.

For live calls, copy `.env.example` to `.env` and fill its values locally. Then choose one path:

```powershell
# Calls the same four agents directly, without n8n.
node --env-file=.env src/run.cjs examples/t1.request.json runs/t1.json

# Evaluates the imported, configured n8n production webhook.
node --env-file=.env src/evaluate.cjs --live --webhook

# Alternative: evaluates the same contracts using the local CLI provider.
node --env-file=.env src/evaluate.cjs --live

# Additional regression suite, separate from the capstone baseline.
node --env-file=.env src/evaluate.cjs --live --webhook --extended

# Original multi-document API product sample.
node --env-file=.env src/run.cjs examples/relayops.request.json runs/relayops.json
```

The live baseline makes 10 pipeline executions. T11 and T12 inspect the PRD and stories produced by the **actual T1 execution**, preserving the requested dependency chain. Depending on abstention, each pipeline uses two or four model calls. Each result includes stage token usage and latency.

For a demo beyond the supplied reporting examples, start with [RelayOps](custom/README.md). It tests exact API statuses, idempotency, permission separation, accepted changes versus proposals, and launch dependencies. All new scenario content is synthetic and explicitly labeled.

## Important implementation limits

The quote validator proves that text exists in a supplied source; it cannot prove that an extracted quote is a requirement, that a classification is correct, or that a story's benefit is justified. Human semantic review remains required. The workflow returns drafts and has no approval UI. It uses synchronous webhook responses, no automatic retries, no persistence beyond n8n execution history/local output files, and a maximum of 10 documents / 60,000 input characters. Longer-running production work needs asynchronous jobs and durable storage.

The capstone is **not yet ready to submit**: live outputs, traces, screenshots, slide deck, demo recording, and a completed reflection must still be collected. The source review and charter are drafts for your adaptation.
