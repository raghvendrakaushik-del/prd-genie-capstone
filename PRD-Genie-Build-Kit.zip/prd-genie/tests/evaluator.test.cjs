const test=require('node:test');const assert=require('node:assert/strict');const c=require('../src/core.cjs');const f=require('./fixtures.cjs');const {dataset,checkCase}=require('../src/evaluate.cjs');
const result=()=>({status:'draft_ready',extraction:structuredClone(f.extraction),gaps:structuredClone(f.gaps),prd:structuredClone(f.prd),stories:structuredClone(f.stories),prd_markdown:c.renderPrd(f.extraction,f.gaps,f.prd),stories_markdown:c.renderStories(f.stories,f.extraction)});
test('baseline preserves exactly 12 cases and explicit T11/T12 dependencies',()=>{
  const cases=dataset();assert.equal(cases.length,12);assert.deepEqual(cases.map(c=>c.id),Array.from({length:12},(_,i)=>'T'+(i+1)));
  assert.equal(cases[10].depends_on,'T1');assert.equal(cases[11].depends_on,'T11');
});
test('baseline checker accepts the authored T1 contract, template and story artifacts',()=>{
  for(const id of ['T1','T11','T12'])assert.ok(checkCase(id,result()).every(c=>c.pass),id);
});
test('baseline checker detects fabricated evidence even if expected keywords remain',()=>{
  const r=result();r.extraction.requirements[0].text+=' and export PDF';
  assert.ok(checkCase('T1',r).some(c=>!c.pass));
});
test('baseline checker rejects a missing PRD section and changed threshold',()=>{
  const r=result();r.prd_markdown=r.prd_markdown.replace('## 7. Dependencies','## Removed');assert.ok(checkCase('T11',r).some(c=>!c.pass));
  const altered=result();altered.extraction.requirements[1].text='Results must load in under 3 seconds.';assert.ok(checkCase('T1',altered).some(c=>!c.pass));
});
test('extended whitespace case requires abstention and a relevant clarification',()=>{
  const {checkExtendedCase}=require('../src/evaluate.cjs');const item=require('../evaluation/extended-cases.json').cases.find(t=>t.id==='E03');
  const r={status:'empty',extraction:{status:'empty',requirements:[],facts:[],issues:[]},gaps:{questions:[{id:'G-001',question:'Please provide substantive notes.',rationale:'No requirements available.',suggested_owner:'Unassigned',severity:'blocking',evidence_ids:[],resolution_status:'open'}]},prd:null,stories:null,prd_markdown:null};
  assert.ok(checkExtendedCase(item,r).every(c=>c.pass));r.prd_markdown='# Invented product';assert.ok(checkExtendedCase(item,r).some(c=>!c.pass));
});
test('extended corpus contains ten distinct cases and all source payloads validate',()=>{
  const cases=require('../evaluation/extended-cases.json').cases;assert.equal(cases.length,10);assert.equal(new Set(cases.map(t=>t.id)).size,10);
  for(const item of cases)c.validateInput({documents:item.documents});
});
