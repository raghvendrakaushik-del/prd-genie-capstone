const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const c=require('../src/core.cjs');const f=require('./fixtures.cjs');const {runPipeline}=require('../src/run.cjs');
const clone=v=>structuredClone(v);
test('extracts exact quotes and preserves original targets',()=>assert.equal(c.validateExtraction(clone(f.extraction),f.input.documents).requirements[1].text,'Results must load in under 2 seconds.'));
test('rejects invented requirement text even with a valid supporting quote',()=>{const e=clone(f.extraction);e.requirements[0].text+=' Export XLSX.';assert.throws(()=>c.validateExtraction(e,f.input.documents),/preserve/);});
test('rejects fabricated quotes, duplicate IDs and nonexistent sources',()=>{
  for(const mutate of [e=>e.requirements[0].quote='Invented',e=>e.requirements[1].id='R-001',e=>e.facts[0].source_id='missing']) {
    const e=clone(f.extraction);mutate(e);assert.throws(()=>c.validateExtraction(e,f.input.documents));
  }
});
test('rejects requirements hidden under an insufficient status',()=>{const e=clone(f.extraction);e.status='insufficient';assert.throws(()=>c.validateExtraction(e,f.input.documents));});
test('rejects a gap report that silently drops a known issue',()=>assert.throws(()=>c.validateGaps({questions:[]},f.extraction),/dropped/));
test('PRD mapping must retain NFRs, criteria, deadlines and questions',()=>{
  for(const key of ['nfr_ids','criteria_requirement_ids','deadline_ids','question_ids']){const p=clone(f.prd);p[key]=[];assert.throws(()=>c.validatePrd(p,f.extraction,f.gaps));}
});
test('all ten template sections appear with unknowns left explicit',()=>{
  const markdown=c.renderPrd(f.extraction,f.gaps,f.prd);
  const titles=fs.readFileSync(path.join(__dirname,'../resources/prd_template.md'),'utf8').match(/^## \d+\. .+$/gm);
  for(const title of titles)assert.ok(markdown.includes(title),title);
  assert.ok(markdown.includes('Deadline: Q3.'));assert.ok(!markdown.includes('2026'));assert.ok(!markdown.includes('FR-002 |'));
});
test('story output preserves criteria and cannot supply additional criteria',()=>{
  const markdown=c.renderStories(f.stories,f.extraction);assert.ok(markdown.includes('Results must load in under 2 seconds.'));
  const s=clone(f.stories);s.epics[0].features[0].stories[0].acceptance_criteria=['Invented'];assert.throws(()=>c.validateStories(s,f.extraction),/unexpected/);
});
test('rejects orphaned requirements and unsupported persona/priority claims',()=>{
  for(const mutate of [s=>s.epics[0].features[0].stories[0].requirement_ids=['R-001'],s=>s.epics[0].features[0].stories[0].persona='Admin',s=>{const story=s.epics[0].features[0].stories[0];story.priority='Nice to Have';story.priority_basis='stated';}]) {
    const s=clone(f.stories);mutate(s);assert.throws(()=>c.validateStories(s,f.extraction));
  }
});
test('rejects malformed JSON, refused and incomplete model responses',()=>{
  for(const r of [{status:'incomplete',output:[]},{status:'completed',output:[{content:[{type:'refusal'}]}]},f.response({wrong:true}),{status:'completed',output:[{content:[{type:'output_text',text:'not json'}]}]}])assert.throws(()=>c.parseResponse(r,c.schemas.extractor));
});
test('reads message content after non-message Responses API output items',()=>assert.deepEqual(c.parseResponse(f.response(f.extraction),c.schemas.extractor),f.extraction));
test('rejects oversized inputs and duplicate document identifiers',()=>{
  assert.throws(()=>c.validateInput({documents:[{id:'x',name:'x',text:'x'.repeat(60001)}]}));
  assert.throws(()=>c.validateInput({documents:[...f.input.documents,...f.input.documents]}));
});
test('four-agent sequence passes the actual prior output into each stage',async()=>{
  const calls=[];const results=[f.extraction,f.gaps,f.prd,f.stories];
  const result=await runPipeline(f.input,{trace:false,provider:async body=>{calls.push(body);return f.response(clone(results[calls.length-1]));}});
  assert.equal(result.status,'draft_ready');assert.equal(calls.length,4);
  assert.deepEqual(JSON.parse(calls[2].input).source_data.extraction,f.extraction);
  assert.deepEqual(JSON.parse(calls[3].input).source_data.prd,f.prd);
});
test('empty notes stop before PRD and stories and still produce a clarification',async()=>{
  let calls=0;const e={status:'empty',requirements:[],facts:[],issues:[]};
  const clarification={questions:[{id:'G-001',question:'Can you provide substantive meeting notes?',rationale:'No requirements are available.',suggested_owner:'Unassigned',severity:'blocking',evidence_ids:[],resolution_status:'open'}]};
  const result=await runPipeline({documents:[{id:'T9',name:'T9',text:'Meeting happened. Notes: none.'}]},{trace:false,provider:async()=>f.response(++calls===1?e:clarification)});
  assert.equal(calls,2);assert.equal(result.status,'empty');assert.equal(result.prd,null);assert.equal(result.stories,null);assert.equal(result.prd_markdown,null);
  assert.equal(result.gaps.questions.length,1);
});
test('provider failures do not fabricate a successful output',async()=>{
  const result=await runPipeline(f.input,{trace:false,provider:async()=>{throw new Error('Simulated timeout');}});
  assert.equal(result.status,'error');assert.equal(result.error.stage,'extractor');assert.equal(result.prd,null);
});
test('OTEL spans have valid IDs, ancestry and exact nanosecond strings',()=>{
  const run={run_id:'test',trace_id:'a'.repeat(32),root_span_id:'b'.repeat(16),started_at:1000,ended_at:2000,status:'draft_ready',input:{},stages:[{name:'extractor',span_id:'c'.repeat(16),started_at:1100,ended_at:1800,model:'test-model',input:{},output:{},usage:{input_tokens:12,output_tokens:8}}]};
  const spans=c.otelPayload(run).resourceSpans[0].scopeSpans[0].spans;
  assert.equal(spans[0].startTimeUnixNano,'1000000000');assert.equal(spans[1].parentSpanId,run.root_span_id);
  assert.ok(spans[1].attributes.some(a=>a.key==='langfuse.observation.usage_details'));
});
test('workflow graph references existing nodes and every Code node parses',()=>{
  const workflow=JSON.parse(fs.readFileSync(path.join(__dirname,'../workflows/prd-genie.n8n.json'),'utf8'));
  const names=new Set(workflow.nodes.map(n=>n.name));
  for(const [name,outputs] of Object.entries(workflow.connections)){assert.ok(names.has(name));for(const branch of outputs.main)for(const edge of branch)assert.ok(names.has(edge.node));}
  for(const node of workflow.nodes.filter(n=>n.type.endsWith('.code')))new vm.Script(`(function(){${node.parameters.jsCode}\n})`);
  assert.equal(workflow.active,false);assert.equal(workflow.nodes.find(n=>n.name==='PRD Genie Webhook').parameters.authentication,'headerAuth');
  assert.equal(workflow.nodes.filter(n=>['Extractor','Gap Analyzer','PRD Generator','Story Breakdown'].includes(n.name)).length,4);
});
test('actual n8n Code nodes produce a grounded response with mocked HTTP responses',()=>{
  const workflow=JSON.parse(fs.readFileSync(path.join(__dirname,'../workflows/prd-genie.n8n.json'),'utf8'));const state={};let current={body:f.input};
  function execute(name){const node=workflow.nodes.find(n=>n.name===name);const ctx={$input:{first:()=>({json:current})},$execution:{id:'unit-test'},$:(name)=>({first:()=>({json:state[name]})})};
    current=vm.runInNewContext(`(function(){${node.parameters.jsCode}\n})()`,ctx)[0].json;state[name]=structuredClone(current);}
  execute('Initialize');
  for(const [name,value] of [['Extractor',f.extraction],['Gap Analyzer',f.gaps],['PRD Generator',f.prd],['Story Breakdown',f.stories]]){
    execute('Prepare '+name);current=f.response(clone(value));execute('Capture '+name);assert.equal(current.error,null);
  }
  execute('Finalize');assert.equal(current.result.status,'draft_ready');assert.equal(current.trace.resourceSpans[0].scopeSpans[0].spans.length,5);
  current={statusCode:200,body:{}};execute('Delivery Status');assert.equal(current.tracing_status,'accepted_by_endpoint');
});
