// Hand-authored fixtures for software tests. These are NOT live model outputs.
const text='The user should be able to filter reports by date range, category, and status. Results must load in under 2 seconds. PM: Sarah. Deadline: Q3.';
const input={documents:[{id:'T1',name:'T1',text}]};
const evidence=text=>({text,quote:text,source_id:'T1'});
const extraction={status:'sufficient',requirements:[
  {id:'R-001',...evidence('The user should be able to filter reports by date range, category, and status.'),kind:'functional',category:'Reporting',persona:'user',priority:'Should Have',acceptance_criteria:[]},
  {id:'R-002',...evidence('Results must load in under 2 seconds.'),kind:'non_functional',category:'Performance',persona:null,priority:'Must Have',acceptance_criteria:[evidence('Results must load in under 2 seconds.')]}
],facts:[{id:'F-001',kind:'stakeholder',...evidence('PM: Sarah.')},{id:'F-002',kind:'deadline',...evidence('Deadline: Q3.')}],issues:[
  {id:'I-001',kind:'missing',description:'Q3 year not provided.',requirement_ids:[],source_ids:['T1'],question:'Which calendar year does Q3 refer to?'}
]};
const gaps={questions:[{id:'G-001',question:'Which calendar year does Q3 refer to?',rationale:'The source states Q3 without a year.',suggested_owner:'PM Sarah',severity:'important',evidence_ids:['I-001','F-002'],resolution_status:'open'}]};
const prd={overview_ids:['F-001'],goal_ids:[],persona_ids:[],functional_ids:['R-001'],nfr_ids:['R-002'],constraint_ids:[],criteria_requirement_ids:['R-002'],out_of_scope_ids:[],dependency_ids:[],assumption_ids:[],question_ids:['G-001'],deadline_ids:['F-002']};
const stories={epics:[{id:'EP-001',title:'Report filtering',features:[{id:'FE-001',title:'Filter report results',requirement_ids:['R-001','R-002'],stories:[
  {id:'US-001',persona:'user',persona_basis:'stated',statement:'As a user, I want to filter reports by date range, category, and status so that I can view matching reports.',priority:'Must Have',priority_basis:'suggested',requirement_ids:['R-001','R-002']}
]}]}]};
function response(value){return {status:'completed',output:[{type:'reasoning',summary:[]},{type:'message',content:[{type:'output_text',text:JSON.stringify(value)}]}],usage:{input_tokens:100,output_tokens:50}};}
module.exports={input,extraction,gaps,prd,stories,response};
