# Continue in the existing Langflow instance

The selected platform is now **Langflow at http://localhost:7860**. It is already running in Docker; renewing n8n Cloud is unnecessary for this implementation. The n8n workflow remains an alternative.

## Current flow

Open [PRD Genie - Groq Evidence Pipeline](http://localhost:7860/flow/843ecb6d-6270-4198-9859-a4351a72b7bc).

The seven-node flow contains Chat Input, four specialist agents, a formatter and Chat Output. All six connections are present. Each agent uses Groq's `openai/gpt-oss-120b` with the existing `GROQ_API_KEY` global variable. No key values are embedded in this kit. The separate OpenAI flow is retained after two provider rate-limit failures.

Live T1 completed twice: extraction, gaps, PRD and stories all validated. T9 correctly returned clarification questions and skipped the PRD/story model calls. Read [actual run status](../evaluation/groq-live-status.json) and the [saved T1 PRD](../evaluation/groq-live/T1.prd.md). These smoke tests establish a working connection and pipeline; the remaining baseline and extended cases still require live evaluation.

## Architecture

```mermaid
flowchart TD
    IN[Chat Input: text or related source documents] --> E[1. Requirement Extractor]
    E -->|Schema and exact source quotes checked| G[2. Gap Analyzer]
    G -->|Issue coverage checked| P[3. PRD Generator]
    P -->|Complete evidence mapping checked| S[4. Story Builder]
    S -->|Role and requirement coverage checked| R[5. Reviewable Output]
    R --> OUT[Chat Output]
```

The PRD and Story agents skip their model calls when extraction is ambiguous, insufficient, or empty. They pass the clarification register to the formatter. A model error, unsupported quotation, or invalid reference fails the run before subsequent stages execute.

Each agent is a separate custom Python component with its own role prompt, schema, model call, and validation boundary. Source text is data, never workflow instructions. The shared code is embedded in the import; no additional container mounts or Python installations are needed for that code. The Groq variant uses the OpenAI-compatible SDK already present in the inspected container, with the Groq endpoint, strict JSON schemas and two bounded retries. The OpenAI variant uses Langflow model integration.

## Run with the working Groq connection

1. Open the flow and select **Playground**.
2. Paste the content of [T1.request.json](../examples/T1.request.json), or paste a plain text product brief. JSON preserves the supplied source IDs; plain text receives `source-1`.
3. Send once. Expect the four stages to validate, followed by the ten-section PRD and epics/features/stories.
4. Run [T9.request.json](../examples/T9.request.json). Expect clarification questions, with the PRD and Story calls skipped.
5. Use the original [RelayOps samples](../custom/README.md) for the fuller API-product demonstration.
6. Change **5. Reviewable Output → Output format** to **JSON** to retain the structured evidence, stage usage, latency and output artifacts for evaluation. Return it to **Readable** for the demo.

Do not paste API keys into Playground or source documents. Update credentials only in Langflow's provider/global-variable settings. Changing a ChatGPT subscription does not itself establish working API quota; verify the API provider account used by the configured key.

## Import into another instance

On the project list, show the Projects sidebar and use the upload arrow next to **Projects** to choose [prd-genie.groq.langflow.json](../workflows/prd-genie.groq.langflow.json). The upload button can be hidden by the narrow layout. Create or select the `GROQ_API_KEY` global variable on every agent, and keep a Groq model that supports strict structured output. The default is `openai/gpt-oss-120b`. The separate OpenAI import remains available. This import is for the inspected Langflow 1.10 environment; validate it after importing into a different version.

## Evaluation and observability limits

The 22 Python software tests cover evidence rejection, role separation, input limits, complete requirement mapping, import handle compatibility, four mocked stage handoffs, downstream skipping, and redaction of provider error details. They use authored fixtures and do not measure model accuracy.

Successful runs report latency and any provider-reported input/output token counts. Missing usage is labeled **Not reported**, never zero. Both failed T1 runs were verified in Langflow's Traces panel; the second trace contains the flow root, Chat Input, and failed Extractor spans, with an 8.92-second root latency. The Groq run envelopes now contain validated results and usage for all four agents. Native trace 27cff274-ab99-4cea-8855-8a7360f827fd was inspected: success, 19.45 seconds, all four agents plus input/output spans present. External Langfuse integration is implemented in the n8n/CLI alternative, but is **not connected in this Langflow flow**. Complete that observability evidence before claiming the capstone is finished.

Use the existing baseline rubric in [Evaluation and cost](04-evaluation-and-cost.md). T11 and T12 must use the actual T1 extraction/PRD, not the authored fixture. The existing Node evaluator targets the Node/n8n path; it does not automatically exercise this Langflow flow. Save and review Langflow outputs separately until an authenticated API evaluation adapter is connected.

## What changed after live testing

Gap question IDs are assigned by the workflow. The PRD organizer receives the complete expected evidence map; a deterministic pass fills missing template references using only validated extraction/gap IDs. Unknown IDs are rejected, and every corrected section is logged under `template_coverage_corrections`. This does not add product facts or acceptance criteria. Exact quotation, role separation and requirement coverage checks remain enforced.

The saved T1 structure is captured from the actual Playground JSON response. Markdown files are rendered locally from that validated structure using the same renderer. They are not authored reference fixtures. The model omitted the generic word "user" as a persona; the resulting stories explicitly label "user" as a placeholder. PM semantic review is still necessary.

Groq's strict-schema compatibility was checked against its [structured-output documentation](https://console.groq.com/docs/structured-outputs) and [OpenAI-compatible API documentation](https://console.groq.com/docs/openai).
