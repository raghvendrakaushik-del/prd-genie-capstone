# Verification status

Recorded: 2026-09-13T05:27:57.638071+00:00

## Current v2.1 status

- Review-gate and export software tests: **22 passed**; see `evaluation/v2-software-tests.txt`.
- Live v2.1 extraction completed in 6.3 seconds and stopped for reviewer identity and approval. Raghavendra Kaushik then approved revision 2; the live flow generated the PRD and stories. The same deterministic renderer materialized wiki.md and the Jira CSV with the exact UI-observed approval receipt. See `evaluation/v2-generated-checks.json`.
- Eight detailed synthetic knowledge files and their manifest were uploaded to the user's Google Drive folder. The live workflow currently uses the identical embedded snapshot; server-side Drive authentication remains unconfigured.
- Private GitHub repository and branch `Feature/Raghav_IK_Capstone_SEP2026` were verified in the browser. Server-side automatic publishing still needs a repository-scoped credential and live verification.
- Fine-tuning datasets contain 48 training, 16 validation and 16 holdout examples. Training has **NOT_STARTED**; label review and a working training connection are required.
- See `evaluation/v2-live-status.json`, `v2/README.md` and `docs/08-v2-capstone-design.md` for evidence and remaining work.

## Earlier v1 verification

- Software tests: **24 passed, 0 failed**. Exact test-run output: `evaluation/software-tests.txt`.
- Langflow software tests: **22 passed, 0 failed**, including mocked component handoffs, Groq adapter, source-only template completion and skip behavior. Output: `evaluation/langflow-software-tests.txt`.
- Working Groq flow: **7 nodes / 6 connections**, four agents configured for `openai/gpt-oss-120b`, using the existing global-variable credential reference.
- Groq live T1 completed twice, including a final 19.5-second run. T9 returned clarification questions and skipped both downstream model calls.
- Captured live T1 output passes 6/6 automated T1 checks; its exact downstream artifacts pass 4/4 T11 and 4/4 T12 checks. These are not three independent model executions.
- Successful native trace `27cff274-ab99-4cea-8855-8a7360f827fd` was inspected: root success, 19.45 seconds, all four agents plus input/output spans present.
- Historical OpenAI attempts failed at the extractor with RateLimitError. Earlier Groq tuning failures are preserved in `evaluation/groq-live-status.json`.
- Generated n8n workflow: **23 nodes**, inactive, with no credential bindings or secret values included.
- All JSON artifacts parse; local Markdown links resolve.
- Five original text/Markdown resource copies match the SHA-256 digests of the supplied originals.
- Source manifest includes all six reviewed source files, including the PDF and discovered meeting transcripts.
- Node/n8n baseline: **T1-T12 NOT_RUN**. Separate Groq status: **T1 live checks passed; T9 clarification behavior observed; T11/T12 checks passed on actual T1 artifacts; T2-T8/T10 NOT_RUN**.
- Additional regression suite: **E01-E10 NOT_RUN** against a live model/workflow.
- Authored T1 and RelayOps references are explicitly labeled; they are not model-evaluation results.
- Recommended continuation: the user's existing **Langflow Docker instance**; no n8n Cloud renewal needed for this path.
- A pinned Docker Compose file and Windows launchers are prepared. Docker is installed, but this session was denied access to the Docker engine/configuration. No container was started.
- n8n remains an optional alternative. Its workflow import and local owner-account setup are not verified.
- Full semantic/model evaluation, the RelayOps live demonstration, external Langfuse connection for Langflow, screenshot/video submission evidence and remote submission are pending.

These checks establish local software and package consistency, not capstone completion or live model quality.
