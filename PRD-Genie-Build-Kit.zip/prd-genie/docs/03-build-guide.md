# Build guide

Platform update (September 12): the selected path is the user's existing [Langflow Docker instance](07-langflow-setup.md). Its four-agent flow now uses the existing Groq connection; T1 completed twice and T9 correctly requested clarification. Full evaluation remains pending. The sections below describe the earlier n8n/CLI alternative. In particular, webhook authentication and Langfuse OTEL delivery below are not yet implemented in the Langflow flow.

## Architecture and orchestration

```mermaid
flowchart TD
    A[Authenticated webhook: related text documents] --> V[Validate input size and source IDs]
    V --> E[Requirement Extractor agent]
    E --> EV[Schema and exact-quote validation]
    EV --> G[Gap Analyzer agent]
    G --> GV[Validate references and preserve known issues]
    GV --> R{Actionable requirements?}
    R -->|No| Q[Return status and clarification questions]
    R -->|Yes| P[PRD Generator agent: evidence-to-template mapping]
    P --> PV[Validate complete coverage]
    PV --> S[Story Breakdown agent]
    S --> SV[Validate IDs, persona separation and priorities]
    SV --> D[Render ten-section PRD and story Markdown]
    D --> T[Langfuse OTEL: root and stage spans]
    Q --> T
    T --> O[Return JSON: draft, questions, trace delivery status]
    F[Captured model or validation error] --> T
```

The chosen pattern is a **sequential pipeline**. Each specialist agent has a separate prompt, JSON schema, LLM call and stage observation. Gap Analysis runs after extraction so the PRD can include its clarification register. The PDF allows architectural justification; its diagram does not require optional analysis to run after stories.

For this bounded workflow, fixed stages make traceability and regression testing easier than a supervisor choosing arbitrary tools. A router, vector database and an autonomous planner would add failure modes without addressing a current requirement. Output artifacts remain drafts; review is a user action, not an implemented in-workflow approval gate.

## Tool choices

| Component | Choice | Reason / tradeoff |
|---|---|---|
| Visual orchestration | n8n standard nodes | JSON workflow artifact and inspectable canvas; import/runtime validation still needed |
| LLM interface | OpenAI Responses API with strict JSON Schema | Typed stage handoffs; refusals/incomplete responses must still be handled |
| Initial model | `gpt-5.4-mini-2026-03-17` | Versioned starting point; measure quality before choosing a more expensive fallback |
| Grounding | Exact quotes + source IDs + coverage checks | Rejects fabricated evidence but cannot judge every semantic relationship |
| Template | Included `prd_template.md` | Known fixed format; no retrieval infrastructure needed |
| Tracing | Langfuse OTLP/HTTP JSON | Compatible with n8n HTTP nodes without installing an SDK in the workflow runtime |
| Local verification | Node.js built-in test runner, no npm dependencies | Tests pure functions and the generated Code nodes using mocked responses |
| Export | Markdown + structured JSON | Portable, readable and easy to put under version control |

The API schema configuration follows the [official Structured Outputs guide](https://developers.openai.com/api/docs/guides/structured-outputs). The starting model's availability and snapshot are listed in the [model reference](https://developers.openai.com/api/docs/models/gpt-5.4-mini). The HTTP JSON-body and credential parameter choices were checked against the [n8n HTTP Request implementation](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/HttpRequest/V3/HttpRequestV3.node.ts). Actual import and execution on your n8n version remain a separate acceptance check.

## Node groups and responsibility

| Nodes | What they do |
|---|---|
| PRD Genie Webhook -> Initialize -> Valid Input? | Authenticate, normalize input, assign run/trace IDs and reject oversized/invalid requests |
| Prepare Extractor -> Extractor -> Capture Extractor | Submit strict schema request; validate exact quotes, status and provenance |
| Extraction Valid? -> Prepare Gap Analyzer -> Gap Analyzer -> Capture Gap Analyzer | Generate an actionable question register; preserve all known issues |
| Enough to Draft? | Stops PRD/stories for ambiguous, insufficient or empty extraction |
| Prepare PRD Generator -> PRD Generator -> Capture PRD Generator -> PRD Valid? | Map evidence into the template; reject missing or invented IDs |
| Prepare Story Breakdown -> Story Breakdown -> Capture Story Breakdown | Generate the epic/feature/story hierarchy; check links and persona separation |
| Finalize | Render Markdown, assemble usage and construct tracing payload |
| Send Langfuse Trace -> Delivery Status -> Return Draft | Send OTEL spans, expose trace failures, return output |

The workflow has 23 nodes including a setup note. It contains no credential IDs, secrets or live pinned output data. HTTP node errors are captured as workflow state so they are distinguishable from insufficient input. No downstream generation proceeds after an invalid stage.

## Input contract

POST JSON to the webhook URL copied from n8n:

```json
{
  "documents": [
    {
      "id": "brief_01",
      "name": "Product brief",
      "text": "The original document text, preserved verbatim."
    }
  ]
}
```

Use `Content-Type: application/json` and the `X-PRD-Genie-Key` header. This header authenticates access to PRD Genie; it is different from the OpenAI API credential. Maximum: 10 documents, 60,000 combined characters. Each ID must be unique, 1-64 letters/numbers/underscores/hyphens. The workflow accepts text, not a binary PDF or audio upload. Convert those formats before calling it if needed later.

Only combine documents that the user identifies as referring to the same product/scope. Send the five sample meetings separately. `examples/analytics-brief-and-notes.request.json` intentionally pairs the brief and stakeholder notes for a multi-document review exercise; that pairing is a test scenario, not a claim that every meeting belongs to that project.

## Output contract

```json
{
  "run_id": "execution identifier",
  "trace_id": "32 hexadecimal characters",
  "status": "draft_ready | ambiguous | insufficient | empty | error",
  "error": null,
  "extraction": {},
  "gaps": {},
  "prd": {},
  "stories": {},
  "prd_markdown": "... or null",
  "stories_markdown": "... or null",
  "review_required": true,
  "tracing_status": "accepted_by_endpoint | failed",
  "usage": []
}
```

This is an illustrative shape, not a literal JSON schema. The actual agent schemas are in `schemas/`; `prd` contains the source-ID map and `stories` the hierarchy. In non-draft paths these fields are null. The n8n application response uses HTTP 200 with an explicit business `status`; inspect that status rather than treating every 200 as success. Authentication/platform errors may return other HTTP codes. The CLI additionally reports `not_configured` when tracing credentials are absent.

## Evidence model

- `R-001`: requirement; exact text/quote, source ID, kind, category, persona, stated priority, and exact criterion quotes.
- `F-001`: source fact; product name, goal, persona, stakeholder, deadline, dependency, stated assumption, exclusion, decision, or context.
- `I-001`: interpretation issue; ambiguity, conflict, risk or missing information with source/requirement references.
- `G-001`: clarification; evidence IDs, severity, suggested owner and open resolution status.

Requirements/facts use `text === quote` and quote substring validation against the relevant source. Issues and questions are analysis rather than copied requirements. All outputs are JSON-schema validated, including missing fields and unexpected keys. PRD mapping must retain all extracted requirements, explicit criteria, facts and questions. Story text is generated and needs semantic review; its criterion text is copied during rendering and cannot be supplied or changed by the story agent.

## Setup and first acceptance run

Follow the credential binding sequence in the README. Keep the model and trace endpoint fixed in **Initialize**, rather than accepting them from the incoming document or webhook. A source document cannot redirect the model endpoint or tracing destination.

For a PowerShell smoke test after the `.env` is configured, the CLI can send the same request directly. For n8n, use an API client or the provided live evaluator against the URL copied from your workspace. n8n's test webhook may stop listening between runs, so the complete baseline should use the production URL of the activated/published workflow.

Confirm on T1: filter date/category/status, load under 2 seconds, PM Sarah, Q3 without an invented year, all ten PRD headings, epics/features/stories, criterion text retained, and a visible trace. Then run T9 and ensure PRD/story fields are null. This establishes the positive and abstention paths before running the entire suite.

For source troubleshooting, inspect **Capture** node errors. Examples include unsupported quote, incomplete model response, invalid JSON, missing NFR coverage, unknown source ID, or persona mismatch. Correct the prompt/contract and regenerate the workflow with `node src/build-workflow.cjs`, then reimport it. Hand-edits to generated Code nodes will be overwritten by rebuilding.

## Next implementation backlog

| ID | Priority | Work | Acceptance criterion |
|---|---|---|---|
| B01 | P0 | Import and bind credentials | n8n opens all 23 nodes and T1 returns a draft |
| B02 | P0 | Verify observability | Root and stage spans appear with matching trace ID; no secret keys appear |
| B03 | P0 | Run all baselines | Every T1-T12 output saved with automated and human results |
| B04 | P0 | Fix model regressions | Preserve exact numeric targets, personas and criteria; all failures explained |
| B05 | P0 | Run extended multi-document examples | Gap register surfaces conflicts without choosing unapproved scope |
| B06 | P0 | Capture submission evidence | Fresh workflow export, action/trace screenshots, video and honest reflection |
| B07 | P1 | Durable review state | PM edits are recorded; approval is an explicit action with document version |
| B08 | P1 | Async processing | POST returns job ID; polling returns state; request timeouts do not lose results |
| B09 | P1 | Retry/cost policy | Retry transient failures only with capped attempts/backoff and recorded usage |
| B10 | P1 | Holdout set and reviewer calibration | Paraphrases/unseen cases reviewed against a shared scoring guide |
| B11 | P2 | Rich document input / exports | File parsing and export preserve source anchors and document versions |

The first six are capstone completion work. The remaining items are productization candidates, not hidden MVP requirements.

## Known limits and failure behavior

Input validation rejects unsupported size/shape rather than silently truncating it. A failed, refused, malformed or incomplete model output stops subsequent generation. Model calls have a 120-second per-call timeout and no automatic retries in this MVP. Total synchronous duration may exceed a reverse proxy's webhook timeout even if individual calls finish; for that environment use the CLI during development or add B08 before deployment.

Most handled model/validation failures are sent to Langfuse. A stopped workflow process, Code-node runtime crash or failure before initialization cannot guarantee trace delivery; n8n execution history is the fallback. Trace delivery failure does not discard an otherwise valid draft, but means the observability acceptance criterion remains unmet. This is a capstone prototype, not a fully hardened multi-user service.
