# Evaluation, observability and cost

## Evaluation layers

1. **Software contract tests:** local mocked responses validate schema handling, exact quotes, reference coverage, abstention, rendering, error propagation and OTEL payload shape. Passing these tests does not mean a language model extracts requirements accurately.
2. **Live baseline checks:** run T1-T10 through the actual configured pipeline; inspect actual T1 PRD for T11 and its actual story breakdown for T12. Save every output and the stage usage/trace ID.
3. **Human semantic review:** compare each generated claim to the source. Check omissions, interpretation, criteria, priority basis, neutrality and usefulness. Automated PASS remains provisional until this review is complete.
4. **Holdout regression set:** after baseline tuning, test paraphrases, different numbers, extra personas, prompt-injection text, long notes, duplicated statements and unrelated documents. Report these separately from the supplied baseline.

The current live baseline file marks all 12 cases NOT_RUN. There is no measured hallucination rate, time saving, cost or model pass rate yet. Hand-authored examples and mocked tests must never be presented as model runs.

## Additional scenario and regression suite

The user-requested RelayOps example adds a realistic API contract and multi-document scope review. Run its three related documents via `examples/relayops.request.json` and compare the result to `custom/relayops_expected_review.md`. Run the incomplete notes separately to preserve their intended abstention test.

E01-E10 in `evaluation/extended-cases.json` cover API fidelity, embedded instruction attacks, whitespace-only input, role permissions, target-date uncertainty, cross-document conflict, missing years, an approved format revision, similar numbers with different meanings, and vague AI intent. They are authored regression cases, not a blind holdout set. Each has explicit expected evidence and human checks.

```powershell
# Prepare NOT_RUN status without external calls.
node src/evaluate.cjs --extended

# Execute the added tests against n8n after setup.
node --env-file=.env src/evaluate.cjs --live --webhook --extended
```

Results use `evaluation/extended-status/` or `evaluation/extended-live-results/`. Do not average these into the official T1-T12 pass rate without separately reporting the two suites. The enhanced template file is a review-design reference; extra approval/decision-register fields are not all populated by the MVP renderer.

## Baseline expectations and review criteria

| Test | Expected behavior | Failure to look for |
|---|---|---|
| T1 | Three report filters, under 2 seconds, Sarah as PM, Q3 deadline | Extra features, year invented, PM turned into persona |
| T2 | Ambiguous; ask metrics, format, users | Inventing specific dashboard/reporting features |
| T3 | Identify frequent-refresh/API-call tension and request resolution | Silently choosing a refresh rate or technical solution |
| T4 | Exact criteria: "PDF must include company logo." and "CSV must preserve formulas."; both reach stories | Added/changed criteria or silent switch to XLSX |
| T5 | Insufficient; ask what dashboard, real-time meaning, budget | Filling fragments with assumed requirements |
| T6 | Preserve Engineering, Design and PM viewpoints; flag tensions neutrally | Favoring one viewpoint or claiming SPA cannot coexist with microservices |
| T7 | Exact 10,000 concurrent users; response time < 200ms at p95; Salesforce REST API v52; NFR classification | Rounding thresholds, replacing the version, omitting compatibility |
| T8 | Separate Admin, End User and Auditor stories | Merging personas or adding privileges |
| T9 | Empty/no extractable requirements; no PRD | Fabricating a usable feature brief |
| T10 | SSO feature, auth-service dependency, Team Alpha, unknown ETA risk | Invented schedule or missing dependency owner |
| T11 | All ten template sections from T1 extraction only | Sample-transcript requirements leaking into baseline output |
| T12 | Epics, features, standard "As a ..." stories, priority suggestions | Orphaned stories, unlabeled assumptions or missing hierarchy |

T11/T12 are dependent checks, not two independent transcript inputs. The evaluator preserves T1's actual extraction/PRD/story artifacts and the same run ID. It does not make a new T1 generation and call that the previous output. All 12 output files are saved during a live run; dependent cases contain the same chain so the reviewer can inspect provenance.

## Running and interpreting the evaluator

```powershell
node --env-file=.env src/evaluate.cjs --live --webhook
```

Set the production URL and matching webhook secret locally. Outputs go to `evaluation/live-results/`, which is git-ignored to avoid publishing sensitive runs accidentally. Review and sanitize any results you intend to submit. Without `--live`, the evaluator writes only the NOT_RUN manifest and performs no external requests.

The result contains separate `execution`, `automated`, `human_review`, checks, tracing status and human review instructions. Any failed automatic check causes a nonzero exit code. A passing automatic score never sets `human_review` to PASSED. Record reviewer, date, observed defect, correction and final decision in a review log alongside each output.

The deterministic checks revalidate source quotes, data types, reference integrity, complete PRD mapping and story coverage. Keywords alone are not the evaluator's only checks, but human review is still needed for meaning. For example, a quoted statement may be a suggestion rather than a commitment, or an apparently reasonable user-story benefit may be unsupported.

## Quality metrics and definitions

| Metric | Definition | Interpretation |
|---|---|---|
| Requirement precision | Supported extracted requirements / all extracted requirements | Human determines semantic support; quote presence is insufficient |
| Requirement recall | Correctly captured reference requirements / reference requirements | Requires a reviewer-approved gold inventory; not inferred from keywords alone |
| Unsupported-claim rate | Unsupported factual product claims / all factual product claims | Audit PRD and stories; suggested questions are not product claims |
| Acceptance-criterion fidelity | Exact required criteria retained / required criteria | Also check that the output adds zero unsupported criteria |
| Traceability coverage | Requirements/stories with valid references / total requirements/stories | A mechanical guard, not proof of relevance |
| Conflict detection | Correctly flagged known conflicts / known conflicts | Note false positives and tradeoffs mistaken for contradictions |
| End-to-end baseline pass | Cases passing all automatic and human criteria / 12 | Report T11/T12 dependence; do not imply 12 independent samples |
| Review effort | Minutes to PM-approved draft and number/severity of edits | Compare against a manual baseline using the same task |
| Runtime and spend | Stage duration and token-cost sum, including retries | Measure live; unknown usage stays unknown |

Freeze prompt version, model snapshot, template, dataset and workflow revision for each evaluation. Avoid tuning on a test input without disclosing that it is part of the tuning set. Model-judge scores can assist triage later, but the judge must not replace a source audit for hallucination-sensitive acceptance.

## Langfuse setup and acceptance

The integration uses `POST /api/public/otel/v1/traces`, Basic Auth using the project key pair, OTLP/HTTP JSON, and the `x-langfuse-ingestion-version: 4` header. Those choices follow the [official OTEL integration](https://langfuse.com/integrations/native/opentelemetry). The default EU host is configurable; use the host associated with the project you actually create.

Do not implement a new dependency on legacy trace ingestion. Langfuse documents its retirement in the [custom ingestion migration guide](https://langfuse.com/integrations/native/opentelemetry/migration-to-v4). The workflow is designed against the supported OTEL endpoint rather than that legacy API.

One root span represents the run; each attempted agent call is a child generation span. Sufficient input normally has four generation spans, while abstaining input has two. The integration carries run/trace IDs, stage names, model, prompt version, duration, token usage when available and error status. Raw prompts and outputs are omitted from Langfuse by default (`trace_content:false` in n8n); local/n8n execution artifacts still contain source/output data.

To capture richer traces for the provided synthetic examples, deliberately enable `trace_content` in Initialize and rerun those examples. The CLI API supports the equivalent `traceContent` option for programmatic use. Do not enable it for other transcripts without deciding which content may be stored in the observability project. Redaction is a configuration choice, not automatic PII detection.

**Acceptance evidence:** a visible Langfuse root and linked stage spans, token/latency fields, matching run/trace ID, and a failure example. HTTP acceptance is reported as `accepted_by_endpoint`; inspect the UI before claiming "observability connected." Partial rejected spans or transport errors set `tracing_status: failed`. A runtime crash before the export may still only exist in n8n execution history.

Evaluation results are written locally in this MVP; numeric evaluation scores are not automatically posted to Langfuse. Join them through the recorded trace IDs. Adding remote score submission is a later improvement, not a feature already implemented.

## Cost strategy

Record the actual tokens for each attempted generation. For a model with different rates for uncached input, cached input and output:

```text
run_cost = sum_over_calls(
  uncached_input_tokens * input_rate_per_million / 1,000,000
  + cached_input_tokens * cached_rate_per_million / 1,000,000
  + output_tokens * output_rate_per_million / 1,000,000
)
```

Input rates should apply to total input minus cached input when cached tokens are reported. Output usage includes whatever billable output the provider reports, including applicable reasoning tokens; do not add those twice. Missing usage following a timeout is unknown rather than zero. Reconcile with the provider's billing data.

The [GPT-5.4 mini reference](https://developers.openai.com/api/docs/models/gpt-5.4-mini), checked 5 September 2026, lists standard per-million token prices of $0.75 input, $0.075 cached input, and $4.50 output. Verify current rates in your account before using this as a budget commitment. The example below is illustrative, not a measured PRD Genie run.

| Illustration | Assumed total across all agent calls | Estimated model cost |
|---|---|---|
| One sufficient-input run | 18,000 uncached input + 5,000 output tokens | $0.036 |
| 100 comparable runs | Same token distribution | $3.60 |
| 1,000 comparable runs | Same token distribution | $36.00 |

This excludes n8n/Langfuse hosting, taxes, storage, retries and PM review effort. The 8,000-token per-call cap is a limit, not expected usage. With up to 40 calls across the 10 independent baseline inputs, each change should be evaluated on a small smoke subset before rerunning the suite. Actual abstention reduces call count. A proposed initial model-spend cap of $10 provides room for iteration but has not been set on any account.

Cost controls: keep short inputs, use one template, avoid unnecessary retrieval/tool calls, stop invalid/empty paths early, pin prompts/model, and retry deliberately while counting added usage. Choose a stronger model only if specific measured errors justify its incremental cost. Compare quality at the same input set and prompt version.
