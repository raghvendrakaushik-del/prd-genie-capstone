# Source review and product decisions

Reviewed 5 September 2026. Source facts, project recommendations, and unresolved decisions are distinguished below.

## 1. Product definition

**Source requirement:** NeuronForge's PMs/TPMs spend too much time extracting scope from meetings, writing inconsistent PRDs and converting them into engineering work items. PRD Genie should ingest text, extract requirements, generate a consistent PRD, and break the result into epics/features/user stories. Data grounding and observability are mandatory. [Problem Statement, pp. 2-4]

**Recommended promise:** "Turn messy discussions into a reviewable, source-linked product draft, with uncertainty made explicit."

The Advanced Analytics Dashboard described in the sample files is a product that PRD Genie documents. Its PostgreSQL, mobile, tenant access and refresh requirements are test data. In particular, the sample dashboard's ban on third-party analytics tools does not prohibit using n8n or Langfuse to build PRD Genie.

## 2. File-by-file findings

| File | Purpose | Build implication |
|---|---|---|
| Problem Statement PDF, eight pages | Authoritative capstone description and evaluation expectations | Map each required capability and submission artifact to evidence. Preserve optional/required distinctions. |
| `prd_template.md` | Ten-section PRD output contract | Always render the ten headings, including Out of Scope, Dependencies and Timeline. Use "Not stated" when evidence is absent. |
| `eval_prdgenie_inputs.txt` | Ten independent inputs plus two dependent stages | T11 consumes T1 extraction; T12 consumes T11 PRD. Do not send the bracketed instructions as if they were transcripts. |
| `sample_product_brief.txt` | Coherent analytics product brief | Preserve stated scope and distinguish questions/suggestions from commitments. |
| `stakeholder_notes.txt` | Four incomplete stakeholder interviews | Track attribution, unresolved tradeoffs, dependencies and possible scope expansion. |
| `sample_meeting_transcripts.txt` | Five meetings of varying quality | Found in the provided folder although absent from the user message. Test each meeting independently unless related scope is explicitly established. |

Source files live under the supplied `PRD Genie` directory. Copies of the five resources are in `resources/`; the original PDF remains at the user's provided path. No source content was edited.

## 3. Requirements and rubric traceability

| Capstone requirement | Required? | Kit implementation / evidence still needed |
|---|---|---|
| Extract requirements, constraints, assumptions, stakeholders and deadlines | Core | Extractor prompt, schema, evidence validator; live outputs needed |
| Separate stated requirements from ambiguity | Core | Exact source quotes, explicit issue register, status gate |
| Follow PRD template | Core | PRD mapping agent plus deterministic renderer with all ten sections |
| Epics, Features and User Stories with priority | Core | Story agent; source links, priority basis, exact criterion rendering |
| Multi-agent design and documented orchestration | Mandatory concept | Four distinct prompted roles with typed handoffs in a sequential workflow |
| At least one extended capability | Required choice | Gap Analysis selected; Scope Estimation and Version Comparison deferred |
| Evaluation/observability tool connected | Mandatory | Langfuse OTEL integration implemented; credentials and visible traces still required |
| Test all T1-T12 and save outputs | Mandatory | Evaluator prepared; all live baseline results currently NOT_RUN |
| Q1 ideation | 15 points | Draft in 02-ideation-and-charter.md |
| Q2 program charter | 15 points | Draft in 02-ideation-and-charter.md |
| Q3 design + implementation + cost/evaluation | 45 points | Implementation and draft writeup; live validation outstanding |
| Q4 reflection | 5 points | Evidence worksheet prepared; cannot complete observed findings before live runs |

Q3's breakdown is 10 design + 12 core + 8 extension + 5 observability + 5 baseline testing + 5 cost/evaluation = 45. The overall printed assignments total **80 points**, not 100. The document provides no basis for inventing the remaining 20. Ask the instructor whether any additional rubric applies.

Human-in-the-loop is an optional curriculum concept, but Q3 asks the architecture discussion to address it. The MVP explicitly returns Draft/Review Required; a persisted approval workflow is a future extension. RAG and fine-tuning are optional. A single known template does not require vector retrieval.

## 4. The product brief: what must be retained

The brief names Advanced Analytics Dashboard, authored by Priya Sharma, dated March 2026, with Draft status. It targets business analysts who export to Excel, team leads needing weekly summaries, and executives needing a high-level view.

Stated requirements: five metrics (revenue, active users, churn rate, NPS score, support ticket volume); date filters for 7/30/90 days and custom ranges; refresh every 15 minutes to manage cost; executives see all data, team leads their own team's data; PDF export for monthly board reports.

Constraints: existing PostgreSQL warehouse, no third-party analytics tools due to licensing concerns, mobile responsiveness, Q3 2026 launch.

Open decisions: fixed versus custom layouts, alerting, and acceptable page-load time. "Under 3 seconds" is a suggestion within an open question, not a finalized NFR. The pricing claims about Competitor X/Y are unverified statements in the brief and do not establish PRD Genie's pricing or recommended capabilities.

## 5. Stakeholder notes: interpretation and clarification register

The owner column below proposes the person to consult; it is not an assignment approved by that stakeholder.

| Issue | Source evidence / interpretation | Proposed question | Suggested reviewer |
|---|---|---|---|
| Launch timing | Brief targets Q3 2026; Tom requests something by end of March and fears losing an account if Q3 is missed | Is March a board-demo milestone and Q3 general availability? What does "basic" contain? | Product owner + Tom |
| Performance prerequisite | Raj reports full scans taking 8+ seconds and requests timestamp indexing before new features | What query workload/data volume is representative, and must the index/query work precede the dashboard? | Raj |
| Backend ownership | Raj requests a separate analytics microservice using the existing events table | Is this an approved architectural constraint or a proposal? Who owns service/warehouse changes? | Raj + product owner |
| Frontend architecture | Lisa proposes an SPA and reports engineering's preference for server-rendered pages for SEO | What discovery, authentication and SEO requirements determine rendering? | Lisa + Raj |
| Mobile timing | Brief says mobile accessible; Lisa proposes desktop first/mobile fast follow | Is mobile in the launch acceptance criteria or a later milestone? | Product owner + Lisa |
| Account isolation | Nina says customers need their own account data; brief defines executive/team-lead visibility | Does "all data" mean within the user's customer account? What access do analysts and tenant administrators receive? | Product owner + Nina + engineering |
| Churn prediction | Tom requests prediction without specifying data or accuracy | Is prediction in this release? What decision would it support, what data is permitted, and what performance threshold is acceptable? | Product owner + Tom |
| Search and filtering | Nina prioritizes finding information; brief specifies only date filtering | What should search cover and is it needed for the first release? | Nina + Lisa |
| White-labeling | Nina reports interest but questions scope | Is customer branding required for PDF export? Which logo is used? | Product owner + Nina |
| Dark mode | Lisa describes it as nice but not critical | Confirm Nice to Have and whether it is deferred | Lisa + product owner |
| Estimates | Raj suggests 2 sprints, maybe 3 with API redesign | What is sprint length, team capacity, dependency readiness and included backend scope? | Raj |

Do not equate the 8+ second observed scan time with an acceptable user-experience target. Do not convert 2-3 sprints into dates without sprint length and a start point. Interview dates omit the year. Preserve that absence even though the brief is dated March 2026.

## 6. Meeting transcripts: separate scenarios

1. **Reporting Feature (Detailed):** Capture the three filters, under-2-second target, dedicated page matching the existing design system, Sarah's PM ownership, Raj's backend ownership, end-of-Q3 deadline, and end-of-April design request. Live querying versus warehouse is unresolved. This has more requirements than baseline T1; never contaminate T1 with this longer transcript.
2. **AI Feature (Vague):** Capture competitive motivation and the request for better reporting as ambiguous intent. Do not invent summarization, forecasting, chat, models, datasets, or success metrics. Ask what data, outputs, user decisions and reporting gaps are intended.
3. **Dashboard (Contradictory):** Preserve Priya's five-second refresh request, Kevin's API-load concern, Mike's proposed WebSockets alternative, and the unresolved disagreement. A proposed technical workaround is not a resolved architecture decision. A draft can display the unresolved alternatives; implementation approval must wait.
4. **Export Feature:** Capture the exact full-transcript PDF criterion (logo at the top of every page) and formula wording. Also capture the subsequent acceptance of XLSX and the request to retain the CSV label. Flag the actual format versus label mismatch; preserve the decision sequence. Baseline T4 does not contain the later XLSX discussion, so its criteria remain the exact shorter baseline text.
5. **General Discussion:** Mark insufficient. Follow up on dashboard scope, meaning of real-time, budget, analytics involvement, design owner and next meeting date. These fragments do not justify a full PRD.

Even if names repeat, Tom's role is VP Product in Transcript 2 and VP Sales in the interview notes. Preserve source-specific attribution; do not automatically deduplicate them into one authoritative role. The brief's 15-minute refresh and Transcript 3's five-second request are cross-document conflicts only if the user establishes that both concern the same scope/version.

## 7. Decisions recommended for PRD Genie

| Decision | Recommendation | Rationale |
|---|---|---|
| Orchestration | Sequential Extract -> Gap Analysis -> PRD -> Stories | Fixed handoffs are easy to inspect. Gap analysis happens early so unresolved items reach the PRD. |
| Platform | n8n, selected with user agreement | Fits the visual workflow/JSON-export requirement; implemented with standard Code, HTTP, If and Webhook nodes. |
| LLM | Configurable OpenAI Responses model with strict output schemas | Keeps role boundaries and typed output observable; chosen snapshot is a starting point for evaluation. |
| Grounding | Source IDs and exact quotes, followed by semantic review | Deterministic checks reject fabricated evidence; human review detects omissions and misinterpretation. |
| Extended capability | Gap Analysis | Directly addresses vague, incomplete, conflicting and dependency-heavy cases. |
| Export | JSON + Markdown | Reviewable, portable and sufficient for a capstone; publishing integrations can follow. |
| Approval | Every generated artifact remains a draft | No automatic approval, stakeholder messaging, or engineering commitment. |
| Deferred | RAG, fine-tuning, story sizing, version comparison, audio transcription, custom web UI | Focus first on evaluated core behavior and the required extension. |

## 8. Decisions still needed from the project owner

n8n remains selected. After the user reported a possibly expired Cloud trial, local Community edition became the recommended hosting path; see `06-local-n8n-setup.md`. Confirm local startup, connected LLM provider/model, tracing connection, and capstone submission date. These do not prevent local design and implementation. Do not share secret key values in chat; configure them in the credential store.

## 9. User-requested enhancements

The user asked for an original sample and improvements to the supplied examples where useful. The kit now includes the synthetic RelayOps product brief, transcript, stakeholder notes, incomplete-input variant, expert reference review, enhanced ten-section template design, and ten additional regression cases. These additions are separate from the supplied sources and official tests, which remain unchanged. This preserves comparability while providing a stronger API/TPM-oriented demo.
