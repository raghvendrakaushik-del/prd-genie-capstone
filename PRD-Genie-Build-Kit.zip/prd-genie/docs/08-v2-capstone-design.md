# PRD Genie v2.1 - capstone design and evidence

The revised implementation addresses the user's September 13 requirements: richer source knowledge, retrieval of template/prior-PRD context, review before generation, complete required fields, detailed Mermaid architecture, Given/When/Then stories and GitHub version commits.

## Q3 design writeup

The selected orchestration is a sequential pipeline with a persisted human checkpoint. Knowledge retrieval precedes the Requirement Extractor, followed by gap/completeness checks. The workflow saves the extracted source revision and returns a review packet. The PRD and Story agents cannot call their models until an explicit approval matches the current session, revision and content hash. Corrections create another revision and invalidate prior approval. This ordering prevents missing information from being converted into invented product decisions.

The knowledge base describes a fictional RelayOps webhook console. Its eight documents cover the product brief, exact API/acceptance behavior, NFRs, a messy workshop transcript, stakeholder decisions, the supplied template and an unrelated past-PRD style example. BM25 retrieves relevant context; the complete current-product catalog is pinned to avoid losing scope through top-k selection. Prior-product facts have a style-only role. The catalog supplies exact descriptions, numbers, dates, names, assumptions and criteria. User-provided corrections are separately attributed.

The PRD Agent organizes the approved inventory into the ten sections of the supplied template. A deterministic renderer preserves complete metadata, three personas and KPIs, eight functional requirements, four NFRs, API contracts, sixteen Given/When/Then scenarios, exclusions, owned dependencies, explicit assumptions, resolved questions, milestones and rollout details. A detailed Mermaid graph is assembled from source-defined nodes and edges whose requirement/decision references are validated. The model does not generate product facts or criteria from general knowledge.

The Story Agent retains source epic groupings and requirement coverage. Exported descriptions contain role/want/benefit, detailed behavior, API contract, applicable NFRs, exact source scenarios, source priority and review provenance. The Jira CSV places Epics before Stories and uses import-local IDs for parent links. No Jira issues are published; the user selected import-ready files.

Version publication is a separate stage after approved-source generation. Missing GitHub credentials trigger a request for connection configuration. With repository-scoped access, one Git tree and commit contains the PRD, Jira CSV, stories, approved source and review manifest. Branch updates use force=false, preserving concurrent changes. Version paths contain product version, review revision and source hash. The author is Raghavendra Kaushik; the reviewer is the actual person providing approval, not a fictional source persona.

## Fine-tuning and measurement

An 80-example synthetic extraction dataset is prepared: 48 training, 16 validation and 16 held-out records, separated by product-domain families. The official T1-T12 baseline is excluded from training. Training submission/status tooling and a base-versus-tuned holdout evaluator are provided. No job has been run, and no trained model or quality uplift is claimed. Groq's available connection supports inference, while actual training needs a functioning training provider; its adapter-hosting service also has separate access requirements.

The workflow retains Langflow native component traces. The earlier Groq T1 run has a verified successful four-agent trace. The new v2.1 extraction run completed in 6.3 seconds and stopped in awaiting_review with the reviewer field missing, as intended. Its source catalog hash matches the saved review packet. Twenty-two v2 software tests cover approval, grounding, completeness, diagram references, CSV relationships and commit behavior. Software tests do not establish full model quality.

## Completion matrix

| Requirement | Actual state |
|---|---|
| Source documents reviewed | Eight-page problem statement and supplied templates/input files reviewed |
| Detailed knowledge base in Google Drive | Eight source files plus manifest uploaded; nine uploads verified |
| RAG before extractor | Implemented and live-tested using the explicit embedded source snapshot; direct Drive API credential still required |
| Human review before PRD | Live gate blocked generation, accepted Raghavendra Kaushik's name and explicit source approval on revision 2, then permitted generation |
| Complete ten-section PRD | Live generation completed; wiki.md materialized with the same approved source and deterministic renderer; no blank fields or unresolved placeholders |
| Given/When/Then Jira stories | Eight stories and three epics generated after source approval; Jira import CSV prepared; no Jira issues published |
| Detailed Mermaid | Source-based architecture included in the review packet and generated-document renderer |
| Fine-tuning | Dataset and lifecycle/evaluation code prepared; actual training and model deployment not performed |
| GitHub repository and branch | Private repository created; requested Feature/Raghav_IK_Capstone_SEP2026 branch created |
| Automatic future commits | Publisher implemented/tested; server credential and live automatic-commit verification pending |
| All baseline outputs | Earlier T1/T9 and dependent T11/T12 evidence available; remaining baseline and extended cases pending |
| External observability | Native Langflow traces present; external Langfuse connection remains pending |
| Slides/video/final submission | Not yet produced or submitted |

The problem statement permits sparse T1-only PRDs in its original baseline. The user's stricter production requirement now blocks incomplete documents and asks for missing facts instead. Preserve both evaluation modes rather than filling T1 with invented facts.

## Operating limits

This version targets the inspected Langflow 1.10 instance. Its own persisted approval gate avoids assuming newer native HITL components exist. Mount the review directory to persistent storage for container replacement. Typed reviewer names and session binding are suitable for the local capstone demonstration; production requires authenticated reviewer identities and access policies. Google browser sign-in, Google Drive server access and GitHub server access are separate credentials.

Use [the v2 setup guide](../v2/README.md) for the current implementation. Earlier n8n/CLI writeups describe a previous architecture and are retained as history, not current completion evidence.
