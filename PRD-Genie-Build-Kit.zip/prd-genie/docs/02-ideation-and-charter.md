# Ideation and program charter

Draft for Q1 and Q2. Pain points come from the problem statement; objectives, owners and timing below are proposals, not observed results or approved commitments.

## Q1. Ideation

| Pain point | Current manual step | Agent solution | Inputs -> outputs | Main risk and mitigation |
|---|---|---|---|---|
| Requirements disappear in long notes | PM rereads meetings and copies requests | Requirement Extractor | Transcripts/briefs/notes -> quoted requirements, facts and source IDs | Misclassification/omission: review source coverage and retain exact evidence |
| Stakeholder disagreement is flattened into one plan | PM reconciles inconsistent requests | Extractor + Gap Analyzer | Attributed viewpoints -> conflicts and decision questions | Favoring a stakeholder: preserve all views and keep resolution open |
| PRD formats differ between PMs | PM rewrites into a preferred document structure | PRD Generator + template renderer | Validated extraction -> ten-section PRD | Plausible invented detail: use evidence IDs and explicit unknowns |
| Engineering work items require another rewrite | PM converts feature prose into a backlog | Story Breakdown | PRD + evidence -> epics, features, stories, priorities | Scope creep: link every story, copy criteria, label suggested priority |
| Missing information is discovered during implementation | Engineers ask questions late | Gap Analyzer | Extraction + source context -> prioritized clarification register | Excessive generic questions: require relevance and a rationale |
| Quality is subjective and difficult to reproduce | PM spot-checks a few outputs | Evaluation workflow | Baseline cases + expected elements -> outputs, checks, review results | Keyword-only passes miss hallucinations: combine deterministic and human checks |
| LLM cost/latency is invisible | Team notices failures and spend after the fact | Observability instrumentation | Per-stage model response metadata -> traces, tokens, duration, errors | Missing traces appear successful: expose delivery status and verify visibility |

**MVP prioritization:** source extraction and grounded PRD generation first, story coverage second, actionable gap analysis third, with evaluation/tracing in the same release. No generalized autonomous project manager is needed to demonstrate value.

## Q2. Program charter

**Program:** PRD Genie. **Sponsor:** NeuronForge Product and Innovation leadership (specific person not provided). **Accountable owner:** capstone PM/TPM, to be named. **Status:** proposed MVP charter.

**Vision:** PMs can move from a messy discussion to a consistent, reviewable product draft while retaining the ability to inspect every requirement's origin.

**Problem:** Manual extraction, inconsistent documentation and repeated backlog translation delay engineering estimation and lose useful requirements. Automating document composition without preserving uncertainty would accelerate errors as well as useful work.

**Primary users:** PMs/TPMs drafting and reviewing scope. **Secondary users:** engineering/design leads checking feasibility and criteria; stakeholders answering open questions. These are PRD Genie's personas, distinct from the dashboard's sample personas.

**Scope included:** text ingestion; source attribution; requirements, NFRs, constraints, facts and issues; all ten PRD template sections; epics/features/stories with priorities; Gap Analysis; JSON/Markdown export; traces; baseline evaluation; human review guidance.

**Scope excluded for MVP:** audio capture/transcription, automatic ticket publishing, enterprise SSO, multi-tenant SaaS hosting, RAG over historic PRDs, fine-tuning, effort estimates, and version diffing. These are project scope recommendations, not extracted dashboard exclusions.

### Proposed objectives and acceptance targets

| Objective | Proposed target | Measurement |
|---|---|---|
| Preserve factual fidelity | Zero unsupported requirements in all 12 baseline cases after human review | Requirement-by-requirement source audit; record numerator/denominator |
| Complete the capstone behavior | All 12 cases pass their expected elements and human review | Saved inputs, stage outputs, automated results, reviewer notes |
| Handle uncertainty safely | All supplied ambiguous/insufficient/empty/conflicting cases identified appropriately | T2/T3/T5/T6/T9/T10 plus full-transcript examples |
| Produce usable structure | Ten template sections and traceable story hierarchy on sufficient inputs | Renderer/schema checks and PM review |
| Reduce authoring effort | At least 50% reduction in median time to a PM-approved draft in a small pilot | Time the same tasks manually and with PRD Genie; include review/edit time |
| Keep execution practical | Initial budget: p95 under 120 seconds per short input, median model cost below $0.10 per run | At least 30 representative runs; revise after measurement |
| Make failures visible | Trace and stage-level error evidence for each evaluable run | Match run IDs to Langfuse traces and saved outputs |

The speed, cost and productivity targets are provisional. The dataset contains no measured time-saving baseline. A 12-case functional suite alone cannot establish a statistically robust p95 latency or business impact.

### Ten working sessions, scheduled relative to kickoff

| Session | Deliverable | Exit criterion |
|---|---|---|
| 1 | Review, scope and rubric map | Stakeholder understands source facts versus proposals |
| 2 | JSON schemas, prompts and source IDs | Hand-authored examples validate; no invented evidence accepted |
| 3 | Extractor and status handling | T1, T2, T5, T9 run live with reviewed outputs |
| 4 | Conflict/dependency Gap Analysis | T3, T6, T10 questions actionable and neutral |
| 5 | PRD generation | T11 follows every template section using actual T1 extraction |
| 6 | Story breakdown | T4, T8, T12 retain criteria and personas |
| 7 | Tracing and measurement | Root + stage spans visible, failures visible, token usage recorded |
| 8 | Full evaluation and iteration | All 12 results recorded; regressions resolved or disclosed |
| 9 | Small PM review pilot | Quality and review-time observations documented |
| 10 | Submission assembly | Fresh workflow export, README, evidence, slides, video and reflection checked |

This is an effort sequence, not a calendar commitment. The sample dashboard's Q3 and March dates do not set the PRD Genie capstone deadline. Two to four focused hours per session is a planning assumption; adjust for the user's experience and setup.

### Stakeholders and decision rights

| Role | Responsibility | Decision |
|---|---|---|
| Capstone PM/TPM | Scope, prompts, baseline expectations, final artifacts | Accepts draft quality and release readiness |
| Engineering reviewer | APIs, schemas, errors, deployment boundary | Reviews technical implementation |
| PM/design reviewer | Readability, personas, story usefulness | Reviews product interpretation |
| Stakeholder/source owner | Clarifies ambiguous requests | Approves requirement changes; no agent makes this decision |
| Instructor/reviewer | Rubric interpretation | Confirms scoring and submission requirements |

### Risks and response

- **Hallucinated or omitted scope:** exact evidence checks, traceable mappings, semantic review, adversarial and paraphrased holdout cases.
- **Confident prioritization without agreement:** suggestions visibly labeled; all outputs remain drafts.
- **Unresolved contradiction accepted for implementation:** clarification register with blocking items; draft status does not equal implementation approval.
- **Provider latency, quota or output truncation:** bounded inputs and request timeouts; stop visibly on error; manually retry during MVP and record added cost.
- **Secret or source exposure:** credential store; no secrets in exports; source content excluded from Langfuse spans by default; retain n8n execution data only for the agreed demo period.
- **Rubric gaps:** use the checklist in the submission guide; confirm the printed 80-point total with the instructor.

### Rollout

Start with the supplied synthetic capstone inputs. Review outputs alongside originals. Then use a small set of consented/sanitized PM examples. Record changes required before approval and time spent reviewing. Broader organizational rollout requires access control, retention policy, durable jobs, versioning and an actual approval workflow; it is outside the present demo implementation.
