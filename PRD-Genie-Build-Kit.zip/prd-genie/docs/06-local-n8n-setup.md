# Continue without an n8n Cloud subscription

The user suspects the n8n Cloud trial has expired. Account expiration has not been verified. The recommended continuation is **local n8n Community edition using the existing Docker installation**. The generated PRD Genie workflow, prompts and tests remain usable without rebuilding them for another platform.

According to [n8n's self-hosting documentation](https://github.com/n8n-io/n8n-docs/blob/main/docs/deploy/host-n8n/README.md), self-hosted n8n runs as the free Community edition without a license key. The Cloud service requires a subscription after its trial; this is separate from the self-hosted edition. LLM API charges and any separately selected observability hosting charges are not removed by running n8n locally.

## Current machine status

- Docker's Windows executable is installed.
- This Codex session was denied access to Docker's engine and configuration, so no image was downloaded and no container was started.
- The Cloud dashboard link reached an instance-selection page, not an account-expiration notice.
- Local deployment files are prepared. Actual Docker startup, owner account, workflow import and model/tracing credentials remain pending.

## Start it

1. Open **Docker Desktop** from the Windows Start menu and wait until the engine is running. If Docker requests first-time setup or terms acceptance, complete that yourself.
2. Open the `deployment` directory and double-click **Start-PRD-Genie.cmd**. It checks Docker availability, downloads the pinned official n8n image if needed, and starts the service.
3. Open **http://localhost:5678**. Allow a minute for initial startup after the image download.
4. Complete n8n's local owner-account setup yourself. Choose credentials locally; do not put them in chat. This creates the owner of this local instance, not a paid Cloud subscription.
5. Tell Codex when the editor is visible. The existing workflow can then be imported and connected to the model/tracing credentials.

Equivalent PowerShell command, with Docker Desktop already running:

```powershell
docker compose -f "C:\Users\Admin\Documents\Codex\2026-09-05\c\outputs\prd-genie\deployment\compose.yaml" up -d
```

If you extracted the ZIP elsewhere, run `docker compose -f .\deployment\compose.yaml up -d` from the extracted `prd-genie` directory instead.

## What the setup does

- Uses the official `docker.n8n.io/n8nio/n8n:2.37.10` image. The version was verified against the [4 September 2026 release](https://github.com/n8n-io/n8n/releases/tag/n8n%402.37.10).
- Binds port 5678 to **127.0.0.1 only**, so the editor is available on this computer. No public tunnel is configured.
- Stores the SQLite database, instance encryption key and credentials in the dedicated Docker volume `prd-genie-local_n8n_data`.
- Mounts the generated workflow directory read-only inside the container. This does not import the workflow automatically.
- Uses the user's Asia/Kolkata timezone. Authentication remains enabled; no password is bundled and no security cookie setting is disabled.
- Uses a health check and restarts the service when Docker restarts unless you explicitly stop it.

The composition follows the official Docker deployment approach. It is a local capstone setup, not a production hosting design. The YAML and launcher have been inspected locally, but Docker execution is not verified in this protected session.

## Import the prepared workflow

In the local n8n editor, create/import a workflow from `workflows/prd-genie.n8n.json`. Confirm all 23 nodes appear. Follow the README's credential steps and first T1/T9 smoke tests. The local workflow begins inactive, like the supplied JSON.

If an OpenAI connection already existed only in the expired Cloud instance, it is not automatically available in this new local database. Recreate/bind the needed credential locally or use a credential already present in the selected local instance. The connected model provider is still unconfirmed; the current workflow targets OpenAI Responses.

For evaluator calls, copy the **production webhook URL shown by the local n8n editor** after publishing/activating the workflow. Do not use the old Cloud URL. The local test webhook is for one-off listening; use the production URL for repeated cases. Keep the webhook Header Auth credential in place.

## Stop and restart

Double-click `Stop-PRD-Genie.cmd` to stop only this Compose service. Saved workflows and credentials remain in the Docker volume. Run `Start-PRD-Genie.cmd` to restart it. Do not delete the Docker volume unless you intentionally want to erase this local instance's data.

## Troubleshooting

| Symptom | Next step |
|---|---|
| Docker engine unavailable | Open Docker Desktop and wait for startup; rerun from your normal Windows terminal |
| Port 5678 already allocated | Check whether your existing local n8n already uses http://localhost:5678; do not terminate an unknown process |
| Image download fails | Check Docker's network/proxy configuration and retry; no paid n8n plan is required |
| Browser initially cannot connect | Allow startup to finish; inspect `docker compose -f .\deployment\compose.yaml logs --tail 60 n8n` |
| Setup page appears | Complete the local owner-account form yourself; this is a fresh local database |
| Model credential missing | Bind a local provider credential; Cloud credentials are not migrated by the supplied workflow JSON |
| No Langfuse trace | Set the correct host and credential, then check `tracing_status` and actual dashboard visibility |

## Existing Cloud workflows

PRD Genie's generated JSON and all project files are already saved locally, so this project does not depend on recovering Cloud data. If you have other valuable workflows in the expired trial, export them promptly if the Admin Panel still offers that option. The [n8n trial FAQ](https://support.n8n.io/article/how-do-i-cancel-my-trial) offers a one-time extension through support and describes post-trial export access, but its stated retention windows are inconsistent (30 and 90 days). Do not rely on a guaranteed recovery window. No extension request or support message has been sent.
