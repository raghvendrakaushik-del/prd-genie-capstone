'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const core=require('./core.cjs');
const root=path.resolve(__dirname,'..');
function assets(){return {prompts:Object.fromEntries(['extractor','gaps','prd','stories'].map(s=>[s,fs.readFileSync(path.join(root,'prompts',s+'.md'),'utf8')])),template:fs.readFileSync(path.join(root,'resources/prd_template.md'),'utf8')};}
async function runPipeline(input, options={}) {
  const config=assets(); const model=options.model||process.env.OPENAI_MODEL||'gpt-5.4-mini-2026-03-17';
  const run={run_id:crypto.randomUUID(),trace_id:crypto.randomBytes(16).toString('hex'),root_span_id:crypto.randomBytes(8).toString('hex'),started_at:Date.now(),input:core.validateInput(input),stages:[]};
  let extraction=null,gaps=null,prd=null,stories=null,error=null;
  const provider=options.provider|| (async body=>{
    if(!process.env.OPENAI_API_KEY)throw new Error('OPENAI_API_KEY is not set. Use a local environment file; never paste keys into project files.');
    const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(120000)});
    if(!response.ok)throw new Error(`OpenAI HTTP ${response.status}`);
    return response.json();
  });
  async function stage(name,data,validator) {
    const record={name,input:data,model,span_id:crypto.randomBytes(8).toString('hex'),started_at:Date.now(),usage:{},output:null};
    try {const response=await provider(core.requestBody(name,data,config,model));record.usage=response.usage||{};
      record.output=core.parseResponse(response,core.schemas[name]);validator(record.output);return record.output;
    } catch(e) {record.error=true;record.output={error:e.message};throw e;}
    finally {record.ended_at=Date.now();run.stages.push(record);}
  }
  try {
    extraction=await stage('extractor',run.input,e=>core.validateExtraction(e,run.input.documents));
    gaps=await stage('gaps',{documents:run.input.documents,extraction},g=>core.validateGaps(g,extraction));
    if(extraction.status==='sufficient') {
      prd=await stage('prd',{extraction,gaps},p=>core.validatePrd(p,extraction,gaps));
      stories=await stage('stories',{extraction,prd},s=>core.validateStories(s,extraction));
    }
  } catch(e) {error={stage:run.stages.at(-1)?.name||'input',message:e.message};}
  run.ended_at=Date.now();run.status=error?'error':stories?'draft_ready':extraction.status;
  let tracing_status='not_configured';
  if(process.env.LANGFUSE_PUBLIC_KEY && process.env.LANGFUSE_SECRET_KEY && options.trace!==false) {
    const traceRun=structuredClone(run);
    if(!options.traceContent){traceRun.input={document_count:input.documents.length};traceRun.stages.forEach(s=>{s.input={omitted:true};s.output={omitted:true,error:!!s.error};});}
    try {
      const response=await fetch((process.env.LANGFUSE_BASE_URL||'https://cloud.langfuse.com').replace(/\/$/,'')+'/api/public/otel/v1/traces',{
        method:'POST',headers:{Authorization:'Basic '+Buffer.from(process.env.LANGFUSE_PUBLIC_KEY+':'+process.env.LANGFUSE_SECRET_KEY).toString('base64'),
        'Content-Type':'application/json','x-langfuse-ingestion-version':'4'},body:JSON.stringify(core.otelPayload(traceRun)),signal:AbortSignal.timeout(20000)});
      const body=await response.json().catch(()=>({}));
      tracing_status=response.ok && !Number(body.partialSuccess?.rejectedSpans||0)?'accepted_by_endpoint':'failed';
    }catch {tracing_status='failed';}
  }
  return {run_id:run.run_id,trace_id:run.trace_id,status:run.status,error,extraction,gaps,prd,stories,review_required:true,tracing_status,
    prd_markdown:stories?core.renderPrd(extraction,gaps,prd):null,stories_markdown:stories?core.renderStories(stories,extraction):null,
    usage:run.stages.map(s=>({stage:s.name,model:s.model,usage:s.usage,latency_ms:s.ended_at-s.started_at}))};
}
if(require.main===module) (async()=>{
  const [inputPath,outputPath]=process.argv.slice(2);
  if(!inputPath||!outputPath)throw new Error('Usage: node --env-file=.env src/run.cjs examples/t1.request.json runs/t1.json');
  const result=await runPipeline(JSON.parse(fs.readFileSync(inputPath,'utf8')));
  fs.mkdirSync(path.dirname(outputPath),{recursive:true});fs.writeFileSync(outputPath,JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({status:result.status,tracing_status:result.tracing_status,output:outputPath}));
  if(result.error)process.exitCode=1;
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={runPipeline};
