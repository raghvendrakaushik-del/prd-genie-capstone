'use strict';
// Dependency-free functions shared by the CLI and embedded n8n Code nodes.
const S = { type: 'string' };
const A = items => ({ type: 'array', items });
const E = values => ({ type: 'string', enum: values });
const O = properties => ({ type: 'object', properties, required: Object.keys(properties), additionalProperties: false });
const nullable = schema => ({ anyOf: [schema, { type: 'null' }] });
const priorities = ['Must Have', 'Should Have', 'Nice to Have'];
const evidence = { text: S, source_id: S, quote: S };
const factKinds = ['product_name','goal','persona','stakeholder','deadline','dependency','assumption','out_of_scope','decision','context'];
const schemas = {
  extractor: O({
    status: E(['sufficient','ambiguous','insufficient','empty']),
    requirements: A(O({ id: S, ...evidence, kind: E(['functional','non_functional','constraint']), category: S,
      persona: nullable(S), priority: nullable(E(priorities)), acceptance_criteria: A(O(evidence)) })),
    facts: A(O({ id: S, kind: E(factKinds), ...evidence })),
    issues: A(O({ id: S, kind: E(['ambiguity','conflict','risk','missing']), description: S,
      requirement_ids: A(S), source_ids: A(S), question: S }))
  }),
  gaps: O({ questions: A(O({ id: S, question: S, rationale: S, suggested_owner: S,
    severity: E(['blocking','important','minor']), evidence_ids: A(S), resolution_status: E(['open']) })) }),
  prd: O(Object.fromEntries(['overview_ids','goal_ids','persona_ids','functional_ids','nfr_ids','constraint_ids',
    'criteria_requirement_ids','out_of_scope_ids','dependency_ids','assumption_ids','question_ids','deadline_ids'].map(k => [k,A(S)]))),
  stories: O({ epics: A(O({ id:S, title:S, features:A(O({id:S,title:S,requirement_ids:A(S),
    stories:A(O({id:S,persona:S,persona_basis:E(['stated','generic_placeholder']),statement:S,
      priority:E(priorities),priority_basis:E(['stated','suggested']),requirement_ids:A(S)}))})) })) })
};
function assert(ok, message) { if (!ok) throw new Error(message); }
function validateSchema(value, schema, path = '$') {
  if (schema.anyOf) {
    assert(schema.anyOf.some(option => { try { validateSchema(value, option, path); return true; } catch { return false; } }), `${path}: wrong nullable type`);
    return;
  }
  if (schema.type === 'null') return assert(value === null, `${path}: expected null`);
  if (schema.type === 'object') {
    assert(value !== null && typeof value === 'object' && !Array.isArray(value), `${path}: expected object`);
    for (const key of schema.required) assert(Object.hasOwn(value,key), `${path}: missing ${key}`);
    for (const key of Object.keys(value)) assert(Object.hasOwn(schema.properties,key), `${path}: unexpected ${key}`);
    for (const [key, child] of Object.entries(schema.properties)) validateSchema(value[key], child, `${path}.${key}`);
  } else if (schema.type === 'array') {
    assert(Array.isArray(value), `${path}: expected array`);
    value.forEach((item,i) => validateSchema(item,schema.items,`${path}[${i}]`));
  } else assert(typeof value === schema.type, `${path}: expected ${schema.type}`);
  if (schema.enum) assert(schema.enum.includes(value), `${path}: invalid enum`);
}
function unique(items, label) { assert(new Set(items).size === items.length, `Duplicate ${label}`); }
function validateInput(input) {
  assert(input && typeof input === 'object', 'Input must be an object');
  assert(Array.isArray(input.documents) && input.documents.length > 0 && input.documents.length <= 10, 'Provide 1-10 documents');
  let total = 0;
  for (const doc of input.documents) {
    assert(typeof doc.id === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(doc.id), 'Invalid document ID');
    assert(typeof doc.text === 'string', 'Document text must be a string');
    assert(typeof doc.name === 'string' && doc.name.length <= 200, 'Document name required, max 200 characters');
    total += doc.text.length;
  }
  unique(input.documents.map(d=>d.id),'document IDs');
  assert(total <= 60000, 'Input exceeds 60,000 characters; split into related project documents');
  return { documents: input.documents.map(({id,name,text})=>({id,name,text})) };
}
function checkEvidence(item, documents) {
  const doc = documents.find(d => d.id === item.source_id);
  assert(doc && item.quote.trim() && doc.text.includes(item.quote), `Unsupported source quote: ${item.source_id}`);
  assert(item.text === item.quote, 'Evidence text must preserve the source quote exactly');
}
function validateExtraction(extraction, documents) {
  validateSchema(extraction, schemas.extractor);
  const all = [...extraction.requirements,...extraction.facts,...extraction.issues];
  unique(all.map(x=>x.id),'evidence IDs');
  for(const r of extraction.requirements) {
    assert(/^R-\d{3,}$/.test(r.id),'Requirement ID must use R-001 format');
    checkEvidence(r, documents);
    r.acceptance_criteria.forEach(ac=>checkEvidence(ac,documents));
    if(r.persona !== null) assert(documents.some(d=>d.text.toLowerCase().includes(r.persona.toLowerCase())), 'Persona must appear in source');
  }
  for(const f of extraction.facts) { assert(/^F-\d{3,}$/.test(f.id),'Fact ID must use F-001 format'); checkEvidence(f,documents); }
  const reqIds = new Set(extraction.requirements.map(r=>r.id));
  for(const issue of extraction.issues) {
    assert(/^I-\d{3,}$/.test(issue.id),'Issue ID must use I-001 format');
    assert(issue.question.trim(),'Issue needs a clarification question');
    issue.requirement_ids.forEach(id=>assert(reqIds.has(id),'Issue references unknown requirement'));
    issue.source_ids.forEach(id=>assert(documents.some(d=>d.id===id),'Issue references unknown source'));
  }
  assert((extraction.status === 'sufficient') === (extraction.requirements.length > 0), 'Only sufficient inputs may have actionable requirements');
  return extraction;
}
function validateGaps(gaps, extraction) {
  validateSchema(gaps, schemas.gaps);
  if(extraction.status!=='sufficient') assert(gaps.questions.length>0,'Insufficient input requires a clarification question');
  unique(gaps.questions.map(q=>q.id),'question IDs');
  const known = new Set([...extraction.requirements,...extraction.facts,...extraction.issues].map(x=>x.id));
  for(const q of gaps.questions) {
    assert(/^G-\d{3,}$/.test(q.id),'Gap IDs must use G-001 format');
    assert(q.question.trim() && q.rationale.trim(),'Empty clarification');
    q.evidence_ids.forEach(id=>assert(known.has(id),`Unknown gap evidence ${id}`));
  }
  for(const issue of extraction.issues) assert(gaps.questions.some(q=>q.evidence_ids.includes(issue.id)),`Gap analyzer dropped ${issue.id}`);
  return gaps;
}
function sameMembers(actual, expected, label) {
  unique(actual,label);
  assert(actual.length === expected.length && actual.every(id=>expected.includes(id)), `Incomplete or invalid ${label}`);
}
function validatePrd(prd, extraction, gaps) {
  validateSchema(prd, schemas.prd);
  assert(extraction.status==='sufficient','No PRD for insufficient input');
  for(const [key,kind] of [['functional_ids','functional'],['nfr_ids','non_functional'],['constraint_ids','constraint']])
    sameMembers(prd[key],extraction.requirements.filter(r=>r.kind===kind).map(r=>r.id),key);
  sameMembers(prd.criteria_requirement_ids,extraction.requirements.filter(r=>r.acceptance_criteria.length).map(r=>r.id),'criteria coverage');
  for(const [key,kinds] of [['overview_ids',['product_name','context','decision','stakeholder']],['goal_ids',['goal']],['persona_ids',['persona']],
    ['out_of_scope_ids',['out_of_scope']],['dependency_ids',['dependency']],['assumption_ids',['assumption']],['deadline_ids',['deadline']]])
    sameMembers(prd[key],extraction.facts.filter(f=>kinds.includes(f.kind)).map(f=>f.id),key);
  sameMembers(prd.question_ids,gaps.questions.map(q=>q.id),'question coverage');
  return prd;
}
function validateStories(stories, extraction) {
  validateSchema(stories, schemas.stories);
  const reqs = new Map(extraction.requirements.map(r=>[r.id,r]));
  const covered = new Set(); const ids = [];
  assert(stories.epics.length>0,'Need at least one epic');
  for(const epic of stories.epics) {
    ids.push(epic.id); assert(epic.features.length>0,'Epic requires features');
    for(const feature of epic.features) {
      ids.push(feature.id); assert(feature.requirement_ids.length>0 && feature.stories.length>0,'Feature needs sources and stories');
      feature.requirement_ids.forEach(id=>assert(reqs.has(id),`Unknown feature requirement ${id}`));
      for(const story of feature.stories) {
        ids.push(story.id);
        assert(story.statement.startsWith(`As a ${story.persona}`) && story.statement.includes('I want') && story.statement.includes('so that'),'Invalid user story format');
        assert(story.requirement_ids.length>0,'Unlinked story');
        for(const id of story.requirement_ids) { assert(feature.requirement_ids.includes(id),'Story reference missing from feature'); covered.add(id); }
        if(story.persona_basis==='stated') assert(story.requirement_ids.some(id=>reqs.get(id).persona?.toLowerCase()===story.persona.toLowerCase()),'Unsupported story persona');
        else assert(story.persona==='user','Generic persona must be user');
        if(story.priority_basis==='stated') assert(story.requirement_ids.some(id=>reqs.get(id).priority===story.priority),'Unsupported stated priority');
        for(const id of story.requirement_ids) if(reqs.get(id).persona) assert(reqs.get(id).persona.toLowerCase()===story.persona.toLowerCase(),'Different personas must remain in separate stories');
      }
      for(const id of feature.requirement_ids) assert(feature.stories.some(s=>s.requirement_ids.includes(id)),'Feature has an unassigned requirement');
    }
  }
  unique(ids,'epic/feature/story IDs');
  for(const r of extraction.requirements) assert(covered.has(r.id),`Stories dropped ${r.id}`);
  return stories;
}
function parseResponse(response, schema) {
  assert(response && !response.error,'Model API error');
  assert(response.status==='completed',`Model response not completed: ${response.status || 'missing status'}`);
  const parts = (response.output || []).flatMap(o=>o.content || []);
  assert(!parts.some(p=>p.type==='refusal'),'Model refused request');
  const text = parts.filter(p=>p.type==='output_text').map(p=>p.text).join('');
  assert(text,'Model returned no output text');
  const value = JSON.parse(text); validateSchema(value,schema); return value;
}
function requestBody(stage, data, assets, model) {
  assert(Object.hasOwn(schemas,stage),'Unknown stage');
  return {model,store:false,max_output_tokens:8000,instructions:assets.prompts[stage],
    input:JSON.stringify({task:stage,source_data:data,template:stage==='prd'?assets.template:undefined}),
    text:{format:{type:'json_schema',name:`prd_genie_${stage}`,strict:true,schema:schemas[stage]}}};
}
function esc(text) { return String(text).replace(/[\r\n]+/g,' ').replace(/\|/g,'\\|').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function renderPrd(extraction, gaps, prd) {
  validatePrd(prd,extraction,gaps);
  const byId = new Map([...extraction.requirements,...extraction.facts].map(x=>[x.id,x]));
  const cite = item=>`[${item.id}; ${esc(item.source_id)}]`;
  const bullets = ids=>ids.length?ids.map(id=>`- ${esc(byId.get(id).text)} ${cite(byId.get(id))}`).join('\n'):'- Not stated.';
  const product = extraction.facts.find(f=>f.kind==='product_name');
  const priority = p=>p===null?'Not stated':({'Must Have':'Must','Should Have':'Should','Nice to Have':'Nice'})[p];
  const functional=prd.functional_ids.map(id=>byId.get(id));
  const nfrs=prd.nfr_ids.map(id=>byId.get(id));
  const criteria=prd.criteria_requirement_ids.map(id=>byId.get(id));
  return `# Product Requirements Document (PRD)\n\n> AI-generated draft. Requires PM review. Evidence is copied from the source; omissions and semantic interpretation still require review.\n\n## 1. Product Overview\n- **Product Name:** ${product?esc(product.text):'Not stated'}\n- **Document Version:** 0.1 (generated draft)\n- **Author:** PRD Genie (generator; approving PM not assigned)\n- **Date:** Not assigned\n- **Status:** Draft\n${bullets(prd.overview_ids)}\n\n## 2. Goals and Objectives\n- **Business Goal / User Goal:** See stated evidence below; unspecified goals remain open.\n${bullets(prd.goal_ids)}\n- **Success Metrics:** Not independently inferred; see any explicit targets in requirements.\n\n## 3. User Personas\n${bullets(prd.persona_ids)}\n- **Current Workaround:** Not inferred; retain only source evidence above.\n\n## 4. Feature Requirements\n\n### 4.1 Functional Requirements\n| ID | Requirement | Priority (Must/Should/Nice) | Source |\n|----|-------------|---------------------------|--------|\n${functional.map(r=>`| ${r.id} | ${esc(r.text)} | ${priority(r.priority)} | ${esc(r.source_id)} |`).join('\n') || '| - | Not stated | - | - |'}\n\n### 4.2 Non-Functional Requirements\n| ID | Requirement | Category | Target |\n|----|-------------|----------|--------|\n${nfrs.map(r=>`| ${r.id} | ${esc(r.text)} [${esc(r.source_id)}] | ${esc(r.category)} | See exact source wording in Requirement |`).join('\n') || '| - | Not stated | - | - |'}\n\n### 4.3 Stated Constraints\n${bullets(prd.constraint_ids)}\n\n## 5. Acceptance Criteria\n${criteria.map(r=>`- **${r.id}:**\n${r.acceptance_criteria.map(ac=>`  - [ ] ${esc(ac.text)} [${esc(ac.source_id)}]`).join('\n')}`).join('\n') || '- Not stated. Request criteria before implementation.'}\n\n## 6. Out of Scope\n${bullets(prd.out_of_scope_ids)}\n\n## 7. Dependencies\n| Dependency | Owner | Status | Risk |\n|-----------|-------|--------|------|\n${prd.dependency_ids.map(id=>`| ${esc(byId.get(id).text)} ${cite(byId.get(id))} | See source wording; not inferred | Not independently verified | Review clarification register |`).join('\n') || '| Not stated | Not stated | Not stated | Not assessed |'}\n\n## 8. Assumptions\n${bullets(prd.assumption_ids)}\n\n## 9. Open Questions\n${gaps.questions.map(q=>`- **${q.id} (${q.severity}; open):** ${esc(q.question)} Suggested owner: ${esc(q.suggested_owner)}. Evidence: ${q.evidence_ids.join(', ')||'Missing source information'}.`).join('\n') || '- No additional questions identified; PM review is still required.'}\n\n## 10. Timeline\n| Milestone | Target Date |\n|-----------|-------------|\n| Design Complete | Not stated unless evidenced below |\n| Development Start | Not stated unless evidenced below |\n| QA / Testing | Not stated unless evidenced below |\n| Launch | Not stated unless evidenced below |\n\nStated timing (preserved without inferring a calendar year):\n${bullets(prd.deadline_ids)}\n`;
}
function renderStories(stories, extraction) {
  validateStories(stories,extraction);
  const reqs=new Map(extraction.requirements.map(r=>[r.id,r]));
  return '# Epics, Features and User Stories\n\n> Draft. Suggested priorities and generated story wording require PM review.\n\n'+stories.epics.map(e=>
    `## ${esc(e.id)}: ${esc(e.title)}\n\n`+e.features.map(f=>`### ${esc(f.id)}: ${esc(f.title)}\n\n`+f.stories.map(s=> {
      const criteria=s.requirement_ids.flatMap(id=>reqs.get(id).acceptance_criteria);
      const uniqueCriteria=[...new Map(criteria.map(c=>[`${c.source_id}:${c.quote}`,c])).values()];
      return `**${esc(s.id)}** ${esc(s.statement)}\n\n- Persona basis: ${s.persona_basis}\n- Priority: ${s.priority} (${s.priority_basis})\n- Requirements: ${s.requirement_ids.join(', ')}\n- Acceptance criteria (source wording):\n${uniqueCriteria.map(c=>`  - [ ] ${esc(c.text)} [${esc(c.source_id)}]`).join('\n')||'  - Not stated; clarification required.'}\n`;
    }).join('\n')).join('\n')).join('\n');
}
function otelPayload(run) {
  const attr=(key,value)=>({key,value:{stringValue:typeof value==='string'?value:JSON.stringify(value)}});
  const common=[attr('langfuse.trace.name','PRD Genie'),attr('langfuse.environment','capstone'),attr('langfuse.version','0.1.0'),attr('langfuse.trace.metadata.run_id',run.run_id)];
  const span=(name,id,start,end,type,extra=[],error=false)=>({traceId:run.trace_id,spanId:id,...(id===run.root_span_id?{}:{parentSpanId:run.root_span_id}),name,kind:1,
    startTimeUnixNano:String(BigInt(start)*1000000n),endTimeUnixNano:String(BigInt(end)*1000000n),
    attributes:[...common,attr('langfuse.observation.type',type),...extra],status:{code:error?2:1}});
  const spans=[span('PRD Genie',run.root_span_id,run.started_at,run.ended_at,'chain',[
    attr('langfuse.observation.input',run.input),attr('langfuse.observation.output',{status:run.status}),
    attr('langfuse.observation.metadata.automated_grounding','quote_match_and_reference_validation_only')],run.status==='error')];
  run.stages.forEach(s=>spans.push(span(s.name,s.span_id,s.started_at,s.ended_at,'generation',[
    attr('langfuse.observation.model.name',s.model),attr('langfuse.observation.input',s.input),
    attr('langfuse.observation.output',s.output),attr('langfuse.observation.usage_details',Object.fromEntries(
      [['input',s.usage?.input_tokens],['output',s.usage?.output_tokens]].filter(([,value])=>Number.isFinite(value)))),attr('langfuse.observation.metadata.prompt_version','v1')],Boolean(s.error))));
  return {resourceSpans:[{resource:{attributes:[attr('service.name','prd-genie')]},scopeSpans:[{scope:{name:'prd-genie',version:'0.1.0'},spans}]}]};
}
module.exports = {schemas,validateSchema,validateInput,validateExtraction,validateGaps,validatePrd,validateStories,parseResponse,requestBody,renderPrd,renderStories,otelPayload};
