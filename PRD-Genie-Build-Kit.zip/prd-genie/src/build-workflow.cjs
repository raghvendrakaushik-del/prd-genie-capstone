'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root=path.resolve(__dirname,'..');
const core=require('./core.cjs');
const shared=fs.readFileSync(path.join(__dirname,'core.cjs'),'utf8').replace(/module\.exports = [^\n]+;/,'');
const assets={prompts:Object.fromEntries(['extractor','gaps','prd','stories'].map(s=>[s,fs.readFileSync(path.join(root,'prompts',s+'.md'),'utf8')])),
  template:fs.readFileSync(path.join(root,'resources/prd_template.md'),'utf8')};
for(const [name,schema] of Object.entries(core.schemas)) fs.writeFileSync(path.join(root,'schemas',name+'.json'),JSON.stringify(schema,null,2)+'\n');
const nodes=[];const connections={};
function node(name,type,parameters,x,y,extra={}) {
  const n={id:crypto.randomUUID(),name,type:`n8n-nodes-base.${type}`,typeVersion:({webhook:2,code:2,if:2,httpRequest:4.2,respondToWebhook:1.4,stickyNote:1})[type],
    position:[x,y],parameters,...extra};nodes.push(n);return name;
}
function link(from,to,branch=0) {
  connections[from]??={main:[]};while(connections[from].main.length<=branch)connections[from].main.push([]);
  connections[from].main[branch].push({node:to,type:'main',index:0});
}
function code(name,body,x,y,includeCore=true){return node(name,'code',{jsCode:(includeCore?shared+'\n':'')+body,mode:'runOnceForAllItems'},x,y);}
function condition(name,expression,x,y){return node(name,'if',{conditions:{options:{caseSensitive:true,leftValue:'',typeValidation:'strict'},
  conditions:[{id:crypto.randomUUID(),leftValue:expression,rightValue:true,operator:{type:'boolean',operation:'true',singleValue:true}}],combinator:'and'},options:{}},x,y);}
node('Read me','stickyNote',{content:'## PRD Genie - configure before first run\n1. Bind webhook Header Auth credential (X-PRD-Genie-Key).\n2. Bind OpenAI Header Auth on four agent calls (Authorization: Bearer ...).\n3. Bind Langfuse Basic Auth (public key / secret key).\n4. Set Langfuse region and model in Initialize.\n5. Import is not runtime validation. Run T1 and confirm a Langfuse trace, then all tests.\n\nOutputs are drafts. No Jira/Docs publishing or stakeholder messaging occurs.\nMax input: 10 docs, 60k characters.\nNo credentials are bundled.',width:570,height:390},-650,-500);
node('PRD Genie Webhook','webhook',{httpMethod:'POST',path:'prd-genie-v1',authentication:'headerAuth',responseMode:'responseNode',options:{}},-650,0,{webhookId:crypto.randomUUID()});
code('Initialize',`const assets=${JSON.stringify(assets)};
const randomHex = length => Array.from({length},()=>Math.floor(Math.random()*16).toString(16)).join('');
const state={assets,model:'gpt-5.4-mini-2026-03-17',langfuse_base_url:'https://cloud.langfuse.com',trace_content:false,
  run_id:String($execution.id),trace_id:randomHex(32),root_span_id:randomHex(16),started_at:Date.now(),stages:[],error:null};
try { state.input=validateInput($input.first().json.body); } catch(e) { state.error={stage:'input',message:e.message}; state.input={documents:[]}; }
return [{json:state}];`,-420,0);
condition('Valid Input?','={{ !$json.error }}',-190,0);
link('PRD Genie Webhook','Initialize');link('Initialize','Valid Input?');
const layout={extractor:[60,0],gaps:[60,320],prd:[60,640],stories:[60,960]};
for(const [stage,[x,y]] of Object.entries(layout)) {
  const title=stage==='extractor'?'Extractor':stage==='gaps'?'Gap Analyzer':stage==='prd'?'PRD Generator':'Story Breakdown';
  const dataExpression=stage==='extractor'?'state.input':stage==='gaps'?'{documents:state.input.documents,extraction:state.extraction}':stage==='prd'?'{extraction:state.extraction,gaps:state.gaps}':'{extraction:state.extraction,prd:state.prd}';
  code(`Prepare ${title}`,`const state=$input.first().json;
const stage_input=${dataExpression};
state.pending={name:'${stage}',input:stage_input,started_at:Date.now(),span_id:Array.from({length:16},()=>Math.floor(Math.random()*16).toString(16)).join(''),model:state.model};
state.request=requestBody('${stage}',stage_input,state.assets,state.model);
return [{json:state}];`,x,y);
  node(title,'httpRequest',{method:'POST',url:'https://api.openai.com/v1/responses',authentication:'genericCredentialType',genericAuthType:'httpHeaderAuth',
    sendBody:true,contentType:'json',specifyBody:'json',jsonBody:'={{ $json.request }}',options:{timeout:120000,response:{response:{responseFormat:'json'}}}},x+230,y,
    {onError:'continueRegularOutput',retryOnFail:false,notes:'Bind your OpenAI Header Auth credential. Retries are explicit/manual to keep cost and error evidence visible.'});
  const validation=stage==='extractor'?'validateExtraction(value,state.input.documents)':stage==='gaps'?'validateGaps(value,state.extraction)':stage==='prd'?'validatePrd(value,state.extraction,state.gaps)':'validateStories(value,state.extraction)';
  const key=stage==='extractor'?'extraction':stage;
  code(`Capture ${title}`,`const state=$('Prepare ${title}').first().json;
const response=$input.first().json;
const record={...state.pending,ended_at:Date.now(),usage:response.usage||{},output:null};
try { const value=parseResponse(response,schemas['${stage}']); ${validation}; state.${key}=value; record.output=value; }
catch(e) { state.error={stage:'${stage}',message:e.message}; record.error=true; record.output={error:e.message}; }
state.stages.push(record);delete state.pending;delete state.request;
return [{json:state}];`,x+460,y);
  link(`Prepare ${title}`,title);link(title,`Capture ${title}`);
}
condition('Extraction Valid?','={{ !$json.error }}',750,0);
condition('Enough to Draft?','={{ !$json.error && $json.extraction.status === "sufficient" }}',750,320);
condition('PRD Valid?','={{ !$json.error }}',750,640);
link('Valid Input?','Prepare Extractor');link('Valid Input?','Finalize',1);
link('Capture Extractor','Extraction Valid?');link('Extraction Valid?','Prepare Gap Analyzer');link('Extraction Valid?','Finalize',1);
link('Capture Gap Analyzer','Enough to Draft?');link('Enough to Draft?','Prepare PRD Generator');link('Enough to Draft?','Finalize',1);
link('Capture PRD Generator','PRD Valid?');link('PRD Valid?','Prepare Story Breakdown');link('PRD Valid?','Finalize',1);
link('Capture Story Breakdown','Finalize');
code('Finalize',`const state=$input.first().json;
state.ended_at=Date.now();state.status=state.error?'error':state.stories?'draft_ready':state.extraction?.status||'error';
const result={run_id:state.run_id,trace_id:state.trace_id,status:state.status,error:state.error,
  extraction:state.extraction||null,gaps:state.gaps||null,prd:state.prd||null,stories:state.stories||null,
  prd_markdown:null,stories_markdown:null,
  review_required:true,usage:state.stages.map(s=>({stage:s.name,model:s.model,usage:s.usage,latency_ms:s.ended_at-s.started_at}))};
if(state.status==='draft_ready') {result.prd_markdown=renderPrd(state.extraction,state.gaps,state.prd);result.stories_markdown=renderStories(state.stories,state.extraction);}
const traceRun=JSON.parse(JSON.stringify(state));
if(!state.trace_content) {traceRun.input={document_count:state.input.documents.length};traceRun.stages.forEach(s=>{s.input={omitted:true};s.output={omitted:true,error:!!s.error};});}
return [{json:{result,trace:otelPayload(traceRun),langfuse_base_url:state.langfuse_base_url}}];`,1010,500);
node('Send Langfuse Trace','httpRequest',{method:'POST',url:'={{ $json.langfuse_base_url + "/api/public/otel/v1/traces" }}',authentication:'genericCredentialType',genericAuthType:'httpBasicAuth',
  sendHeaders:true,headerParameters:{parameters:[{name:'x-langfuse-ingestion-version',value:'4'}]},sendBody:true,contentType:'json',specifyBody:'json',jsonBody:'={{ $json.trace }}',
  options:{timeout:20000,response:{response:{responseFormat:'json',fullResponse:true,neverError:true}}}},1240,500,{onError:'continueRegularOutput',notes:'Bind Langfuse Basic Auth. Username = public key, password = secret key. Change region in Initialize.'});
code('Delivery Status',`const result=$('Finalize').first().json.result;
const response=$input.first().json;
const rejected=Number(response.body?.partialSuccess?.rejectedSpans||0);
result.tracing_status=response.statusCode>=200 && response.statusCode<300 && !response.error && !rejected?'accepted_by_endpoint':'failed';
result.tracing_note=result.tracing_status==='accepted_by_endpoint'?'Verify trace visibility in Langfuse before claiming observability connected.':'Trace delivery failed; workflow is not submission-ready.';
return [{json:result}];`,1470,500,false);
node('Return Draft','respondToWebhook',{respondWith:'json',responseBody:'={{ $json }}',options:{responseCode:200}},1700,500);
link('Finalize','Send Langfuse Trace');link('Send Langfuse Trace','Delivery Status');link('Delivery Status','Return Draft');
const workflow={name:'PRD Genie - Evidence Grounded Pipeline v0.1',nodes,connections,active:false,settings:{executionOrder:'v1',saveManualExecutions:true,saveDataSuccessExecution:'all',saveDataErrorExecution:'all'},pinData:{},tags:[]};
fs.writeFileSync(path.join(root,'workflows/prd-genie.n8n.json'),JSON.stringify(workflow,null,2)+'\n');
console.log(`Wrote ${nodes.length}-node workflow and four schemas. Import and live integration validation still required.`);
