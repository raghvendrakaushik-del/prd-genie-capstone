'use strict';
const fs=require('node:fs');const path=require('node:path');const c=require('./core.cjs');const f=require('../tests/fixtures.cjs');const {dataset}=require('./evaluate.cjs');
const root=path.resolve(__dirname,'..');const write=(name,value)=>fs.writeFileSync(path.join(root,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');
for(const item of dataset().filter(t=>!t.depends_on))write(`examples/${item.id.toLowerCase()}.request.json`,{documents:[{id:item.id,name:item.id,text:item.input}]});
write('examples/analytics-brief-and-notes.request.json',{documents:[
  {id:'brief',name:'sample_product_brief.txt',text:fs.readFileSync(path.join(root,'resources/sample_product_brief.txt'),'utf8')},
  {id:'notes',name:'stakeholder_notes.txt',text:fs.readFileSync(path.join(root,'resources/stakeholder_notes.txt'),'utf8')}
]});
write('examples/relayops.request.json',{documents:['relayops_product_brief.txt','relayops_meeting_transcript.txt','relayops_stakeholder_notes.txt'].map((name,i)=>({id:`relayops_${i+1}`,name,text:fs.readFileSync(path.join(root,'custom',name),'utf8')}))});
write('examples/relayops-incomplete.request.json',{documents:[{id:'relayops_incomplete',name:'relayops_incomplete_notes.txt',text:fs.readFileSync(path.join(root,'custom/relayops_incomplete_notes.txt'),'utf8')}]});
const transcripts=fs.readFileSync(path.join(root,'resources/sample_meeting_transcripts.txt'),'utf8');
const blocks=transcripts.split(/(?==== TRANSCRIPT \d+:)/).slice(1);
blocks.forEach((text,i)=>write(`examples/transcript-${i+1}.request.json`,{documents:[{id:`transcript_${i+1}`,name:`Sample transcript ${i+1}`,text:text.trim()}]}));
write('examples/t1.reference.json',{provenance:'Hand-authored fixture, NOT a live model output. Validates contracts and demonstrates formatting only.',extraction:f.extraction,gaps:f.gaps,prd:f.prd,stories:f.stories});
const disclaimer='> REFERENCE EXAMPLE: rendered from a hand-authored test fixture. This is not a live PRD Genie model output or baseline test result.\n\n';
write('examples/t1.reference-prd.md',disclaimer+c.renderPrd(f.extraction,f.gaps,f.prd));
write('examples/t1.reference-stories.md',disclaimer+c.renderStories(f.stories,f.extraction));
console.log('Prepared ten baseline requests, five transcript requests, paired-document request and labeled T1 references.');
