'use strict';
const fs=require('node:fs');const path=require('node:path');const {runPipeline}=require('./run.cjs');const core=require('./core.cjs');
const root=path.resolve(__dirname,'..');
function dataset(){
  const text=fs.readFileSync(path.join(root,'resources/eval_prdgenie_inputs.txt'),'utf8');
  return [...text.matchAll(/^T(\d+):\s*([^\r\n]+)/gm)].map(m=>({id:'T'+m[1],input:m[2],depends_on:m[1]==='11'?'T1':m[1]==='12'?'T11':null}));
}
function checkCase(id,result) {
  const checks=[];const add=(label,ok)=>checks.push({label,pass:Boolean(ok)});
  const e=result.extraction;const text=(e?[...e.requirements,...e.facts].map(r=>r.text).join(' '):'');
  const questions=(result.gaps?.questions||[]).map(q=>q.question+' '+q.rationale).join(' ').toLowerCase();
  const issueText=(e?.issues||[]).map(i=>i.description+' '+i.question).join(' ').toLowerCase();
  const allQuestions=questions+' '+issueText;
  const flatStories=(result.stories?.epics||[]).flatMap(ep=>ep.features.flatMap(fe=>fe.stories));
  add('Pipeline did not error',result.status!=='error' && !!e);
  if(!e)return checks;
  const sourceCase=dataset().find(item=>item.id===(['T11','T12'].includes(id)?'T1':id));
  try {
    core.validateExtraction(e,[{id:sourceCase.id,name:sourceCase.id,text:sourceCase.input}]);
    core.validateGaps(result.gaps,e);
    if(result.prd)core.validatePrd(result.prd,e,result.gaps);
    if(result.stories)core.validateStories(result.stories,e);
    add('Source quotes, typed output, references and coverage validate',true);
  }catch{add('Source quotes, typed output, references and coverage validate',false);}
  if(id==='T1'){
    add('All three filters',['date range','category','status'].every(s=>text.includes(s)));add('Exact 2 second target',text.includes('under 2 seconds'));
    add('PM Sarah captured as stakeholder',e.facts.some(f=>f.kind==='stakeholder'&&f.text.includes('Sarah')));add('Q3 deadline',e.facts.some(f=>f.kind==='deadline'&&f.text.includes('Q3')));
  }
  if(id==='T2') {add('Ambiguous intent',e.status==='ambiguous');add('No invented actionable requirements',e.requirements.length===0);add('Metrics, format, users clarified',/metric/.test(allQuestions)&&/format/.test(allQuestions)&&/user/.test(allQuestions));}
  if(id==='T3') {add('Refresh/call tension flagged',e.issues.some(i=>i.kind==='conflict'));add('Stakeholder clarification',/refresh/.test(allQuestions)&&/(api|calls)/.test(allQuestions)&&result.gaps.questions.length>0);}
  if(id==='T4') {
    const expected=['PDF must include company logo.','CSV must preserve formulas.'];
    const ac=e.requirements.flatMap(r=>r.acceptance_criteria.map(a=>a.text));
    add('Exact required criteria and no extra criteria',expected.every(s=>ac.includes(s))&&ac.every(s=>expected.includes(s)));
    add('Both criteria reach stories',expected.every(s=>result.stories_markdown?.includes(s)));
  }
  if(id==='T5') {add('Insufficient',e.status==='insufficient');add('No invented requirements',e.requirements.length===0);add('Dashboard, real-time, budget gaps',/dashboard/.test(allQuestions)&&/real.time/.test(allQuestions)&&/budget/.test(allQuestions));}
  if(id==='T6') {add('All viewpoints preserved',['Engineering','microservices','Design','single-page','PM','March'].every(s=>text.includes(s)));add('Tension surfaced',e.issues.length>0&&result.gaps.questions.length>0);}
  if(id==='T7') {const nfr=e.requirements.filter(r=>r.kind==='non_functional').map(r=>r.text).join(' ');add('Exact capacity, latency, percentile, API version as NFRs',['10,000','< 200ms','p95','Salesforce REST API v52'].every(s=>nfr.includes(s)));}
  if(id==='T8') {const roles=flatStories.map(s=>s.persona.toLowerCase());add('Separate Admin, End User, Auditor stories',['admin','end user','auditor'].every(role=>roles.some(r=>r===role||r===role+'s')));}
  if(id==='T9') {add('No requirements extractable',e.status==='empty'&&e.requirements.length===0);add('No PRD or stories',result.prd===null&&result.stories===null&&result.prd_markdown===null);}
  if(id==='T10') {add('SSO extracted',e.requirements.some(r=>r.text.includes('SSO')));add('Dependency and owner',e.facts.some(f=>f.kind==='dependency'&&f.text.includes('auth service')&&f.text.includes('Team Alpha')));add('Unknown ETA risk',e.issues.some(i=>i.kind==='risk')&&/eta|unknown|timeline/.test(allQuestions));}
  if(id==='T11') {const headings=fs.readFileSync(path.join(root,'resources/prd_template.md'),'utf8').match(/^## \d+\. .+$/gm);add('All ten template headings',headings.every(h=>result.prd_markdown?.includes(h)));try{core.validatePrd(result.prd,e,result.gaps);add('PRD uses only and all T1 evidence',true);}catch{add('PRD uses only and all T1 evidence',false);}}
  if(id==='T12') {add('Epics and features',result.stories?.epics.length>0&&result.stories.epics.every(ep=>ep.features.length>0));add('Standard stories and priorities',flatStories.length>0&&flatStories.every(s=>s.statement.startsWith('As a ')&&['Must Have','Should Have','Nice to Have'].includes(s.priority)));}
  return checks;
}
const humanChecks={
  T1:'No unsupported requirements, scope, dates, personas or KPIs.',T2:'Questions do not imply invented reporting specifications.',
  T3:'Preserve both positions; do not silently choose polling/WebSockets.',T4:'No added criteria; retain requested CSV semantics and flag uncertainty.',
  T5:'No assumptions promoted to requirements.',T6:'Neutral treatment of all viewpoints; SPA and microservices are not inherently incompatible.',
  T7:'No rounded or changed numeric thresholds; integration version preserved.',T8:'Persona permissions remain distinct without added privileges.',
  T9:'Empty input never yields a PRD.',T10:'Unknown ETA remains a risk; no invented delivery date.',
  T11:'All content derives from T1; Not stated placeholders are acceptable.',T12:'Story benefits and suggested priorities do not invent scope.'};
function checkExtendedCase(item,result) {
  const checks=[];const add=(label,ok)=>checks.push({label,pass:Boolean(ok)});
  const e=result.extraction;add('Pipeline produced extraction without error',!!e&&result.status!=='error');if(!e)return checks;
  try{core.validateExtraction(e,item.documents);core.validateGaps(result.gaps,e);if(result.prd)core.validatePrd(result.prd,e,result.gaps);if(result.stories)core.validateStories(result.stories,e);add('Contracts and source evidence valid',true);}catch{add('Contracts and source evidence valid',false);}
  add('Expected extraction status',e.status===item.expected_status);
  const evidence=[...e.requirements,...e.facts].map(r=>r.text).join(' ');
  add('Required evidence retained',item.required_fragments.every(s=>evidence.includes(s)));
  const requirements=e.requirements.map(r=>r.text).join(' ');
  add('Forbidden content absent from actionable requirements',item.forbidden_requirement_fragments.every(s=>!requirements.toLowerCase().includes(s.toLowerCase())));
  const questions=(result.gaps?.questions||[]).map(q=>q.question+' '+q.rationale).join(' ').toLowerCase();
  if(item.question_fragments_any.length)add('Relevant clarification present',item.question_fragments_any.some(s=>questions.includes(s.toLowerCase())));
  if(item.expected_status!=='sufficient')add('No draft for non-actionable input',result.prd===null&&result.stories===null&&result.prd_markdown===null);
  return checks;
}
async function main(){
  const args=process.argv.slice(2);const live=args.includes('--live');const webhook=args.includes('--webhook');
  const extended=args.includes('--extended');
  const outIndex=args.indexOf('--out');const out=path.resolve(outIndex>=0?args[outIndex+1]:path.join(root,'evaluation',extended?(live?'extended-live-results':'extended-status'):(live?'live-results':'baseline-status')));
  fs.mkdirSync(out,{recursive:true});const cases=extended?JSON.parse(fs.readFileSync(path.join(root,'evaluation/extended-cases.json'),'utf8')).cases:dataset();const reports=[];const outputs={};
  if(live&&!webhook&&!process.env.OPENAI_API_KEY)throw new Error('OPENAI_API_KEY required for --live. No tests were run.');
  if(live&&webhook&&(!process.env.PRD_GENIE_WEBHOOK_URL||!process.env.PRD_GENIE_WEBHOOK_KEY))throw new Error('Webhook URL and key required. No tests were run.');
  for(const item of cases){
    if(!live){reports.push({id:item.id,execution:'NOT_RUN',automated:null,human_review:'PENDING',human_check:item.human_review||humanChecks[item.id],depends_on:item.depends_on||null});continue;}
    let result;
    if(item.depends_on) result=outputs.T1||{status:'error',error:{message:'T1 failed'},extraction:null};
    else {
      const input={documents:item.documents||[{id:item.id,name:item.id,text:item.input}]};
      try {
        if(webhook){const response=await fetch(process.env.PRD_GENIE_WEBHOOK_URL,{method:'POST',headers:{'Content-Type':'application/json','X-PRD-Genie-Key':process.env.PRD_GENIE_WEBHOOK_KEY},body:JSON.stringify(input),signal:AbortSignal.timeout(600000)});
          if(!response.ok)throw new Error(`Webhook HTTP ${response.status}`);result=await response.json();
        }else result=await runPipeline(input);
      }catch(error){result={status:'error',error:{message:error.message},extraction:null};}
    }
    outputs[item.id]=result;fs.writeFileSync(path.join(out,item.id+'.output.json'),JSON.stringify(result,null,2)+'\n');
    let checks;try{checks=extended?checkExtendedCase(item,result):checkCase(item.id,result);}catch(error){checks=[{label:'Evaluation schema error: '+error.message,pass:false}];}
    reports.push({id:item.id,execution:'EXECUTED',automated:checks.every(c=>c.pass)?'PASS':'FAIL',checks,human_review:'PENDING',human_check:item.human_review||humanChecks[item.id],
      trace_id:result.trace_id||null,tracing_status:result.tracing_status||'unavailable',depends_on:item.depends_on,
      note:item.depends_on?'Reuses T1 pipeline artifacts: T11 = PRD generated from T1 extraction; T12 = breakdown from that exact PRD. Not an independent model call.':undefined});
    console.log(item.id+': '+reports.at(-1).automated+'; human review pending');
  }
  fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({generated_at:new Date().toISOString(),suite:extended?'extended_regression':'official_baseline',mode:live?'live':'not_run',reports},null,2)+'\n');
  const table='| Test | Execution | Automated | Human review |\n|---|---|---|---|\n'+reports.map(r=>`| ${r.id} | ${r.execution} | ${r.automated||'-'} | ${r.human_review} |`).join('\n');
  fs.writeFileSync(path.join(out,'results.md'),'# '+(extended?'Extended regression':'Baseline')+' evaluation status\n\n'+(live?'These are automated checks on live outputs. Semantic grounding requires the listed human review.':'No live model or n8n evaluation has been run. Software fixture tests are reported separately.')+'\n\n'+table+'\n\n'+(extended?'E01-E10 are authored additional regression tests, reported separately from the official baseline.':'T11 and T12 use the actual T1 pipeline artifacts, not the literal bracketed text in the input file.')+'\n');
  if(live&&reports.some(r=>r.automated==='FAIL'))process.exitCode=1;
}
if(require.main===module)main().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={dataset,checkCase,checkExtendedCase};
