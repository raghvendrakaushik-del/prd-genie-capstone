"""Build a Groq variant of the same validated stage; uses an existing secret reference."""


def adapt_stage(source):
    source = source.replace('from lfx.io import MessageInput, ModelInput, SecretStrInput, Output',
                            'from lfx.io import MessageInput, StrInput, SecretStrInput, Output\nfrom types import SimpleNamespace')
    source = source.replace('from lfx.base.models.unified_models import get_llm, handle_model_input_update\n', '')
    source = source.replace("        ModelInput(name='model', display_name='Language Model', required=True, real_time_refresh=True),",
                            "        StrInput(name='model_name', display_name='Groq Model', value='openai/gpt-oss-120b', required=True),")
    source = source.replace("SecretStrInput(name='api_key', display_name='API Key Override', required=False, advanced=True,\n                       info='Leave blank to use the configured model provider. Never include keys in source text.')",
                            "SecretStrInput(name='api_key', display_name='Groq API Key', required=True,\n                       info='Select your existing GROQ_API_KEY global variable. Never paste keys into source text.')")
    source = source.replace("    def update_build_config(self, build_config, field_value, field_name=None):\n        return handle_model_input_update(self, build_config, field_value, field_name)\n\n", '')
    begin = source.index('            model = get_llm(')
    end = source.index('        except Exception as exc:', begin)
    source = source[:begin] + '''            from openai import AsyncOpenAI
            key = self.api_key.get_secret_value() if hasattr(self.api_key, 'get_secret_value') else str(self.api_key or '')
            require(bool(key) and key != 'GROQ_API_KEY', 'Configure existing Groq secret')
            async with AsyncOpenAI(api_key=key, base_url='https://api.groq.com/openai/v1', timeout=90, max_retries=2) as client:
                response = await client.chat.completions.create(
                    model=self.model_name, max_completion_tokens=4000,
                    messages=[{'role': 'system', 'content': PROMPTS[stage]},
                              {'role': 'user', 'content': json.dumps({'task': stage, 'source_data': source,
                               **({'template': TEMPLATE} if stage == 'prd' else {})}, ensure_ascii=False)}],
                    response_format={'type': 'json_schema', 'json_schema': {
                        'name': 'prd_genie_' + stage, 'strict': True, 'schema': SCHEMAS[stage]}},
                )
            require(bool(response.choices), 'No Groq response choice')
            choice = response.choices[0]
            require(choice.finish_reason == 'stop', 'Groq response was incomplete or refused')
            require(not getattr(choice.message, 'refusal', None), 'Groq refused input')
            usage = response.usage
            raw = SimpleNamespace(response_metadata={'finish_reason': choice.finish_reason, 'model_name': response.model},
                                  additional_kwargs={}, usage_metadata=None if usage is None else {
                                  'input_tokens': usage.prompt_tokens, 'output_tokens': usage.completion_tokens,
                                  'total_tokens': usage.total_tokens})
            result = {'parsed': json.loads(choice.message.content or ''), 'raw': raw, 'parsing_error': None}
''' + source[end:]
    source = source.replace("'prompt_version': 'v1'}", "'prompt_version': 'v1', 'provider': 'Groq'}")
    return source
