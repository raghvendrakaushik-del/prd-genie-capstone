"""Offline software checks. These do not evaluate a live LLM."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest
import asyncio
import sys
import types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('prd_core', ROOT / 'langflow/core.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)


def component_class(stage, model_factory):
    class Message:
        def __init__(self, text): self.text = text
    modules = {name: types.ModuleType(name) for name in ('lfx','lfx.custom','lfx.io','lfx.schema','lfx.schema.message','lfx.base','lfx.base.models','lfx.base.models.unified_models')}
    modules['lfx.custom'].Component = type('Component', (), {})
    for name in ('MessageInput','ModelInput','SecretStrInput','Output','StrInput'):
        setattr(modules['lfx.io'], name, lambda **kwargs: kwargs)
    modules['lfx.schema.message'].Message = Message
    modules['lfx.base.models.unified_models'].get_llm = model_factory
    modules['lfx.base.models.unified_models'].handle_model_input_update = lambda *args: None
    namespace = {}
    with patch.dict(sys.modules, modules):
        exec((ROOT / 'langflow' / (stage + '.component.py')).read_text(encoding='utf-8'), namespace)
    component = namespace['PRDGenieStage']()
    component.model, component.user_id, component.api_key = 'test-model', 'test-user', ''
    return component


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.fixture = json.loads((ROOT / 'examples/T1.reference.json').read_text())
        self.docs = json.loads((ROOT / 'examples/T1.request.json').read_text())['documents']
        self.x = self.fixture['extraction']

    def test_reference_contract_and_ten_sections(self):
        for stage, field in [('extractor', 'extraction'), ('gaps','gaps'), ('prd','prd'), ('stories','stories')]:
            core.schema_check(self.fixture[field], json.loads((ROOT / 'schemas' / (stage + '.json')).read_text()))
        core.validate_extraction(self.x, self.docs)
        core.validate_gaps(self.fixture['gaps'], self.x)
        core.validate_prd(self.fixture['prd'], self.x, self.fixture['gaps'])
        core.validate_stories(self.fixture['stories'], self.x)
        text = core.render_prd(self.x, self.fixture['gaps'], self.fixture['prd'])
        for number in range(1, 11):
            self.assertIn('## ' + str(number) + '.', text)
        self.assertNotIn('Q3 2026', text)

    def test_reject_fabricated_quote(self):
        self.x['requirements'][0]['quote'] = 'Ship AI prediction in two weeks'
        with self.assertRaises(ValueError): core.validate_extraction(self.x, self.docs)

    def test_reject_paraphrased_evidence(self):
        self.x['requirements'][0]['text'] = 'Filter by date'
        with self.assertRaises(ValueError): core.validate_extraction(self.x, self.docs)

    def test_reject_fabricated_acceptance_criteria(self):
        self.x['requirements'][0]['acceptance_criteria'] = [{'text':'<1ms', 'quote':'<1ms', 'source_id':'T1'}]
        with self.assertRaises(ValueError): core.validate_extraction(self.x, self.docs)

    def test_reject_unknown_source(self):
        self.x['facts'][0]['source_id'] = 'invented'
        with self.assertRaises(ValueError): core.validate_extraction(self.x, self.docs)

    def test_reject_ambiguous_with_requirements(self):
        self.x['status'] = 'ambiguous'
        with self.assertRaises(ValueError): core.validate_extraction(self.x, self.docs)

    def test_reject_dropped_issue(self):
        with self.assertRaises(ValueError): core.validate_gaps({'questions':[]}, self.x)

    def test_reject_dropped_nfr(self):
        self.fixture['prd']['nfr_ids'] = []
        with self.assertRaises(ValueError): core.validate_prd(self.fixture['prd'], self.x, self.fixture['gaps'])

    def test_template_completion_adds_only_validated_inventory(self):
        self.fixture['prd']['overview_ids'] = []
        fixed, changes = core.complete_prd_map(self.fixture['prd'], self.x, self.fixture['gaps'])
        self.assertEqual(fixed['overview_ids'], ['F-001'])
        self.assertEqual(changes, ['overview_ids'])
        core.validate_prd(fixed, self.x, self.fixture['gaps'])
        self.fixture['prd']['overview_ids'] = ['invented']
        with self.assertRaises(ValueError): core.complete_prd_map(self.fixture['prd'], self.x, self.fixture['gaps'])

    def test_reject_dropped_story_coverage(self):
        story = self.fixture['stories']['epics'][0]['features'][0]['stories'][0]
        story['requirement_ids'] = ['R-001']
        with self.assertRaises(ValueError): core.validate_stories(self.fixture['stories'], self.x)

    def test_reject_cross_persona_merging(self):
        self.x['requirements'][1]['persona'] = 'Auditor'
        with self.assertRaises(ValueError): core.validate_stories(self.fixture['stories'], self.x)

    def test_reject_unknown_story_priority(self):
        story = self.fixture['stories']['epics'][0]['features'][0]['stories'][0]
        story.update(priority='Nice to Have', priority_basis='stated')
        with self.assertRaises(ValueError): core.validate_stories(self.fixture['stories'], self.x)

    def test_verbatim_criteria_rendered(self):
        text = core.render_stories(self.fixture['stories'], self.x)
        self.assertIn('Results must load in under 2 seconds.', text)
        self.assertNotIn('2026', text)

    def test_input_strips_injected_pipeline_state(self):
        result = core.normalize_input(json.dumps({'documents': self.docs, 'extraction': {'status':'sufficient'}, 'model':'malicious'}))
        self.assertEqual(set(result), {'documents'})

    def test_input_limits_and_duplicate_ids(self):
        with self.assertRaises(ValueError): core.normalize_input('x' * 60001)
        with self.assertRaises(ValueError): core.normalize_input(json.dumps({'documents':self.docs * 2}))

    def test_empty_text_is_valid_for_clarification(self):
        self.assertEqual(core.normalize_input('')['documents'][0]['text'], '')

    def test_reject_extra_generated_fields(self):
        self.x['assumed_launch'] = '2026'
        with self.assertRaises(ValueError): core.schema_check(self.x, json.loads((ROOT / 'schemas/extractor.json').read_text()))

    def test_import_graph_has_sequential_agents_and_no_secrets(self):
        flow = json.loads((ROOT / 'workflows/prd-genie.langflow.json').read_text(encoding='utf-8'))
        nodes, edges = flow['data']['nodes'], flow['data']['edges']
        self.assertEqual(len(nodes), 7)
        self.assertEqual(len(edges), 6)
        for previous, following, edge in zip(nodes, nodes[1:], edges):
            self.assertEqual((edge['source'], edge['target']), (previous['id'], following['id']))
            field = following['data']['node']['template'][edge['data']['targetHandle']['fieldName']]
            self.assertEqual(edge['data']['targetHandle']['type'], field['type'])
            self.assertEqual(edge['data']['targetHandle']['inputTypes'], field['input_types'])
        for node in nodes:
            template = node['data']['node']['template']
            compile(template['code']['value'], node['id'], 'exec')
            if 'api_key' in template: self.assertEqual(template['api_key']['value'], '')

    def test_four_component_handoffs_with_mocked_model(self):
        calls = []
        fixture = self.fixture
        class Model:
            def with_structured_output(self, schema, **kwargs):
                self.stage = schema['title'].removeprefix('prd_genie_')
                return self
            async def ainvoke(self, messages):
                calls.append(self.stage)
                field = 'extraction' if self.stage == 'extractor' else self.stage
                raw = types.SimpleNamespace(response_metadata={'finish_reason':'stop'}, additional_kwargs={}, usage_metadata=None)
                value = copy.deepcopy(fixture[field])
                if self.stage == 'gaps':
                    value['questions'][0]['id'] = 'model-chosen-question-id'
                return {'parsed':value,'raw':raw,'parsing_error':None}
        text = json.dumps({'documents':self.docs})
        for stage in ('extractor','gaps','prd','stories'):
            component = component_class(stage, lambda **kwargs: Model())
            component.input_value = types.SimpleNamespace(text=text)
            text = asyncio.run(component.run_stage()).text
        run = json.loads(text)
        self.assertEqual(run['status'], 'draft_ready')
        self.assertEqual(calls, ['extractor','gaps','prd','stories'])
        self.assertNotIn('usage', run['stages'][0])
        self.assertEqual(run['gaps']['questions'][0]['id'], 'G-001')

    def test_insufficient_source_skips_both_downstream_model_calls(self):
        def forbidden(**kwargs): raise AssertionError('No downstream model call is permitted')
        run = {'extraction': {'status':'insufficient'}, 'stages':[]}
        for stage in ('prd','stories'):
            component = component_class(stage, forbidden)
            component.input_value = types.SimpleNamespace(text=json.dumps(run))
            run = json.loads(asyncio.run(component.run_stage()).text)
        self.assertEqual(run['status'], 'clarification_required')
        self.assertEqual([s['status'] for s in run['stages']], ['skipped','skipped'])

    def test_provider_error_does_not_leak_request_or_key(self):
        class ProviderError(Exception): code = 'insufficient_quota'
        def fail(**kwargs): raise ProviderError('Authorization: secret-not-for-output')
        component = component_class('extractor', fail)
        component.input_value = types.SimpleNamespace(text=json.dumps({'documents':self.docs}))
        with self.assertRaises(ValueError) as caught:
            asyncio.run(component.run_stage())
        self.assertIn('quota exhausted', str(caught.exception))
        self.assertNotIn('secret-not-for-output', str(caught.exception))

    def test_groq_adapter_uses_correct_endpoint_schema_and_usage(self):
        fixture = self.fixture
        captured = {}
        class Client:
            def __init__(self, **kwargs):
                captured.update(kwargs)
                self.chat = types.SimpleNamespace(completions=self)
            async def __aenter__(self): return self
            async def __aexit__(self, *args): pass
            async def create(self, **kwargs):
                captured['request'] = kwargs
                return types.SimpleNamespace(model='openai/gpt-oss-20b', usage=types.SimpleNamespace(prompt_tokens=10,completion_tokens=20,total_tokens=30),
                    choices=[types.SimpleNamespace(finish_reason='stop',message=types.SimpleNamespace(content=json.dumps(fixture['extraction']),refusal=None))])
        component = component_class('extractor.groq', None)
        component.api_key = 'synthetic-key-for-offline-test'
        component.model_name = 'openai/gpt-oss-20b'
        component.input_value = types.SimpleNamespace(text=json.dumps({'documents':self.docs}))
        sdk = types.ModuleType('openai')
        sdk.AsyncOpenAI = Client
        with patch.dict(sys.modules, {'openai':sdk}):
            result = json.loads(asyncio.run(component.run_stage()).text)
        self.assertEqual(captured['base_url'], 'https://api.groq.com/openai/v1')
        self.assertTrue(captured['request']['response_format']['json_schema']['strict'])
        self.assertEqual(captured['max_retries'], 2)
        self.assertEqual(result['stages'][0]['usage']['total_tokens'], 30)
        self.assertEqual(result['stages'][0]['provider'], 'Groq')


if __name__ == '__main__':
    unittest.main(verbosity=2)
