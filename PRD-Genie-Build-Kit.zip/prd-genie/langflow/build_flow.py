from pathlib import Path
import json
import copy
import sys
from groq_adapter import adapt_stage

groq = '--groq' in sys.argv

root = Path(__file__).resolve().parent.parent
lf = root / 'langflow'
stock = {'data': {'nodes': json.loads((lf / 'node_templates.json').read_text(encoding='utf-8'))}}
assets = 'SCHEMAS = ' + repr({s: json.loads((root / 'schemas' / (s + '.json')).read_text()) for s in ('extractor','gaps','prd','stories')}) + '\n'
assets += 'PROMPTS = ' + repr({s: (root / 'prompts' / (s + '.md')).read_text(encoding='utf-8') for s in ('extractor','gaps','prd','stories')}) + '\n'
assets += 'TEMPLATE = ' + repr((root / 'resources/prd_template.md').read_text(encoding='utf-8-sig')) + '\n'
core = (lf / 'core.py').read_text(encoding='utf-8')
stage_source = (lf / 'stage_component.py').read_text(encoding='utf-8')
if groq:
    stage_source = adapt_stage(stage_source)
model_template = next(n for n in stock['data']['nodes'] if n['data']['type'] == 'LanguageModelComponent')['data']['node']['template']
nodes = []

def stock_node(kind, suffix, x):
    n = copy.deepcopy(next(n for n in stock['data']['nodes'] if n['data']['type'] == kind))
    n['id'] = n['data']['id'] = kind + '-' + suffix
    n['position'] = {'x': x, 'y': 0}
    n['selected'] = False
    n.pop('measured', None)
    n['data']['node']['frozen'] = False
    t = n['data']['node']['template']
    for k in list(t):
        if k.startswith('_frontend'):
            del t[k]
    return n

start = stock_node('ChatInput', 'PRDSource', 0)
start['data']['node']['template']['input_value']['value'] = ''
nodes.append(start)

def component(kind, suffix, title, code, template, index):
    template = copy.deepcopy(template)
    template['_type'] = 'Component'
    template['code'] = dict(model_template['code'], value=code)
    name = kind + '-' + suffix
    out = {'allows_loop': False, 'cache': True, 'display_name': 'Validated handoff' if kind == 'PRDGenieStage' else 'Result',
           'group_outputs': False, 'method': 'run_stage' if kind == 'PRDGenieStage' else 'format_output',
           'name': 'message', 'selected': 'Message', 'tool_mode': False, 'types': ['Message'], 'value': '__UNDEFINED__'}
    data = {'base_classes': ['Message'], 'display_name': title, 'description': 'PRD Genie: source-grounded sequential pipeline',
            'custom_fields': {}, 'field_order': [k for k in template if not k.startswith('_') and k != 'code'],
            'icon': 'BrainCircuit' if kind == 'PRDGenieStage' else 'FileText', 'edited': True, 'frozen': False,
            'outputs': [out], 'template': template, 'lf_version': '1.10.0', 'legacy': False, 'beta': False,
            'conditional_paths': [], 'metadata': {}, 'output_types': []}
    return {'id': name, 'type': 'genericNode', 'position': {'x': index * 370, 'y': 0}, 'selected': False,
            'data': {'id': name, 'type': kind, 'node': data, 'display_name': title, 'description': data['description']}}

for index, (stage, title) in enumerate([('extractor','1. Requirement Extractor'), ('gaps','2. Gap Analyzer'), ('prd','3. PRD Generator'), ('stories','4. Story Builder')], 1):
    code = assets + '\n' + core + '\nSTAGE = ' + repr(stage) + '\n' + stage_source.replace("display_name = 'PRD Genie Agent'", 'display_name = ' + repr(title))
    compile(code, '<' + stage + '>', 'exec')
    (lf / (stage + ('.groq' if groq else '') + '.component.py')).write_text(code, encoding='utf-8')
    template = {k: copy.deepcopy(model_template[k]) for k in ('input_value','model','api_key')}
    template['input_value']['required'] = True
    if groq:
        del template['model']
        template['api_key'].update(value='GROQ_API_KEY', load_from_db=True, display_name='Groq API Key', required=True, advanced=False)
        template['model_name'] = {'_input_type':'StrInput', 'type':'str', 'name':'model_name', 'display_name':'Groq Model',
                                  'value':'openai/gpt-oss-120b', 'show':True, 'required':True, 'advanced':False}
    nodes.append(component('PRDGenieStage', stage, title, code, template, index))

format_code = (lf / 'format_component.py').read_text(encoding='utf-8')
template = {'input_value': copy.deepcopy(model_template['input_value']),
            'output_format': {'_input_type': 'DropdownInput', 'name': 'output_format', 'display_name': 'Output format',
                              'type': 'str', 'value': 'Readable', 'options': ['Readable','JSON'], 'advanced': False,
                              'show': True, 'required': False, 'dynamic': False}}
nodes.append(component('PRDGenieOutput', 'Result', '5. Reviewable Output', format_code, template, 5))
nodes.append(stock_node('ChatOutput', 'PRDResult', 6 * 370))
edges = []
for previous, following in zip(nodes, nodes[1:]):
    sh = {'dataType': previous['data']['type'], 'id': previous['id'], 'name': 'message', 'output_types': ['Message']}
    th = {'fieldName': 'input_value', 'id': following['id'], 'inputTypes': ['Data','JSON','DataFrame','Table','Message'] if following['data']['type']=='ChatOutput' else ['Message'], 'type': 'str'}
    edges.append({'id': previous['id'] + '-to-' + following['id'], 'source': previous['id'], 'target': following['id'],
                  'sourceHandle': json.dumps(sh).replace('"','œ'), 'targetHandle': json.dumps(th).replace('"','œ'),
                  'data': {'sourceHandle': sh, 'targetHandle': th}, 'animated': False, 'selected': False})
flow = {'name': 'PRD Genie - Evidence Grounded Pipeline', 'description': 'Four specialist agents: extract requirements, analyze gaps, map PRD, and build stories. JSON schemas, source quotations, coverage checks, and insufficient-input gates. PM approval required.',
        'icon': 'FileText', 'is_component': False, 'access_type': 'PRIVATE', 'data': {'nodes': nodes, 'edges': edges, 'viewport': {'x': 30, 'y': 100, 'zoom': 0.6}}}
if groq:
    flow['name'] = 'PRD Genie - Groq Evidence Pipeline'
target = root / ('workflows/prd-genie.groq.langflow.json' if groq else 'workflows/prd-genie.langflow.json')
target.write_text(json.dumps(flow, indent=2, ensure_ascii=False), encoding='utf-8')
print('Created', target, 'with', len(nodes), 'nodes and', len(edges), 'edges; no credentials embedded.')
