import json
from lfx.custom import Component
from lfx.io import MessageInput, DropdownInput, Output
from lfx.schema.message import Message


class PRDGenieOutput(Component):
    display_name = 'PRD Genie Output'
    description = 'Readable draft or full JSON evidence and run metrics. Review before approval.'
    icon = 'FileText'
    name = 'PRDGenieOutput'
    inputs = [MessageInput(name='input_value', display_name='Validated result', required=True),
              DropdownInput(name='output_format', display_name='Output format', options=['Readable', 'JSON'], value='Readable')]
    outputs = [Output(display_name='Result', name='message', method='format_output')]

    def format_output(self) -> Message:
        value = self.input_value.text if hasattr(self.input_value, 'text') else str(self.input_value)
        run = json.loads(value)
        if self.output_format == 'JSON':
            return Message(text=json.dumps(run, indent=2, ensure_ascii=False))
        if run['status'] == 'clarification_required':
            text = '# Clarification required\n\nThe supplied material does not support a PRD yet.\n\n'
            text += '\n'.join('- **' + q['id'] + ':** ' + q['question'] for q in run['gaps']['questions'])
        else:
            text = run['prd_markdown'] + '\n\n---\n\n' + run['stories_markdown']
        text += '\n\n---\n\nRun: ' + run['run_id'] + '\n\n| Agent | Status | Latency ms | Input tokens | Output tokens |\n|---|---|---|---|---|\n'
        for stage in run['stages']:
            usage = stage.get('usage', {})
            text += '| ' + ' | '.join(str(x) for x in [stage['name'], stage['status'], stage.get('latency_ms', '-'), usage.get('input_tokens', 'Not reported'), usage.get('output_tokens', 'Not reported')]) + ' |\n'
        text += '\nDraft only. Semantic completeness, source conflicts, and suggested priorities need PM review.'
        return Message(text=text)
