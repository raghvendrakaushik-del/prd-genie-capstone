# Build script prepends reviewed prompts, JSON schemas and core.py to this file.
import time
import uuid
from copy import deepcopy
from lfx.custom import Component
from lfx.io import MessageInput, ModelInput, SecretStrInput, Output
from lfx.schema.message import Message
from lfx.base.models.unified_models import get_llm, handle_model_input_update


class PRDGenieStage(Component):
    display_name = 'PRD Genie Agent'
    description = 'Schema-constrained specialist with exact source quotation and coverage checks.'
    icon = 'BrainCircuit'
    name = 'PRDGenieStage'
    inputs = [
        MessageInput(name='input_value', display_name='Source / validated handoff', required=True),
        ModelInput(name='model', display_name='Language Model', required=True, real_time_refresh=True),
        SecretStrInput(name='api_key', display_name='API Key Override', required=False, advanced=True,
                       info='Leave blank to use the configured model provider. Never include keys in source text.'),
    ]
    outputs = [Output(display_name='Validated handoff', name='message', method='run_stage')]

    def update_build_config(self, build_config, field_value, field_name=None):
        return handle_model_input_update(self, build_config, field_value, field_name)

    async def run_stage(self) -> Message:
        stage = STAGE
        incoming = self.input_value.text if hasattr(self.input_value, 'text') else str(self.input_value)
        if stage == 'extractor':
            run = dict(normalize_input(incoming), run_id=str(uuid.uuid4()), stages=[], status='running')
        else:
            run = json.loads(incoming)
        # No inference or model call downstream of insufficient input.
        if stage in ('prd', 'stories') and run['extraction']['status'] != 'sufficient':
            run['status'] = 'clarification_required'
            run['stages'].append({'name': stage, 'status': 'skipped', 'reason': 'insufficient_source'})
            return Message(text=json.dumps(run, ensure_ascii=False))
        source = {'documents': run['documents']} if stage == 'extractor' else {
            'extraction': run['extraction'],
            **({'gaps': run['gaps']} if stage in ('prd', 'stories') else {}),
            **({'prd': run['prd']} if stage == 'stories' else {}),
        }
        if stage == 'prd':
            source['required_section_ids'] = canonical_prd_map(run['extraction'], run['gaps'])
        schema = dict(SCHEMAS[stage], title='prd_genie_' + stage, description='Validated ' + stage + ' output')
        started = time.time()
        try:
            model = get_llm(model=self.model, user_id=self.user_id, api_key=self.api_key,
                            temperature=None, stream=False, max_tokens=8000)
            structured = model.with_structured_output(schema, method='json_schema', strict=True, include_raw=True)
            result = await structured.ainvoke([
                ('system', PROMPTS[stage]),
                ('human', json.dumps({'task': stage, 'source_data': source,
                                     **({'template': TEMPLATE} if stage == 'prd' else {})}, ensure_ascii=False)),
            ])
        except Exception as exc:
            # Provider errors can include request headers; do not copy their bodies into artifacts.
            provider_code = getattr(exc, 'code', None)
            category = 'quota exhausted; check API billing' if provider_code == 'insufficient_quota' else 'temporary rate limit; retry later' if provider_code == 'rate_limit_exceeded' else 'check provider connection and quota'
            raise ValueError(stage + ' model call failed: ' + type(exc).__name__ + '; ' + category + '.') from None
        require(not result.get('parsing_error'), stage + ' returned invalid structured output')
        value, raw = result.get('parsed'), result.get('raw')
        require(value is not None, stage + ' returned no parsed output (possible refusal)')
        meta = getattr(raw, 'response_metadata', {}) or {}
        require(meta.get('finish_reason') not in ('length', 'content_filter'), stage + ' output was incomplete')
        require(not (getattr(raw, 'additional_kwargs', {}) or {}).get('refusal'), 'Model refused input')
        schema_check(value, SCHEMAS[stage])
        if stage == 'extractor':
            validate_extraction(value, run['documents'])
            run['extraction'] = value
        elif stage == 'gaps':
            # Question identifiers are workflow metadata, not source evidence.
            for index, question in enumerate(value['questions'], 1):
                question['id'] = f'G-{index:03d}'
            validate_gaps(value, run['extraction'])
            run['gaps'] = value
        elif stage == 'prd':
            value, corrections = complete_prd_map(value, run['extraction'], run['gaps'])
            run['template_coverage_corrections'] = corrections
            validate_prd(value, run['extraction'], run['gaps'])
            run['prd'] = value
            run['prd_markdown'] = render_prd(run['extraction'], run['gaps'], value)
        else:
            validate_stories(value, run['extraction'])
            run['stories'] = value
            run['stories_markdown'] = render_stories(value, run['extraction'])
            run['status'] = 'draft_ready'
        usage = getattr(raw, 'usage_metadata', None)
        stage_log = {'name': stage, 'status': 'validated', 'latency_ms': round((time.time() - started) * 1000),
                     'model': meta.get('model_name', 'configured_model'), 'prompt_version': 'v1'}
        if usage:
            stage_log['usage'] = {k: usage[k] for k in ('input_tokens', 'output_tokens', 'total_tokens') if k in usage}
        run['stages'].append(stage_log)
        self.status = stage + ': validated'
        return Message(text=json.dumps(run, ensure_ascii=False))
