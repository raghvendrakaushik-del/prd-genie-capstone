"""Dependency-free evidence checks for the Langflow pipeline. No model calls here."""
import json
import re


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique(values, label):
    require(len(values) == len(set(values)), 'Duplicate ' + label)


def schema_check(value, schema):
    if 'anyOf' in schema:
        for option in schema['anyOf']:
            try:
                schema_check(value, option)
                return
            except ValueError:
                pass
        raise ValueError('Invalid nullable value')
    kind = schema['type']
    expected = {'object': dict, 'array': list, 'string': str, 'null': type(None)}[kind]
    require(isinstance(value, expected), 'Expected ' + kind)
    if kind == 'object':
        require(set(value) == set(schema['properties']), 'Missing or unexpected fields')
        for key, child in schema['properties'].items():
            schema_check(value[key], child)
    elif kind == 'array':
        for item in value:
            schema_check(item, schema['items'])
    if 'enum' in schema:
        require(value in schema['enum'], 'Invalid enum')


def normalize_input(text):
    # Plain text is one document; a leading JSON object must be valid input JSON.
    if text.lstrip().startswith('{'):
        value = json.loads(text)
    else:
        value = {'documents': [{'id': 'source-1', 'name': 'Product input', 'text': text}]}
    require(isinstance(value, dict), 'Input must be an object')
    docs = value.get('documents')
    require(isinstance(docs, list) and 1 <= len(docs) <= 10, 'Provide 1-10 documents')
    for doc in docs:
        require(isinstance(doc, dict), 'Invalid document')
        require(isinstance(doc.get('id'), str) and re.fullmatch(r'[A-Za-z0-9_-]{1,64}', doc['id']), 'Invalid document ID')
        require(isinstance(doc.get('name'), str) and len(doc['name']) <= 200, 'Invalid document name')
        require(isinstance(doc.get('text'), str), 'Document text must be a string')
    unique([d['id'] for d in docs], 'document IDs')
    require(sum(len(d['text']) for d in docs) <= 60000, 'Input exceeds 60,000 characters')
    return {'documents': [{k: d[k] for k in ('id', 'name', 'text')} for d in docs]}


def evidence(item, docs):
    doc = next((d for d in docs if d['id'] == item['source_id']), None)
    require(doc is not None and item['quote'].strip() and item['quote'] in doc['text'], 'Unsupported source quote')
    require(item['text'] == item['quote'], 'Evidence wording changed')


def validate_extraction(x, docs):
    unique([v['id'] for k in ('requirements', 'facts', 'issues') for v in x[k]], 'evidence IDs')
    for r in x['requirements']:
        require(re.fullmatch(r'R-\d{3,}', r['id']), 'Invalid requirement ID')
        evidence(r, docs)
        for ac in r['acceptance_criteria']:
            evidence(ac, docs)
        if r['persona'] is not None:
            require(any(r['persona'].lower() in d['text'].lower() for d in docs), 'Unsupported persona')
    for f in x['facts']:
        require(re.fullmatch(r'F-\d{3,}', f['id']), 'Invalid fact ID')
        evidence(f, docs)
    for i in x['issues']:
        require(re.fullmatch(r'I-\d{3,}', i['id']), 'Invalid issue ID')
        require(i['question'].strip(), 'Issue needs question')
        require(set(i['requirement_ids']) <= {r['id'] for r in x['requirements']}, 'Unknown issue requirement')
        require(set(i['source_ids']) <= {d['id'] for d in docs}, 'Unknown issue source')
    require((x['status'] == 'sufficient') == bool(x['requirements']), 'Only sufficient inputs may have actionable requirements')


def validate_gaps(g, x):
    require(x['status'] == 'sufficient' or g['questions'], 'Clarification required')
    unique([q['id'] for q in g['questions']], 'gap IDs')
    known = {v['id'] for k in ('requirements', 'facts', 'issues') for v in x[k]}
    for q in g['questions']:
        require(re.fullmatch(r'G-\d{3,}', q['id']), 'Invalid gap ID')
        require(q['question'].strip() and q['rationale'].strip(), 'Empty clarification')
        require(set(q['evidence_ids']) <= known, 'Unknown gap evidence')
    for issue in x['issues']:
        require(any(issue['id'] in q['evidence_ids'] for q in g['questions']), 'Gap analyzer dropped issue ' + issue['id'])


def same(actual, expected, label):
    unique(actual, label)
    require(set(actual) == set(expected), 'Incomplete or invalid ' + label)


def canonical_prd_map(x, g):
    mapping = {'overview_ids': ['product_name', 'context', 'decision', 'stakeholder'], 'goal_ids': ['goal'],
               'persona_ids': ['persona'], 'out_of_scope_ids': ['out_of_scope'], 'dependency_ids': ['dependency'],
               'assumption_ids': ['assumption'], 'deadline_ids': ['deadline']}
    result = {key: [f['id'] for f in x['facts'] if f['kind'] in kinds] for key, kinds in mapping.items()}
    for key, kind in [('functional_ids','functional'),('nfr_ids','non_functional'),('constraint_ids','constraint')]:
        result[key] = [r['id'] for r in x['requirements'] if r['kind'] == kind]
    result['criteria_requirement_ids'] = [r['id'] for r in x['requirements'] if r['acceptance_criteria']]
    result['question_ids'] = [q['id'] for q in g['questions']]
    return result


def complete_prd_map(proposed, x, g):
    expected = canonical_prd_map(x, g)
    known = {i for ids in expected.values() for i in ids}
    require(all(i in known for ids in proposed.values() for i in ids), 'PRD proposed unknown evidence ID')
    result = {}
    for key, ids in expected.items():
        result[key] = list(dict.fromkeys([i for i in proposed[key] if i in ids] + ids))
    corrections = [key for key in expected if proposed[key] != result[key]]
    return result, corrections


def validate_prd(p, x, g):
    require(x['status'] == 'sufficient', 'No PRD for insufficient inputs')
    for key, kind in [('functional_ids', 'functional'), ('nfr_ids', 'non_functional'), ('constraint_ids', 'constraint')]:
        same(p[key], [r['id'] for r in x['requirements'] if r['kind'] == kind], key)
    same(p['criteria_requirement_ids'], [r['id'] for r in x['requirements'] if r['acceptance_criteria']], 'criteria coverage')
    mapping = {'overview_ids': ['product_name', 'context', 'decision', 'stakeholder'], 'goal_ids': ['goal'],
               'persona_ids': ['persona'], 'out_of_scope_ids': ['out_of_scope'], 'dependency_ids': ['dependency'],
               'assumption_ids': ['assumption'], 'deadline_ids': ['deadline']}
    for key, kinds in mapping.items():
        same(p[key], [f['id'] for f in x['facts'] if f['kind'] in kinds], key)
    same(p['question_ids'], [q['id'] for q in g['questions']], 'question coverage')


def validate_stories(s, x):
    reqs = {r['id']: r for r in x['requirements']}
    covered, ids = set(), []
    require(s['epics'], 'At least one epic required')
    for e in s['epics']:
        ids.append(e['id'])
        require(e['features'], 'Epic needs features')
        for f in e['features']:
            ids.append(f['id'])
            require(f['requirement_ids'] and f['stories'], 'Feature needs requirements and stories')
            require(set(f['requirement_ids']) <= set(reqs), 'Unknown feature reference')
            for story in f['stories']:
                ids.append(story['id'])
                require(story['statement'].startswith('As a ' + story['persona']) and 'I want' in story['statement'] and 'so that' in story['statement'], 'Invalid story format')
                require(story['requirement_ids'] and set(story['requirement_ids']) <= set(f['requirement_ids']), 'Invalid story references')
                linked = [reqs[rid] for rid in story['requirement_ids']]
                if story['persona_basis'] == 'stated':
                    require(any((r['persona'] or '').lower() == story['persona'].lower() for r in linked), 'Unsupported story persona')
                else:
                    require(story['persona'] == 'user', 'Generic persona must be user')
                if story['priority_basis'] == 'stated':
                    require(any(r['priority'] == story['priority'] for r in linked), 'Unsupported stated priority')
                for r in linked:
                    if r['persona']:
                        require(r['persona'].lower() == story['persona'].lower(), 'Keep different personas in separate stories')
                covered.update(story['requirement_ids'])
            same(list(set(rid for story in f['stories'] for rid in story['requirement_ids'])), list(set(f['requirement_ids'])), 'feature coverage')
    unique(ids, 'epic/feature/story IDs')
    require(covered == set(reqs), 'Story coverage incomplete')


def esc(text):
    return re.sub(r'[\r\n]+', ' ', str(text)).replace('|', '\\|').replace('<', '&lt;').replace('>', '&gt;')


def render_prd(x, g, p):
    validate_prd(p, x, g)
    lookup = {v['id']: v for k in ('requirements', 'facts') for v in x[k]}
    def bullets(key):
        return '\n'.join('- ' + esc(lookup[i]['text']) + ' [' + i + '; ' + esc(lookup[i]['source_id']) + ']' for i in p[key]) or '- Not stated.'
    lines = ['# Product Requirements Document (PRD)', '> AI-generated draft. PM review required. Exact quote matching does not prove completeness or correct interpretation.',
             '## 1. Product Overview', '**Version:** 0.1 draft | **Author:** PRD Genie | **Date:** Not assigned', bullets('overview_ids'),
             '## 2. Goals and Objectives', bullets('goal_ids'), '## 3. User Personas', bullets('persona_ids'),
             '## 4. Feature Requirements', '### 4.1 Functional Requirements', '| ID | Requirement | Priority | Source |\n|---|---|---|---|']
    lines.append('\n'.join('| ' + ' | '.join([r['id'], esc(r['text']), r['priority'] or 'Not stated', esc(r['source_id'])]) + ' |' for r in [lookup[i] for i in p['functional_ids']]) or '| - | Not stated | - | - |')
    lines += ['### 4.2 Non-Functional Requirements', '| ID | Requirement | Category | Target |\n|---|---|---|---|']
    lines.append('\n'.join('| ' + ' | '.join([r['id'], esc(r['text']) + ' [' + esc(r['source_id']) + ']', esc(r['category']), 'See exact requirement wording']) + ' |' for r in [lookup[i] for i in p['nfr_ids']]) or '| - | Not stated | - | - |')
    lines += ['### 4.3 Stated Constraints', bullets('constraint_ids'), '## 5. Acceptance Criteria']
    lines.append('\n'.join('- **' + i + ':**\n' + '\n'.join('  - [ ] ' + esc(ac['text']) + ' [' + esc(ac['source_id']) + ']' for ac in lookup[i]['acceptance_criteria']) for i in p['criteria_requirement_ids']) or '- Not stated; clarification required.')
    for title, key in [('6. Out of Scope', 'out_of_scope_ids'), ('7. Dependencies', 'dependency_ids'), ('8. Assumptions', 'assumption_ids')]:
        lines += ['## ' + title, bullets(key)]
    lines += ['## 9. Open Questions', render_gaps(g), '## 10. Timeline', 'Stated timing is preserved without inferring a year. Other milestones: Not stated.', bullets('deadline_ids')]
    return '\n\n'.join(lines).replace('|\n\n|', '|\n|')


def render_gaps(g):
    return '\n'.join('- **' + q['id'] + ' (' + q['severity'] + '; open):** ' + esc(q['question']) + ' Suggested owner: ' + esc(q['suggested_owner']) + '. Evidence: ' + (', '.join(q['evidence_ids']) or 'Missing source information') for q in g['questions']) or '- No further questions identified; PM review required.'


def render_stories(s, x):
    validate_stories(s, x)
    reqs = {r['id']: r for r in x['requirements']}
    lines = ['# Epics, Features and User Stories', '> Generated wording and suggested priorities need PM review.']
    for e in s['epics']:
        lines.append('## ' + esc(e['id']) + ': ' + esc(e['title']))
        for f in e['features']:
            lines.append('### ' + esc(f['id']) + ': ' + esc(f['title']))
            for story in f['stories']:
                lines += ['**' + esc(story['id']) + '** ' + esc(story['statement']),
                          '- Persona basis: ' + story['persona_basis'] + '\n- Priority: ' + story['priority'] + ' (' + story['priority_basis'] + ')\n- Requirements: ' + ', '.join(story['requirement_ids'])]
                criteria = {(ac['source_id'], ac['text']) for rid in story['requirement_ids'] for ac in reqs[rid]['acceptance_criteria']}
                lines.append('Acceptance criteria (source wording):\n' + ('\n'.join('- [ ] ' + esc(t) + ' [' + esc(src) + ']' for src, t in sorted(criteria)) or '- Not stated; clarification required.'))
    return '\n\n'.join(lines)
