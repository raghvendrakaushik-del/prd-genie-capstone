# Enhanced PRD review template

Design reference derived from the supplied ten-section template. This is an optional richer review format; the current executable renderer retains the original ten headings and already includes source links and explicit unknowns. It does not yet populate every extra field below automatically.

> Status: Draft. Reviewer: Not assigned. Review date: Not assigned.
> Product/scope identifier: Not stated. Source versions: Not stated.
> Distinguish stated requirements, approved changes, proposals and open questions.

## 1. Product Overview
- Product name, document version, author, date and approval status.
- Problem and intended users, with evidence references.
- Source register: document ID, name, version/date, source owner if stated.

## 2. Goals and Objectives
| Goal | Business/user | Metric | Baseline | Target | Measurement owner | Evidence |
|---|---|---|---|---|---|---|
| Not stated | Not stated | Not stated | Not stated | Not stated | Not stated | - |

## 3. User Personas
| Persona | Need | Current workaround | Permissions | Evidence |
|---|---|---|---|---|
| Not stated | Not stated | Not stated | Not stated | - |

## 4. Feature Requirements

### 4.1 Functional Requirements
| ID | Requirement | Must/Should/Nice | Priority basis | State | Exact quote | Source |
|---|---|---|---|---|---|---|
| FR-001 | Not stated | Not stated | Stated/suggested | Stated/proposed/approved | Not stated | - |

### 4.2 Non-Functional Requirements
| ID | Requirement | Category | Exact target | Conditions/workload | Evidence |
|---|---|---|---|---|---|
| NFR-001 | Not stated | Not stated | Not stated | Not stated | - |

### 4.3 API / Integration Contract (when present in source)
| Operation | Request/identity fields | Response/status | Errors | Version/dependency | Unresolved decision |
|---|---|---|---|---|---|
| Not stated | Not stated | Not stated | Not stated | Not stated | Not stated |

## 5. Acceptance Criteria
| Requirement ID | Exact source criterion | Evidence | Review state |
|---|---|---|---|
| Not stated | Not stated; do not invent | - | Pending |

Derived test ideas belong in a separately labeled proposal, never in the source's verbatim criterion list.

## 6. Out of Scope
- Explicit exclusions with source evidence.
- Separate requested future opportunities from approved scope.

## 7. Dependencies
| Dependency | Owner | Status | ETA | Risk | Evidence |
|---|---|---|---|---|---|
| Not stated | Not stated | Not stated | Unknown | Not assessed | - |

## 8. Assumptions
- Stated assumptions with evidence.
- Suggested assumptions require explicit review and must not be treated as approved requirements.

## 9. Open Questions
| ID | Question / conflicting positions | Why it matters | Suggested owner | Severity | Status |
|---|---|---|---|---|---|
| G-001 | Not stated | Not stated | Unassigned | Not assessed | Open |

### Decision register
| Decision | Exact approval evidence | Decision-maker | Date/version | Supersedes |
|---|---|---|---|---|
| Not stated | Not stated | Not stated | Not stated | Not stated |

## 10. Timeline
| Milestone | Target date as stated | Commitment/target/proposal | Dependency | Evidence |
|---|---|---|---|---|
| Not stated | Not stated | Not stated | Not stated | - |

Do not infer a year, convert a sprint count into dates, or promote a prototype date to launch without evidence.
