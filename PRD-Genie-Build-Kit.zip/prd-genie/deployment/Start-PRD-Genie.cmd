@echo off
setlocal
where docker >nul 2>&1
if errorlevel 1 (
  echo Docker was not found. Open Docker Desktop or check its installation.
  pause
  exit /b 1
)
docker info --format "{{.ServerVersion}}" >nul 2>&1
if errorlevel 1 (
  echo Docker is not accessible. Open Docker Desktop and wait until its engine is running.
  echo Then run this launcher again from your normal Windows session.
  pause
  exit /b 1
)
docker compose -f "%~dp0compose.yaml" up -d
if errorlevel 1 (
  echo n8n could not start. Review the Docker error above.
  echo If port 5678 is in use, do not stop an unknown application; check the setup guide.
  pause
  exit /b 1
)
echo.
echo n8n is starting at http://localhost:5678
echo First startup may take a minute after the image download finishes.
echo Complete the local owner-account setup in your browser, then tell Codex it is ready.
echo Workflows and credentials persist in the dedicated prd-genie-local Docker volume.
start "" "http://localhost:5678"
pause
