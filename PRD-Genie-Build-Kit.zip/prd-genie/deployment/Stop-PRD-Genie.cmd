@echo off
setlocal
docker compose -f "%~dp0compose.yaml" stop
if errorlevel 1 (
  echo Unable to stop PRD Genie's local service. Review the error above.
  pause
  exit /b 1
)
echo PRD Genie's local service is stopped. Its saved workflows and credentials are retained.
pause
