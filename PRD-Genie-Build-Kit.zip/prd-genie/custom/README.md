# Original sample project: RelayOps

These are **synthetic inputs authored for this project**, not real customer documents or live model outputs. They exercise PRD Genie on an API-oriented product: a console for investigating and replaying failed webhooks.

Use these three related documents together:

1. `relayops_product_brief.txt`: purpose, three personas, API behavior, performance target, dependencies and exclusions.
2. `relayops_meeting_transcript.txt`: disagreements, explicit accepted changes and unresolved questions.
3. `relayops_stakeholder_notes.txt`: follow-ups, unapproved expansion requests and a dependency without an ETA.

The combined API request is `examples/relayops.request.json`. Run `relayops_incomplete_notes.txt` separately to test abstention; combining it with the full brief would remove the intended insufficient-input condition.

The [expert reference review](relayops_expected_review.md) is an authored review aid. It shows what a good interpretation should retain and question. It is not a claim that the implemented model pipeline has produced or passed this sample.

## Enhancements over the original examples

| Improvement | Why it matters |
|---|---|
| Explicit product and document identifiers | Tests related-document assembly without merging unrelated meetings |
| Three distinct roles and permissions | Tests persona preservation and authorization scope |
| Exact API statuses and idempotency window | Tests numeric/contract fidelity beyond reporting keywords |
| Performance workload and percentile | Prevents an isolated latency number being treated as a complete target |
| Accepted decision versus proposal | Tests whether the system distinguishes agreement from requests |
| 30-day history versus 90-day retention | Tests similar numbers with different meanings |
| Current pilot versus future opportunity | Prevents a requested bulk feature leaking into committed scope |
| Dependency ETA missing despite a target date | Tests whether a date is incorrectly treated as a guaranteed plan |
| Stated baseline versus measured implementation result | Tests faithful documentation without claiming PRD Genie achieved the goal |
| Separate incomplete-input scenario | Demonstrates clarification instead of filling gaps |

The original resources and T1-T12 remain unchanged. `resources/prd_template.enhanced.md` is a design reference for richer reviews while keeping the original ten-section structure. `evaluation/extended-cases.json` adds ten independent regression cases (E01-E10); their results remain separate from the capstone baseline.
