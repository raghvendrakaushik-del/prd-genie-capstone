# Baseline evaluation status

No live model or n8n evaluation has been run. Software fixture tests are reported separately.

| Test | Execution | Automated | Human review |
|---|---|---|---|
| T1 | NOT_RUN | - | PENDING |
| T2 | NOT_RUN | - | PENDING |
| T3 | NOT_RUN | - | PENDING |
| T4 | NOT_RUN | - | PENDING |
| T5 | NOT_RUN | - | PENDING |
| T6 | NOT_RUN | - | PENDING |
| T7 | NOT_RUN | - | PENDING |
| T8 | NOT_RUN | - | PENDING |
| T9 | NOT_RUN | - | PENDING |
| T10 | NOT_RUN | - | PENDING |
| T11 | NOT_RUN | - | PENDING |
| T12 | NOT_RUN | - | PENDING |

T11 and T12 use the actual T1 pipeline artifacts, not the literal bracketed text in the input file.
