# Extended regression evaluation status

No live model or n8n evaluation has been run. Software fixture tests are reported separately.

| Test | Execution | Automated | Human review |
|---|---|---|---|
| E01 | NOT_RUN | - | PENDING |
| E02 | NOT_RUN | - | PENDING |
| E03 | NOT_RUN | - | PENDING |
| E04 | NOT_RUN | - | PENDING |
| E05 | NOT_RUN | - | PENDING |
| E06 | NOT_RUN | - | PENDING |
| E07 | NOT_RUN | - | PENDING |
| E08 | NOT_RUN | - | PENDING |
| E09 | NOT_RUN | - | PENDING |
| E10 | NOT_RUN | - | PENDING |

E01-E10 are authored additional regression tests, reported separately from the official baseline.
