"""Explicit training lifecycle. Merely running validation never starts a paid job."""
import argparse,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'fine-tuning'
parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['validate','submit','status'])
parser.add_argument('--model',default='gpt-4.1-mini-2025-04-14')
parser.add_argument('--label-reviewer')
parser.add_argument('--job-id')
args=parser.parse_args()
manifest=json.loads((ROOT/'manifest.json').read_text())
if args.action=='validate':
 for split in ('train','validation','holdout'):
  rows=[json.loads(x) for x in (ROOT/(split+'.jsonl')).read_text(encoding='utf-8').splitlines()]
  assert all([m['role'] for m in row['messages']]==['system','user','assistant'] for row in rows)
  print(split+': '+str(len(rows))+' schema-validated source-grounded examples')
 print('No training submitted. Label review, provider access and held-out comparison remain required.')
else:
 from openai import OpenAI
 client=OpenAI(api_key=os.environ['OPENAI_API_KEY'])
 if args.action=='submit':
  if not args.label_reviewer: raise SystemExit('Supply --label-reviewer after the named person reviews the examples.')
  if (ROOT/'job.json').exists(): raise SystemExit('A job record already exists; inspect status instead of submitting a duplicate.')
  with (ROOT/'train.jsonl').open('rb') as f: training=client.files.create(file=f,purpose='fine-tune')
  with (ROOT/'validation.jsonl').open('rb') as f: validation=client.files.create(file=f,purpose='fine-tune')
  job=client.fine_tuning.jobs.create(model=args.model,training_file=training.id,validation_file=validation.id,
      method={'type':'supervised','supervised':{'hyperparameters':{'n_epochs':2}}},suffix='prd-genie-extractor')
  (ROOT/'job.json').write_text(json.dumps({'job_id':job.id,'status':job.status,'base_model':args.model,'label_reviewer':args.label_reviewer,'training_file_id':training.id,'validation_file_id':validation.id},indent=2))
  print('Training submitted: '+job.id+'. A submitted job is not a successfully trained model.')
 else:
  jid=args.job_id or json.loads((ROOT/'job.json').read_text())['job_id']
  job=client.fine_tuning.jobs.retrieve(jid)
  report={'job_id':job.id,'status':job.status,'fine_tuned_model':job.fine_tuned_model,'trained_tokens':job.trained_tokens}
  (ROOT/'job-status.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
