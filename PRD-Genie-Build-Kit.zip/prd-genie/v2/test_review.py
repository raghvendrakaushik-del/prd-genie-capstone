import copy,json,tempfile,unittest
from pathlib import Path
import review_core as c
ROOT=Path(__file__).resolve().parent
CAT=json.loads((ROOT/'knowledge-base/01-relayops-source-of-truth.json').read_text(encoding='utf-8'))
CAT['metadata']['reviewer']='Unit Test Reviewer'

class ReviewTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(); self.store=c.ReviewStore(Path(self.temp.name)/'reviews.sqlite')
  self.p=copy.deepcopy(CAT)
  self.review=self.store.save_new('session-a',self.p,{'chunks':[]}, {'selected_ids':[r['id'] for r in self.p['requirements']]},[],[])
 def tearDown(self): self.temp.cleanup()
 def approve(self,r=None):
  r=r or self.review
  return self.store.approve('session-a',r['review_id'],r['revision'],r['digest'],r['product']['metadata']['reviewer'],'I reviewed the extracted requirements and approve this exact revision.',CAT)
 def test_sample_is_complete(self): self.assertEqual(c.completeness(CAT,CAT),[])
 def test_author_missing_prompts_and_blocks(self):
  self.p['metadata']['author']=''
  issues=c.completeness(self.p,CAT); self.assertIn('/metadata/author',[i['path'] for i in issues])
  r=self.store.save_new('session-a',self.p,{}, {},issues,[])
  with self.assertRaises(ValueError): self.approve(r)
 def test_unknown_placeholder_blocks(self):
  self.p['dependencies'][0]['owner']='TBD'
  self.assertTrue(c.completeness(self.p,CAT))
 def test_no_prd_before_approval(self):
  with self.assertRaises(ValueError): c.render_prd(self.review)
 def test_no_story_before_approval(self):
  with self.assertRaises(ValueError): c.build_stories(self.review,[])
 def test_wrong_session_cannot_read_or_approve(self):
  with self.assertRaises(ValueError): self.store.get('session-b',self.review['review_id'])
 def test_wrong_hash_cannot_approve(self):
  self.review['digest']='forged'
  with self.assertRaises(ValueError): self.approve()
 def test_edit_invalidates_approval_and_old_revision(self):
  approved=self.approve()
  new=self.store.answer('session-a',approved['review_id'],1,{'/metadata/author':'Test Author'},'Test Reviewer',CAT)
  self.assertIsNone(new['approval']); self.assertEqual(new['revision'],2)
  with self.assertRaises(ValueError): self.approve(approved)
  with self.assertRaises(ValueError): self.store.assert_approved('session-a',approved)
 def test_mutated_handoff_cannot_generate(self):
  r=self.approve(); r['product']['name']='Forged product'
  with self.assertRaises(ValueError): self.store.assert_approved('session-a',r)
 def test_wrong_reviewer_rejected(self):
  self.review['product']['metadata']['reviewer']='Impersonated'
  with self.assertRaises(ValueError): self.approve()
 def test_approval_persists_across_store_instances(self):
  r=self.approve(); again=c.ReviewStore(self.store.path).get('session-a',r['review_id'])
  self.assertEqual(again['approval']['digest'],r['digest'])
 def test_ten_sections_and_full_metadata(self):
  # Explicit unit-test fixture approval; never saved as a user-approved deliverable.
  text=c.render_prd(self.approve())
  for i in range(1,11): self.assertIn('## '+str(i)+'.',text)
  for word in ['Author','Reviewer','Success','GIVEN','WHEN','THEN','```mermaid','API Contracts']:
   if word=='Success': continue
   self.assertIn(word,text)
  for bad in ['TBD','Not stated','Not assigned']: self.assertNotIn(bad,text)
 def test_jira_criteria_preserve_all_source_words(self):
  r=self.approve(); groups=[{'epic_id':e['id'],'requirement_ids':[x['id'] for x in CAT['requirements'] if x['epic_id']==e['id']]} for e in CAT['epics']]
  stories=c.build_stories(r,groups); self.assertEqual(len(stories),8)
  for story,req in zip(sorted(stories,key=lambda s:s['requirement_ids']),CAT['requirements']):
   self.assertEqual(story['acceptance_criteria'],req['acceptance_criteria'])
   self.assertIn(req['description'],story['description'])
 def test_story_wrong_epic_and_omissions_rejected(self):
  with self.assertRaises(ValueError): c.build_stories(self.approve(),[{'epic_id':'invented','requirement_ids':['FR-001']}])
 def test_unresolved_scope_blocks_approval(self):
  self.p['open_questions']['state']='open'
  self.assertTrue(c.completeness(self.p,CAT))
 def test_diagram_unknown_evidence_rejected(self):
  self.p['architecture']['edges'][0]['evidence']=['invented']
  self.assertTrue(c.completeness(self.p,CAT))
 def test_rag_keeps_style_separate(self):
  docs=[{'name':'style.md','role':'style_only','text':'Beacon has a 20% target and Priya as author.'},{'name':'template.md','role':'template','text':'Product Overview and Acceptance Criteria.'},{'name':'source.md','role':'supporting_source','text':'RelayOps webhook replay audit evidence.'}]
  r=c.retrieval(docs,CAT,'webhook replay audit',1)
  self.assertEqual(r['chunks'][0]['role'],'supporting_source')
  self.assertTrue(any(x['role']=='style_only' for x in r['chunks']))
  self.assertEqual(r['canonical_sha256'],c.digest(CAT))
 def test_approval_wording_required(self):
  r=self.review
  with self.assertRaises(ValueError): self.store.approve('session-a',r['review_id'],1,r['digest'],CAT['metadata']['reviewer'],'looks fine',CAT)

if __name__=='__main__': unittest.main(verbosity=2)
