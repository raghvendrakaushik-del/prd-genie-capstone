"""Run the same held-out records against a base model and a completed SFT model.
Requires a working OpenAI connection; never returns invented evaluation scores.
"""
import argparse,importlib.util,json,os,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(); p.add_argument('--base',default='gpt-4.1-mini-2025-04-14'); p.add_argument('--tuned',required=True); args=p.parse_args()
from openai import OpenAI
client=OpenAI(api_key=os.environ['OPENAI_API_KEY'])
spec=importlib.util.spec_from_file_location('grounding',ROOT.parent/'langflow/core.py'); core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
schema=json.loads((ROOT.parent/'schemas/extractor.json').read_text())
rows=[json.loads(x) for x in (ROOT/'fine-tuning/holdout.jsonl').read_text(encoding='utf-8').splitlines()]
report={'status':'RUNNING','dataset':'held-out synthetic domain families; official baseline must also be tested','models':{}}
for model in (args.base,args.tuned):
 results=[]
 for index,row in enumerate(rows):
  start=time.time(); expected=json.loads(row['messages'][-1]['content']); docs=json.loads(row['messages'][1]['content'])['documents']
  try:
   answer=client.chat.completions.create(model=model,messages=row['messages'][:-1],max_tokens=3500,
       response_format={'type':'json_schema','json_schema':{'name':'prd_extraction','strict':True,'schema':schema}})
   if not answer.choices or answer.choices[0].finish_reason!='stop': raise ValueError('Incomplete output')
   actual=json.loads(answer.choices[0].message.content)
   core.schema_check(actual,schema); core.validate_extraction(actual,docs)
   def reqs(x): return {(r['text'],r['kind'],r['persona'],r['priority']) for r in x['requirements']}
   def criteria(x): return {a['text'] for r in x['requirements'] for a in r['acceptance_criteria']}
   results.append({'case_index':index,'source_grounding_pass':True,'status_match':actual['status']==expected['status'],'requirements_exact_match':reqs(actual)==reqs(expected),'criteria_exact_match':criteria(actual)==criteria(expected),'actual':actual,'latency_ms':round((time.time()-start)*1000),'usage':answer.usage.model_dump() if answer.usage else None})
  except Exception as exc: results.append({'case_index':index,'source_grounding_pass':False,'error_type':type(exc).__name__})
 report['models'][model]={'results':results,'grounding_passes':sum(r['source_grounding_pass'] for r in results),'exact_requirement_passes':sum(r.get('requirements_exact_match',False) for r in results),'cases':len(results)}
 (ROOT/'fine-tuning/comparison-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
report['status']='COMPLETED'
report['promotion']='Human review and official baseline regression checks required before changing the deployed extractor.'
(ROOT/'fine-tuning/comparison-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:{a:b for a,b in v.items() if a!='results'} for k,v in report['models'].items()},indent=2))
