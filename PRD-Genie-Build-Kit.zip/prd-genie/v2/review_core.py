"""Source-backed retrieval, persisted review and deterministic document assembly.

No model or network calls in this module. Approval is recorded only by an explicit
review action and is bound to an immutable revision, content hash and session.
"""
from pathlib import Path
from datetime import datetime, timezone
import copy, hashlib, json, math, re, sqlite3, uuid
from contextlib import contextmanager

def utc(): return datetime.now(timezone.utc).isoformat()
def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def require(condition, message):
    if not condition: raise ValueError(message)
def pointer(path): return '/'+'/'.join(str(x).replace('~','~0').replace('/','~1') for x in path)
def leaves(value, path=()):
    if isinstance(value,dict):
        for key,child in value.items(): yield from leaves(child,path+(key,))
    elif isinstance(value,list):
        for i,child in enumerate(value): yield from leaves(child,path+(i,))
    else: yield pointer(path),value
def clean(value): return str(value).replace('|','\\|').replace('<','&lt;').replace('>','&gt;').replace('\n',' ')

PLACEHOLDER = re.compile(r'(^\s*(?:TBD|TBC|N/?A|none|unknown|not stated|not assigned|unassigned|pending)\s*$)|\b(?:TBD|TBC|not stated|not assigned)\b',re.I)
def completeness(product, shape):
    issues=[]
    def walk(value, sample, path):
        label=pointer(path)
        if isinstance(sample,dict):
            if not isinstance(value,dict): issues.append((label,'Provide the complete '+label+' details.')); return
            for key,item in sample.items(): walk(value.get(key),item,path+(key,))
        elif isinstance(sample,list):
            if not isinstance(value,list) or not value: issues.append((label,'Provide at least one source-backed entry for '+label+'.')); return
            for i,item in enumerate(value): walk(item,sample[0],path+(i,))
        elif not isinstance(value,str) or not value.strip() or PLACEHOLDER.search(value):
            question={'/metadata/author':'What is the full name of the document author?', '/metadata/reviewer':'Who is reviewing these extracted requirements? Enter the actual reviewer\'s full name.'}.get(label,'Provide a specific, source-backed value for '+label+'.')
            issues.append((label,question))
    walk(product,shape,())
    if issues: return [{'path':p,'question':q,'kind':'missing_information'} for p,q in issues]
    reqs=product['requirements']; ids=[r['id'] for r in reqs]+[n['id'] for n in product['nfrs']]
    if len(ids)!=len(set(ids)): issues.append(('/requirements','Give every requirement a unique ID.'))
    known=set(ids)|{d['id'] for d in product['decisions']}
    roles={p['role'] for p in product['personas']}; epics={e['id'] for e in product['epics']}
    for i,r in enumerate(reqs):
        if r['persona'] not in roles: issues.append((f'/requirements/{i}/persona','Confirm a persona from the declared persona catalog.'))
        if r['epic_id'] not in epics: issues.append((f'/requirements/{i}/epic_id','Choose an epic from the declared epic catalog.'))
        if r['priority'] not in ['Must Have','Should Have','Nice to Have']: issues.append((f'/requirements/{i}/priority','Specify Must Have, Should Have or Nice to Have.'))
    criteria=[c['id'] for r in reqs for c in r['acceptance_criteria']]
    if len(criteria)!=len(set(criteria)): issues.append(('/requirements','Give every acceptance scenario a unique ID.'))
    if product['open_questions']['state']!='resolved': issues.append(('/open_questions','Resolve the product questions with a decision, owner and source before approval.'))
    if not set(product['open_questions']['resolution_ids']) <= {d['id'] for d in product['decisions']}: issues.append(('/open_questions/resolution_ids','Reference existing decision IDs.'))
    nodes={n['id'] for n in product['architecture']['nodes']}
    if len(nodes)!=len(product['architecture']['nodes']): issues.append(('/architecture/nodes','Use unique diagram node IDs.'))
    for n in nodes:
        if not re.fullmatch('[A-Z][A-Z0-9_]*',n): issues.append(('/architecture/nodes','Diagram node IDs must use uppercase letters, digits and underscores.'))
    for edge in product['architecture']['edges']:
        if edge['from'] not in nodes or edge['to'] not in nodes or not set(edge['evidence']) <= known:
            issues.append(('/architecture/edges','Ground every diagram edge in declared nodes and source requirement or decision IDs.'))
    for n in product['nfrs']:
        if not set(n['related_requirements']) <= {r['id'] for r in reqs}: issues.append(('/nfrs','Link NFRs only to declared functional requirement IDs.'))
    return [{'path':p,'question':q,'kind':'validation'} for p,q in issues]

def retrieval(documents, product, query, top_k=4):
    """BM25 lexical RAG with mandatory current-product catalog and isolated style context."""
    def words(s): return re.findall(r'[a-z0-9]+',s.lower())
    chunks=[]
    for doc in documents:
        if doc['role']=='canonical': continue
        for i,start in enumerate(range(0,len(doc['text']),1000)):
            text=doc['text'][start:start+1200]
            chunks.append({'id':doc['name']+'#chunk-'+str(i+1),'name':doc['name'],'role':doc['role'],'text':text,'sha256':hashlib.sha256(text.encode()).hexdigest()})
    tokens=[words(c['text']) for c in chunks]; avg=sum(map(len,tokens))/max(len(tokens),1); q=set(words(query)); scored=[]
    for c,terms in zip(chunks,tokens):
        score=0
        for term in q:
            tf=terms.count(term)
            df=sum(term in ts for ts in tokens)
            idf=math.log(1+(len(tokens)-df+0.5)/(df+0.5))
            if tf: score += idf*tf*2.2/(tf+1.2*(0.25+0.75*len(terms)/max(avg,1)))
        scored.append(dict(c,score=round(score,6)))
    selected=sorted(scored,key=lambda x:(-x['score'],x['id']))[:top_k]
    # Include the original template and one past-PRD style chunk as retrieval context.
    for role in ('template','style_only'):
        extra=next((c for c in scored if c['role']==role),None)
        if extra and not any(c['id']==extra['id'] for c in selected): selected.append(extra)
    return {'method':'BM25 + mandatory catalog coverage','query':query,'product_id':product['product_id'],
            'canonical_sha256':digest(product),'canonical_source':'01-relayops-source-of-truth.json',
            'chunks':selected,'rule':'Only the current product canonical catalog and explicit reviewer answers supply product facts. Retrieved prior-PRD text is style context only.'}

def extraction_inventory(product):
    entries=[]
    for key in ['name','version','source_date','classification','metadata','overview','problem','business_goal','user_goal','metrics','personas','out_of_scope','assumptions','dependencies','decisions','open_questions','timeline','delivery','architecture']:
        value=product.get(key)
        entries.append({'id':key,'source_pointer':'/'+key,'preview':json.dumps(value,ensure_ascii=False)[:360]})
    entries += [{'id':r['id'],'source_pointer':f'/requirements/{i}','preview':r['title']+': '+r['description']} for i,r in enumerate(product.get('requirements',[]))]
    entries += [{'id':n['id'],'source_pointer':f'/nfrs/{i}','preview':n['requirement']+' '+n['target']} for i,n in enumerate(product.get('nfrs',[]))]
    return entries

class ReviewStore:
    def __init__(self,path):
        self.path=str(path); Path(path).parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS reviews (id TEXT PRIMARY KEY, session TEXT NOT NULL, revision INTEGER NOT NULL, digest TEXT NOT NULL, body TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, review_id TEXT, event TEXT, at TEXT, details TEXT)')
    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path,timeout=30)
        try:
            with db: yield db
        finally: db.close()
    def save_new(self,session,product,retrieved,extraction,issues,stages):
        review={'review_id':str(uuid.uuid4()),'revision':1,'created_at':utc(),'status':'awaiting_review','product':product,'retrieval':retrieved,'extraction':extraction,'issues':issues,'stages':stages,'answers':[],'approval':None}
        review['digest']=digest({'product':product,'extraction':extraction,'issues':issues,'retrieval':retrieved})
        with self.connect() as db:
            db.execute('INSERT INTO reviews VALUES (?,?,?,?,?)',(review['review_id'],session,1,review['digest'],json.dumps(review)))
            self.event(db,review['review_id'],'extracted',{'revision':1,'digest':review['digest']})
        return review
    def event(self,db,rid,name,details): db.execute('INSERT INTO events(review_id,event,at,details) VALUES (?,?,?,?)',(rid,name,utc(),json.dumps(details)))
    def get(self,session,rid):
        with self.connect() as db: row=db.execute('SELECT body FROM reviews WHERE id=? AND session=?',(rid,session)).fetchone()
        require(row is not None,'Review not found in this user/session. Start extraction in the same Playground session.')
        return json.loads(row[0])
    def answer(self,session,rid,revision,answers,actor,shape):
        require(isinstance(actor,str) and actor.strip(),'Provide the name of the person supplying corrections.')
        review=self.get(session,rid); require(review['revision']==revision,'Stale review revision. Open the latest review before editing.')
        require(isinstance(answers,dict) and answers,'Provide field answers keyed by JSON Pointer.')
        for path,value in answers.items():
            require(path.startswith('/') and path not in ['/product_id','/classification'],'This source identity field cannot be overridden.')
            parts=[x.replace('~1','/').replace('~0','~') for x in path[1:].split('/')]
            target=review['product']
            for part in parts[:-1]: target=target[int(part)] if isinstance(target,list) else target[part]
            key=int(parts[-1]) if isinstance(target,list) else parts[-1]
            require((isinstance(target,list) and 0<=key<len(target)) or (isinstance(target,dict) and key in target),'Unknown answer field.')
            target[key]=value
            review['answers'].append({'path':path,'value':value,'actor':actor,'at':utc(),'source':'explicit_user_answer'})
        review['revision']+=1; review['approval']=None; review['status']='awaiting_review'
        # Model-raised conflicts remain open until explicitly addressed and re-extracted.
        model_issues=[i for i in review['issues'] if i.get('kind')=='source_conflict']
        review['issues']=completeness(review['product'],shape)+model_issues
        review['digest']=digest({'product':review['product'],'extraction':review['extraction'],'issues':review['issues'],'retrieval':review['retrieval'],'answers':review['answers']})
        with self.connect() as db:
            count=db.execute('UPDATE reviews SET revision=?,digest=?,body=? WHERE id=? AND session=? AND revision=?',(review['revision'],review['digest'],json.dumps(review),rid,session,revision)).rowcount
            require(count==1,'Concurrent update; reload latest review.')
            self.event(db,rid,'corrected',{'revision':review['revision'],'actor':actor,'paths':list(answers),'approval_invalidated':True})
        return review
    def approve(self,session,rid,revision,content_digest,reviewer,statement,shape):
        review=self.get(session,rid)
        require(review['revision']==revision and review['digest']==content_digest,'Approval does not match the current reviewed revision and hash.')
        require(statement=='I reviewed the extracted requirements and approve this exact revision.','Provide the explicit review approval statement.')
        require(review['product']['metadata']['reviewer']==reviewer,'Reviewer name must match the document reviewer; correct that field first if needed.')
        require(not review['issues'] and not completeness(review['product'],shape),'Resolve every missing field or source conflict before approval.')
        if review['approval']: return review
        review['approval']={'reviewer':reviewer,'at':utc(),'revision':revision,'digest':content_digest,'statement':statement}
        review['status']='approved_for_generation'
        with self.connect() as db:
            count=db.execute('UPDATE reviews SET body=? WHERE id=? AND session=? AND revision=? AND digest=?',(json.dumps(review),rid,session,revision,content_digest)).rowcount
            require(count==1,'Concurrent edit invalidated approval.')
            self.event(db,rid,'approved',review['approval'])
        return review
    def assert_approved(self,session,review):
        current=self.get(session,review['review_id'])
        require(current['approval'] and current['digest']==review['digest'] and current['revision']==review['revision'],'Current evidence has no valid approval.')
        require(digest(current['product'])==digest(review['product']),'Product content changed after review.')
        return current

def table(headers,rows):
    return '| '+' | '.join(headers)+' |\n|'+'|'.join('---' for _ in headers)+'|\n'+'\n'.join('| '+' | '.join(clean(x) for x in row)+' |' for row in rows)
def citation(path): return '[Source: 01-relayops-source-of-truth.json#'+path+']'
def architecture_mermaid(product):
    def label(s): return s.replace('"',"'").replace('<','').replace('>','').replace('\n',' ')
    lines=['flowchart TD']
    for n in product['architecture']['nodes']: lines.append(f'    {n["id"]}["{label(n["label"])}"]')
    for e in product['architecture']['edges']: lines.append(f'    {e["from"]} -->|"{label(e["label"])} [{", ".join(e["evidence"])}]"| {e["to"]}')
    return '\n'.join(lines)

def render_review(review):
    p=review['product']; lines=['# Extracted requirements - approval required',p['classification'],
        f'Review ID: `{review["review_id"]}` | Revision: {review["revision"]} | Status: {review["status"]}',
        'Content hash: `'+review['digest']+'`',
        '**Review these extracted requirements before document generation.**',
        '## Document identity',table(['Field','Extracted value'],[(k,v) for k,v in p['metadata'].items()]),
        '## Product intent',p['overview'],p['problem'],p['business_goal'],p['user_goal'],
        '## Requirements, API behavior and acceptance scenarios']
    for i,r in enumerate(p['requirements']):
        lines += ['### '+r['id']+' - '+r['title'],r['description'],r['api_contract'],
                  'Persona: '+r['persona']+' | Priority: '+r['priority']+' | Epic: '+r['epic_id'],citation('/requirements/'+str(i))]
        for c in r['acceptance_criteria']: lines.append('**'+c['id']+'**\n- GIVEN '+c['given']+'\n- WHEN '+c['when']+'\n- THEN '+c['then'])
    for heading,key in [('Non-functional requirements','nfrs'),('Personas','personas'),('Metrics','metrics'),('Dependencies','dependencies'),('Assumptions','assumptions'),('Resolved questions','decisions'),('Timeline','timeline'),('Delivery plan','delivery')]:
        lines += ['## '+heading,'```json\n'+json.dumps(p[key],indent=2,ensure_ascii=False)+'\n```']
    lines += ['## Excluded scope','\n'.join('- '+s for s in p['out_of_scope']),'## Proposed product architecture','```mermaid\n'+architecture_mermaid(p)+'\n```',
              '## Required clarifications', '\n'.join('- '+i['question']+' Field: `'+i.get('path','source conflict')+'`' for i in review['issues']) if review['issues'] else 'The completeness checks found no missing fields. Review the facts, assumptions, acceptance criteria and source conflicts before deciding.',
              '## Retrieval evidence','```json\n'+json.dumps({k:v for k,v in review['retrieval'].items() if k!='chunks'},indent=2)+'\n```',
              '\n'.join('- '+c['id']+' | '+c['role']+' | score '+str(c['score']) for c in review['retrieval']['chunks']),
              '## Review actions','To correct metadata or source facts, send an answer action. Corrections create a new revision and invalidate prior approval. To approve, use the exact current hash and reviewer name.',
              '```json\n'+json.dumps({'action':'approve','review_id':review['review_id'],'revision':review['revision'],'digest':review['digest'],'reviewer':p['metadata']['reviewer'],'statement':'I reviewed the extracted requirements and approve this exact revision.'},indent=2)+'\n```']
    return '\n\n'.join(lines)

def render_prd(review):
    require(review.get('approval'),'Human approval required before PRD generation.')
    p=review['product']; a=review['approval']; m=p['metadata']
    lines=['# Product Requirements Document (PRD)',p['classification'],
      '## 1. Product Overview',table(['Field','Value'],[
      ('Product Name',p['name']),('Document Version',p['version']),('Author',m['author']),('Reviewer',m['reviewer']),('Date',m['date']),
      ('Status','Draft generated from approved requirements; final PRD sign-off remains separate'),('Requirements Approval',a['reviewer']+' at '+a['at']),('Source Revision',str(review['revision'])+' / '+review['digest'])]),
      p['overview'],p['problem'],citation('/overview')+' '+citation('/problem'),
      '## 2. Goals and Objectives','**Business goal:** '+p['business_goal'],'**User goal:** '+p['user_goal'],
      table(['KPI','Baseline','Target','Window','Measurement','Owner'],[[x[k] for k in ['name','baseline','target','window','measurement','owner']] for x in p['metrics']]),citation('/metrics'),
      '## 3. User Personas',table(['Role','Key need','Current workaround','Permissions'],[[x[k] for k in ['role','need','workaround','permissions']] for x in p['personas']]),citation('/personas'),
      '## 4. Feature Requirements','### 4.1 Functional Requirements',
      table(['ID','Requirement','Priority (Must/Should/Nice)','Source'],[(r['id'],r['description'],r['priority'],citation('/requirements/'+str(i))) for i,r in enumerate(p['requirements'])]),
      '### 4.2 Non-Functional Requirements',table(['ID','Requirement','Category','Target','Verification','Owner'],[[n[k] for k in ['id','requirement','category','target','verification','owner']] for n in p['nfrs']]),citation('/nfrs'),
      '### 4.3 API Contracts','\n\n'.join('**'+r['id']+' - '+r['title']+'**\n\n'+r['api_contract'] for r in p['requirements']),
      '### 4.4 Detailed Product Architecture','```mermaid\n'+architecture_mermaid(p)+'\n```',citation('/architecture')+' Diagram edges include supporting requirement/decision IDs.',
      '## 5. Acceptance Criteria']
    for i,r in enumerate(p['requirements']):
        lines.append('### '+r['id']+' - '+r['title'])
        for c in r['acceptance_criteria']: lines.append('**'+c['id']+'**\n- **GIVEN** '+c['given']+'\n- **WHEN** '+c['when']+'\n- **THEN** '+c['then'])
        lines.append(citation('/requirements/'+str(i)+'/acceptance_criteria'))
    lines += ['## 6. Out of Scope','\n'.join('- '+x for x in p['out_of_scope']),citation('/out_of_scope'),
      '## 7. Dependencies',table(['Dependency','Owner','Status','Risk','Mitigation'],[[x[k] for k in ['name','owner','status','risk','mitigation']] for x in p['dependencies']]),citation('/dependencies'),
      '## 8. Assumptions',table(['Explicit assumption','Owner','Validation basis'],[[x[k] for k in ['statement','owner','validation']] for x in p['assumptions']]),citation('/assumptions'),
      '## 9. Open Questions',p['open_questions']['statement'],table(['Decision','Question','Resolution','Owner','Date'],[[x[k] for k in ['id','question','resolution','owner','date']] for x in p['decisions']]),citation('/decisions'),
      '## 10. Timeline',table(['Milestone','Target Date','Owner','Exit criterion'],[[x[k] for k in ['milestone','date','owner','exit']] for x in p['timeline']]),citation('/timeline'),
      '### Delivery and rollout','\n\n'.join('**'+k.capitalize()+':** '+v for k,v in p['delivery'].items()),citation('/delivery'),
      '### Review provenance',table(['Review ID','Revision','Approval hash'],[(review['review_id'],review['revision'],review['digest'])])]
    if review['answers']:
        lines += ['### Reviewer amendments',table(['Field','Confirmed value','Confirmed by','When'],[(x['path'],json.dumps(x['value'],ensure_ascii=False),x['actor'],x['at']) for x in review['answers']]),
                  'Reviewer amendments supersede the corresponding catalog values. Their explicit answer records are the source for changed fields.']
    text='\n\n'.join(lines)
    require(not re.search(r'\b(?:TBD|TBC|Not stated|Not assigned)\b',text,re.I),'Unresolved placeholder in generated PRD.')
    return text

def build_stories(review, grouping):
    require(review.get('approval'),'Human approval required before story generation.')
    p=review['product']; reqs={r['id']:r for r in p['requirements']}; expected={e['id'] for e in p['epics']}
    require({e['epic_id'] for e in grouping}==expected,'Story grouping must retain all source epics.')
    seen=[]; stories=[]
    for e in grouping:
        for rid in e['requirement_ids']:
            require(rid in reqs and reqs[rid]['epic_id']==e['epic_id'],'Story grouping changed a source epic or referenced an unknown requirement.')
            seen.append(rid); r=reqs[rid]
            criteria='\n\n'.join(c['id']+'\nGIVEN '+c['given']+'\nWHEN '+c['when']+'\nTHEN '+c['then'] for c in r['acceptance_criteria'])
            nfrs=[n for n in p['nfrs'] if rid in n['related_requirements']]
            description='As a '+r['persona']+', I want to '+r['want']+', so that '+r['benefit']+'\n\nDESCRIPTION\n'+r['description']+'\n\nAPI CONTRACT\n'+r['api_contract']+'\n\nACCEPTANCE CRITERIA\n'+criteria
            if nfrs: description+='\n\nAPPLICABLE NON-FUNCTIONAL REQUIREMENTS\n'+'\n'.join(n['id']+': '+n['target']+' Verification: '+n['verification'] for n in nfrs)
            description+='\n\nSOURCE AND REVIEW\nRequirement: '+rid+'; source priority: '+r['priority']+'; review '+review['review_id']+' revision '+str(review['revision'])+'; approved by '+review['approval']['reviewer']+'.'
            stories.append({'local_id':'ST-'+rid,'epic_id':e['epic_id'],'issue_type':'Story','summary':r['title'],'description':description,'requirement_ids':[rid],'priority':r['priority'],'acceptance_criteria':copy.deepcopy(r['acceptance_criteria'])})
    require(len(seen)==len(set(seen)) and set(seen)==set(reqs),'Stories must cover every requirement exactly once.')
    return stories
