from pathlib import Path
import copy,json
ROOT=Path(__file__).resolve().parent
old=json.loads((ROOT.parent/'workflows/prd-genie.groq.langflow.json').read_text(encoding='utf-8'))
catalog=json.loads((ROOT/'knowledge-base/01-relayops-source-of-truth.json').read_text(encoding='utf-8'))
manifest=json.loads((ROOT/'knowledge-base/manifest.json').read_text())
docs=[dict(name=f['name'],role=f['role'],text=(ROOT/'knowledge-base'/f['name']).read_text(encoding='utf-8')) for f in manifest['files']]
prefix=(ROOT/'review_core.py').read_text(encoding='utf-8')+'\n'+(ROOT/'version_export.py').read_text(encoding='utf-8')+'\nCATALOG = '+repr(catalog)+'\nDOCUMENTS = '+repr(docs)+'\n'
base=(ROOT/'flow_component.py').read_text(encoding='utf-8')
nodes=[copy.deepcopy(old['data']['nodes'][0])]
nodes[0]['data']['node']['template']['input_value']['value']=''
for i,(stage,title) in enumerate([('retrieval','1. Knowledge Retrieval and Review Actions'),('extractor','2. Requirement Extractor Agent'),('gaps','3. Gap and Completeness Agent'),('review','4. Human Review Gate'),('prd','5. PRD Generator Agent'),('stories','6. Jira Story Breakdown Agent'),('publish','7. GitHub Version Publisher'),('output','8. Reviewed Document Output')],1):
    node=copy.deepcopy(old['data']['nodes'][1]); nid='PRDGenieReviewedStage-'+stage
    node['id']=node['data']['id']=nid; node['data']['type']='PRDGenieReviewedStage'
    node['position']={'x':i*380,'y':0}; node['selected']=False
    d=node['data']['node']; d['display_name']=title; node['data']['display_name']=title
    code=prefix+'\nSTAGE = '+repr(stage)+'\n'+base.replace("display_name='PRD Genie Reviewed Stage'",'display_name='+repr(title))
    compile(code,'<'+stage+'>','exec'); (ROOT/(stage+'.component.py')).write_text(code,encoding='utf-8')
    t=d['template']; t['code']['value']=code
    t['api_key']['advanced']=True; t['api_key']['required']=stage in ['extractor','gaps','prd','stories']
    t['model_name']['advanced']=True
    def field(name,label,value='',kind='str',input_kind='StrInput'):
        return {'name':name,'display_name':label,'value':value,'type':kind,'_input_type':input_kind,'show':True,'advanced':True,'required':False}
    t['source_mode']=dict(field('source_mode','Knowledge Source','Embedded snapshot',input_kind='DropdownInput'),options=['Embedded snapshot','Google Drive'])
    t['drive_folder_id']=field('drive_folder_id','Google Drive Folder ID','121xKPik0_bfY8N6y43BNlNKRpWqD09jV')
    t['google_service_account']=dict(copy.deepcopy(t['api_key']),name='google_service_account',display_name='Google Service Account JSON',value='',load_from_db=False,required=False)
    t['review_directory']=field('review_directory','Review Store Directory')
    t['github_token']=dict(copy.deepcopy(t['api_key']),name='github_token',display_name='GitHub Access Token',value='',load_from_db=False,required=False)
    t['github_repository']=field('github_repository','GitHub Repository (owner/repository)','raghvendrakaushik-del/prd-genie-capstone')
    t['github_branch']=field('github_branch','GitHub Branch','Feature/Raghav_IK_Capstone_SEP2026')
    t['github_author_email']=field('github_author_email','GitHub Author Email (optional)')
    if stage=='retrieval': t['source_mode']['advanced']=False
    d['field_order']=[k for k in t if k not in ['code','_type'] and not k.startswith('_')]
    d['outputs'][0]['display_name']='Reviewed handoff'; d['outputs'][0]['method']='run_stage'
    nodes.append(node)
end=copy.deepcopy(old['data']['nodes'][-1]); end['position']={'x':9*380,'y':0}; nodes.append(end)
edges=[]
for a,b in zip(nodes,nodes[1:]):
    sh={'dataType':a['data']['type'],'id':a['id'],'name':'message','output_types':['Message']}
    th={'fieldName':'input_value','id':b['id'],'inputTypes':['Data','JSON','DataFrame','Table','Message'] if b['data']['type']=='ChatOutput' else ['Message'],'type':'str'}
    edges.append({'id':a['id']+'-to-'+b['id'],'source':a['id'],'target':b['id'],'sourceHandle':json.dumps(sh).replace('"','œ'),'targetHandle':json.dumps(th).replace('"','œ'),'data':{'sourceHandle':sh,'targetHandle':th},'animated':False})
flow={'name':'PRD Genie v2.1 - Reviewed PRD and GitHub','description':'Versioned knowledge retrieval, full required-field checks, persisted revision-bound approval, complete PRD with Mermaid, Given/When/Then Jira CSV and automatic GitHub version commits after access configuration. Embedded snapshot demo until Google Drive credentials are configured.','icon':'ShieldCheck','is_component':False,'access_type':'PRIVATE','data':{'nodes':nodes,'edges':edges,'viewport':{'x':20,'y':100,'zoom':0.4}}}
target=ROOT.parent/'workflows/prd-genie.v2-reviewed.langflow.json'; target.write_text(json.dumps(flow,indent=2,ensure_ascii=False),encoding='utf-8')
print('Built',len(nodes),'nodes and',len(edges),'edges:',target)
