# PRD Genie v2.1 - reviewed product documentation

Author: **Raghavendra Kaushik**. The reviewer must supply their own full name and explicitly approve the extracted requirements before generation.

For this capstone, Raghavendra Kaushik is also the reviewer. He approved the extracted requirements on September 13, 2026. The live approval gate accepted revision 2 and generated the [wiki.md PRD](generated/wiki.md), [eight detailed stories](generated/stories.md), and [three-epic/eight-story Jira CSV](generated/jira-import.csv). The document remains a draft for his final review and merge into main. The latest import publishes future PRDs as `wiki.md`.

## Current live setup

- [Reviewed Langflow flow](http://localhost:7860/flow/d22537f8-64b3-4a58-862a-3efa220f7518)
- [Google Drive knowledge folder](https://drive.google.com/drive/u/0/folders/121xKPik0_bfY8N6y43BNlNKRpWqD09jV)
- [Private GitHub repository](https://github.com/raghvendrakaushik-del/prd-genie-capstone)
- Branch: `Feature/Raghav_IK_Capstone_SEP2026`

The Drive folder contains eight detailed source files plus a manifest. The current live run used the identical embedded snapshot because a Google service-account connection has not yet been configured in Langflow. Browser sign-in and server-side Drive API access are separate connections. The flow reports its actual source transport and never silently falls back if Drive retrieval fails.

## Review workflow

```mermaid
flowchart TD
    D[Google Drive source folder or explicit versioned snapshot] --> R[BM25 retrieval plus complete current-product catalog]
    R --> E[Requirement Extractor: exact source IDs and coverage]
    E --> G[Gap Agent plus required-field validation]
    G --> H[Persist extracted evidence and revision hash]
    H --> Q{Missing field or unresolved conflict?}
    Q -->|Yes| A[Ask reviewer for specific information]
    A --> V[Record answer provenance; increment revision; invalidate approval]
    V --> H
    Q -->|No| U[Human reads extraction and enters reviewer name]
    U --> P{Explicit approval of current revision and hash?}
    P -->|No| H
    P -->|Yes| PRD[PRD Agent: exact ten-section template and detailed Mermaid]
    PRD --> J[Story Agent: source descriptions and Given/When/Then criteria]
    J --> CSV[Jira import CSV with epics and parent relationships]
    CSV --> AUTH{GitHub access configured?}
    AUTH -->|No| ASK[Prompt for repository-scoped connection]
    AUTH -->|Yes| COMMIT[One atomic commit on configured branch]
```

Start in Playground:

```json
{"action":"extract","product_id":"relayops-pilot-v1"}
```

Read the returned requirements, API contracts, all 16 acceptance scenarios, metrics, assumptions, dependencies, resolved questions and architecture. The source is explicitly synthetic product data. Neither the model nor the source document can approve itself.

Supply the reviewer through an `answer` action using the current review ID and revision shown by the flow:

```json
{"action":"answer","review_id":"COPY_CURRENT_REVIEW_ID","revision":1,"actor":"ACTUAL_REVIEWER_FULL_NAME","answers":{"/metadata/reviewer":"ACTUAL_REVIEWER_FULL_NAME"}}
```

This produces a new review revision. Only after reading it should the reviewer send the displayed `approve` action, using its exact digest and the statement `I reviewed the extracted requirements and approve this exact revision.` Changing an answer invalidates all older approvals. The `review` action reloads a saved review in the same user/Playground session without another model call.

The placeholders in the **command examples above are instructions for user input**, not PRD content. The final PRD generator rejects missing metadata, empty required fields and unresolved placeholders. A fully resolved decision register fills section 9 rather than leaving an empty Open Questions section.

## RAG and source grounding

The corpus includes a canonical JSON product catalog, detailed brief, API/acceptance catalog, NFR/operations notes, messy meeting transcript, resolved stakeholder notes, the original PRD template and a fictional past-PRD style reference. BM25 selects contextual chunks. The complete current-product catalog is pinned so top-k retrieval cannot silently omit required product scope. Prior-product facts are never valid evidence for RelayOps.

This implementation uses **constrained extraction from a structured source catalog**, with narrative context for review. It does not claim that arbitrary unstructured documents are automatically normalized into that catalog. The earlier free-text extractor remains available for baseline tests and future catalog ingestion. Those extracted inputs still require review and completion before entering the strict v2 document-generation path.

Each source field has a JSON Pointer citation. Human amendments record field, value, actor and timestamp. The PRD copies approved descriptions, numbers, owners, dates and criteria; the architecture renderer uses declared nodes/edges with evidence IDs. Source quotation and catalog membership checks cannot prove that the original source is factually correct, so human review remains mandatory.

## Connect Google Drive to Langflow

1. Use a Google Cloud service account with Drive API access. Share only the knowledge folder with its service-account email as Viewer.
2. Store its JSON credential in a Langflow secret variable; do not paste credentials in Playground, GitHub or a source file.
3. In **1. Knowledge Retrieval and Review Actions**, select **Google Drive**, set folder ID `121xKPik0_bfY8N6y43BNlNKRpWqD09jV`, and select the secret in **Google Service Account JSON**.
4. Keep the eight filenames unchanged. Upload them as JSON/Markdown files without Google Docs conversion.
5. Run extraction and verify `transport: google_drive`, file IDs and timestamps in the retrieval evidence.

Until that connection is configured, choose **Embedded snapshot** explicitly. A browser login alone does not give the Docker application an API credential.

## Jira imports

The user requested import-ready stories rather than publishing Jira issues. After approval, the export includes three Epics and eight Stories. Each Story has an actor/want/benefit sentence, detailed behavior, API contract, two exact Given/When/Then scenarios, applicable NFRs, source priority and review provenance. No extra scenario is invented by the story model.

Use Jira's administrative CSV import that supports hierarchy. Map `Issue ID` to the importer’s work-item ID field and `Parent` to Parent; Epics appear before Stories. `Issue Type`, Summary, Description and Labels also need mapping. The simple bulk-create importer may not support hierarchy. Source Must/Should/Nice priorities are retained in Description rather than assuming they match the destination project's priority names. No Jira project, assignee or issue keys are fabricated.

## GitHub versioning

After generation, **GitHub Version Publisher** prepares the PRD, Jira CSV, story JSON, approved source and review manifest. If credentials are missing, it asks for access. Configure a repository-restricted token with Contents write access in **GitHub Access Token**, repository `raghvendrakaushik-del/prd-genie-capstone`, and branch `Feature/Raghav_IK_Capstone_SEP2026`.

The publisher creates one tree and commit for all files, then updates the existing branch with `force: false`. Versions use product version, review revision and source hash in their paths. Repeating a committed revision detects its manifest and avoids another write. The connected account must have commit access; the document author name is used for commit attribution. Final PRD sign-off remains distinct from approval of source requirements; generated files are honestly marked Draft.

The publisher is implemented and tested with mocked GitHub responses. Browser repository creation does not configure a server token. An actual automatic commit from Langflow must still be verified after the connection is supplied.

## Fine-tuning

`fine-tuning/train.jsonl`, `validation.jsonl` and `holdout.jsonl` contain 48/16/16 synthetic, schema-validated extraction examples. Product-domain families are separated across splits. Official T1-T12 are excluded from training. The data covers filler, rejected ideas, speculation, exact numerical targets, acceptance criteria, empty and vague inputs. Human label review is still required; repetitive synthetic examples alone are not evidence of useful generalization.

`fine_tune.py` validates data, submits an actual supervised training job when a working OpenAI API connection is provided, and records status/model ID. It does not label prompt editing as training. Default training target is `gpt-4.1-mini-2025-04-14`; validate account access before submission. After training, compare the base and tuned extractor on the held-out examples and official baseline before promoting a model.

**No fine-tuning job has been run and no trained model is deployed.** Groq provides LoRA inference rather than training and currently restricts adapter hosting to enterprise customers. The working Groq model stays in place until a supported training and inference path is available.

## Verification and deployment limits

Software checks cover missing-field blocking, no generation before approval, exact revision/hash checks, cross-session denial, stale approvals, persistent review reload, exact AC fidelity, diagram references, Jira CSV hierarchy and non-force atomic GitHub publication. These are software tests, not a substitute for live model evaluation.

The SQLite review store is under `LANGFLOW_CONFIG_DIR/prd-genie-v2` or the configured directory (otherwise the Langflow user's `.langflow` directory). Mount this directory to a persistent Docker volume before relying on survival across container replacement. User/session binding prevents casual cross-session reuse; typed reviewer identity is **not enterprise identity attestation**. Production access should use authenticated reviewer accounts and role authorization.

The original baseline T11 allows a sparse PRD derived only from T1, whereas the user's new strict requirement forbids incomplete PRDs. Keep the original baseline results separate: the v2 release gate requests completion and approval before producing a final document. Do not invent T1 details merely to satisfy the stricter gate.

## Sources

- [Groq LoRA service and access limits](https://console.groq.com/docs/lora)
- [OpenAI supervised fine-tuning](https://developers.openai.com/api/docs/guides/supervised-fine-tuning)
- [Langflow Google components](https://docs.langflow.org/bundles-google)
- [GitHub Git tree API](https://docs.github.com/en/rest/git/trees)
- [Jira CSV preparation and hierarchy](https://support.atlassian.com/jira-software-cloud/docs/prepare-a-csv-file-for-import/)

Native HITL documentation describes newer Langflow versions. This project uses its own persisted review gate in the inspected Langflow 1.10 environment, avoiding an unrequested container upgrade.
