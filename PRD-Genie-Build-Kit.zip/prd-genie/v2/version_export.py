"""Jira import preparation and atomic GitHub version commits after human review."""
import csv, io, json, re
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import quote

def jira_csv(product,stories):
    # Parent references use import-local IDs, not invented Jira issue keys.
    stream=io.StringIO(newline='')
    writer=csv.DictWriter(stream,fieldnames=['Issue ID','Issue Type','Summary','Description','Parent','Labels'])
    writer.writeheader()
    parents={e['id']:str(i+1) for i,e in enumerate(product['epics'])}
    for e in product['epics']:
        writer.writerow({'Issue ID':parents[e['id']],'Issue Type':'Epic','Summary':e['title'],'Description':e['outcome']+'\nSource epic: '+e['id'],'Parent':'','Labels':'prd-genie-relayops'})
    for i,s in enumerate(stories,100):
        writer.writerow({'Issue ID':str(i),'Issue Type':'Story','Summary':s['summary'],'Description':s['description'],'Parent':parents[s['epic_id']],'Labels':'prd-genie-relayops'})
    return stream.getvalue()

def version_files(run):
    review=run['review']; p=review['product']
    manifest={'product_id':p['product_id'],'product_version':p['version'],'review_id':review['review_id'],'review_revision':review['revision'],'review_digest':review['digest'],'approval':review['approval'],'author':p['metadata']['author'],'source_transport':review['retrieval'].get('transport'),'status':'Draft generated from approved source requirements; final document sign-off is separate.'}
    return {'wiki.md':run['prd_markdown'],'jira-import.csv':jira_csv(p,run['stories']),
            'stories.json':json.dumps(run['stories'],indent=2,ensure_ascii=False),
            'approved-source.json':json.dumps(p,indent=2,ensure_ascii=False),
            'review-manifest.json':json.dumps(manifest,indent=2,ensure_ascii=False)}

def commit_version(run,repository,branch,token,author_email='',transport=None):
    review=run['review']; approval=review.get('approval')
    if not approval or approval['digest']!=review['digest']: raise ValueError('An exact approved source revision is required for GitHub commit.')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repository or ''): raise ValueError('Set GitHub repository as owner/repository.')
    if not branch or branch.startswith('-') or '..' in branch or any(c in branch for c in '~^:?*[\\'): raise ValueError('Set a valid explicit existing GitHub branch.')
    if not token or token=='GITHUB_TOKEN': raise ValueError('Configure GitHub access in the secret field.')
    def call(method,path,data=None):
        if transport: return transport(method,path,data)
        request=Request('https://api.github.com'+path,data=None if data is None else json.dumps(data).encode(),method=method,
                        headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Content-Type':'application/json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'PRD-Genie'})
        try:
            with urlopen(request,timeout=30) as response: return json.load(response)
        except HTTPError as exc: raise ValueError('GitHub returned HTTP '+str(exc.code)+'. Check repository access, existing branch and concurrent updates. No credentials are included in this error.') from None
    repo=call('GET','/repos/'+repository)
    if repo.get('permissions',{}).get('push') is False: raise ValueError('The connected GitHub account cannot commit to this repository.')
    actor=call('GET','/user')
    email=author_email or actor.get('email') or f"{actor['id']}+{actor['login']}@users.noreply.github.com"
    ref=call('GET','/repos/'+repository+'/git/ref/heads/'+quote(branch,safe='/'))
    head=ref['object']['sha']; base=call('GET','/repos/'+repository+'/git/commits/'+head)
    folder='prd-genie/'+review['product']['product_id']+'/v'+review['product']['version']+'-r'+str(review['revision'])+'-'+review['digest'][:12]
    # Unique immutable version paths. A retry recognizes an existing commit marker.
    tree=call('GET','/repos/'+repository+'/git/trees/'+base['tree']['sha']+'?recursive=1')
    if any(x.get('path')==folder+'/review-manifest.json' for x in tree.get('tree',[])):
        return {'status':'already_committed','repository':repository,'branch':branch,'path':folder,'commit_sha':head,'url':'https://github.com/'+repository+'/tree/'+quote(branch,safe='/')+'/'+folder}
    created=call('POST','/repos/'+repository+'/git/trees',{'base_tree':base['tree']['sha'],'tree':[{'path':folder+'/'+name,'mode':'100644','type':'blob','content':body} for name,body in version_files(run).items()]})
    commit=call('POST','/repos/'+repository+'/git/commits',{'message':'PRD Genie: '+review['product']['name']+' reviewed revision '+str(review['revision'])+' ['+review['digest'][:12]+']',
       'tree':created['sha'],'parents':[head],'author':{'name':review['product']['metadata']['author'],'email':email}})
    call('PATCH','/repos/'+repository+'/git/refs/heads/'+quote(branch,safe='/'),{'sha':commit['sha'],'force':False})
    return {'status':'committed','repository':repository,'branch':branch,'commit_sha':commit['sha'],'author':review['product']['metadata']['author'],'connected_account':actor['login'],'url':'https://github.com/'+repository+'/commit/'+commit['sha'],'path':folder}
