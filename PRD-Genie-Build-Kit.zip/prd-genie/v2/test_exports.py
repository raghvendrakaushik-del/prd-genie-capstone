import copy,csv,io,unittest
import test_review as tr
import review_core as c
import version_export as v

CAT=tr.CAT
class ExportTests(unittest.TestCase):
 setUp=tr.ReviewTests.setUp
 tearDown=tr.ReviewTests.tearDown
 approve=tr.ReviewTests.approve
 def generated(self):
  r=self.approve(); grouping=[{'epic_id':e['id'],'requirement_ids':[x['id'] for x in CAT['requirements'] if x['epic_id']==e['id']]} for e in CAT['epics']]
  return {'review':r,'prd_markdown':c.render_prd(r),'stories':c.build_stories(r,grouping)}
 def test_csv_parent_hierarchy_and_multiline_descriptions(self):
  run=self.generated(); rows=list(csv.DictReader(io.StringIO(v.jira_csv(CAT,run['stories']))))
  self.assertEqual(len(rows),11); parents={r['Issue ID'] for r in rows if r['Issue Type']=='Epic'}
  for row in rows[3:]:
   self.assertIn(row['Parent'],parents)
   for word in ['GIVEN','WHEN','THEN','API CONTRACT']: self.assertIn(word,row['Description'])
 def test_commit_uses_single_tree_and_nonforce_update(self):
  calls=[]
  def fake(method,path,data):
   calls.append((method,path,data))
   if path=='/user': return {'id':123,'login':'test-user','email':None}
   if '/git/ref/heads/' in path: return {'object':{'sha':'old-head'}}
   if path.endswith('/git/commits/old-head'): return {'tree':{'sha':'base-tree'}}
   if '?recursive=1' in path: return {'tree':[]}
   if method=='GET': return {'permissions':{'push':True}}
   if path.endswith('/git/trees'): return {'sha':'new-tree'}
   if path.endswith('/git/commits'): return {'sha':'new-commit'}
   return {}
  result=v.commit_version(self.generated(),'owner/repo','prd-genie-v2','mock-secret',transport=fake)
  self.assertEqual(result['status'],'committed')
  self.assertEqual(calls[-1][2],{'sha':'new-commit','force':False})
  commit=next(x[2] for x in calls if x[0]=='POST' and x[1].endswith('/git/commits'))
  self.assertEqual(commit['parents'],['old-head']); self.assertEqual(commit['author']['name'],'Raghavendra Kaushik')
  self.assertFalse(any('mock-secret' in str(x) for x in calls))
 def test_commit_denied_before_any_network_when_unapproved(self):
  called=[]
  with self.assertRaises(ValueError): v.commit_version({'review':self.review},'owner/repo','branch','secret',transport=lambda *a: called.append(a))
  self.assertEqual(called,[])
 def test_duplicate_version_does_not_write(self):
  run=self.generated(); r=run['review']; folder='prd-genie/'+CAT['product_id']+'/v'+CAT['version']+'-r1-'+r['digest'][:12]
  methods=[]
  def fake(method,path,data):
   methods.append(method)
   if path=='/user': return {'id':1,'login':'test'}
   if '/git/ref/' in path: return {'object':{'sha':'head'}}
   if '/git/commits/' in path: return {'tree':{'sha':'tree'}}
   if '?recursive=1' in path: return {'tree':[{'path':folder+'/review-manifest.json'}]}
   return {'permissions':{'push':True}}
  self.assertEqual(v.commit_version(run,'owner/repo','branch','secret',transport=fake)['status'],'already_committed')
  self.assertTrue(all(m=='GET' for m in methods))

if __name__=='__main__': unittest.main(verbosity=2)
