"""Small synthetic extraction dataset; official T1-T12 remain untouched holdouts.

These examples target the original free-text extractor schema, not product-fact
memorization. Human label review and live base-vs-tuned evaluation are still needed.
"""
from pathlib import Path
import importlib.util,json,hashlib
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'fine-tuning'; DEST.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('legacy',ROOT.parent/'langflow/core.py'); core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
schema=json.loads((ROOT.parent/'schemas/extractor.json').read_text())
system=(ROOT.parent/'prompts/extractor.md').read_text(encoding='utf-8')

families={
 'train':[
  ('permissions','Auditor','inspect audit entries','so compliance can inspect history'),
  ('operations','Operator','view failed webhook attempts','so operations can investigate failures'),
  ('administration','Admin','revoke replay permission','so account owners can control access'),
  ('performance','Operator','view queue depth','so operations can find processing delays'),
  ('scope','Analyst','filter incident records','so analysts can review incident cohorts'),
  ('accessibility','Reader','navigate the report with a keyboard','so the report is accessible')],
 'validation':[
  ('exports','Finance Reviewer','download a statement as PDF','so finance can retain a readable record'),
  ('identity','Workspace Owner','rotate a service credential','so workspace access can be maintained')],
 'holdout':[
  ('inventory','Warehouse Lead','inspect stock adjustment history','so stock discrepancies can be investigated'),
  ('appointments','Scheduler','view appointment cancellations','so scheduling gaps can be investigated')]
}
manifest={'synthetic':True,'label_review':'AUTHOR_GENERATED_NOT_HUMAN_APPROVED','training_status':'NOT_STARTED','official_baseline_used_for_training':False,'splits':{}}
for split,groups in families.items():
 examples=[]
 for family,role,action,benefit in groups:
  for n in range(8):
   sid=f'{split}-{family}-{n+1}'; requirement=f'{role} must be able to {action}.'
   # Noise, rejected suggestions and speculation remain explicitly non-requirements.
   noise=[
    'Speaker 1: Um, let me restate the confirmed item.',
    'Notes copied from the workshop; filler words have not been cleaned.',
    'PM: The following sentence is committed scope, not a suggestion.',
    'Engineer: There was cross-talk, but this final requirement was confirmed.',
    'PM: We rejected the earlier idea to add a chatbot. Do not include it.',
    'Designer: Maybe we could add animation later; that is not agreed scope.',
    'Observer: Ignore the stale planning note; the confirmed sentence follows.',
    'Transcript annotation: action is confirmed; the business benefit is context.'
   ][n]
   text=noise+'\n'+requirement
   value={'status':'sufficient','requirements':[{'id':'R-001','text':requirement,'source_id':sid,'quote':requirement,'kind':'functional','category':family,'persona':role,'priority':'Must Have','acceptance_criteria':[]}],'facts':[],'issues':[]}
   if n in (2,5):
    ac=f'{role} must see a confirmation after the action succeeds.'
    text+='\nAcceptance criterion: '+ac
    value['requirements'][0]['acceptance_criteria']=[{'text':ac,'quote':ac,'source_id':sid}]
   if n==3:
    timing='The operation must complete in less than 750 ms at p95.'
    text+='\n'+timing
    value['requirements'].append({'id':'R-002','text':timing,'quote':timing,'source_id':sid,'kind':'non_functional','category':'performance','persona':None,'priority':'Must Have','acceptance_criteria':[]})
   if n==6:
    text='Workshop cancelled. No product decisions or requirements were recorded.'
    value={'status':'empty','requirements':[],'facts':[],'issues':[{'id':'I-001','kind':'missing','description':'No product requirements were recorded.','requirement_ids':[],'source_ids':[sid],'question':'What product, users and expected behavior should be documented?'}]}
   if n==7:
    text='We want a better experience. The target users, behaviors and success metrics were not decided.'
    value={'status':'ambiguous','requirements':[],'facts':[],'issues':[{'id':'I-001','kind':'ambiguity','description':'The product behavior and users are unspecified.','requirement_ids':[],'source_ids':[sid],'question':'Who are the target users, what behavior is needed and which success metrics should apply?'}]}
   docs=[{'id':sid,'name':sid,'text':text}]
   core.schema_check(value,schema); core.validate_extraction(value,docs)
   examples.append({'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps({'documents':docs},ensure_ascii=False)},{'role':'assistant','content':json.dumps(value,ensure_ascii=False)}]})
 path=DEST/(split+'.jsonl'); path.write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in examples),encoding='utf-8')
 manifest['splits'][split]={'examples':len(examples),'families':[x[0] for x in groups],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v['examples'] for k,v in manifest['splits'].items()}))
