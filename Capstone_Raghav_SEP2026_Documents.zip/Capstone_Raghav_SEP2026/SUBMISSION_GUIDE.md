# Submission guide

Author and capstone reviewer: Raghavendra Kaushik. Prepared 13 September 2026.

## Rubric mapping - 80 points total
| Assignment | Points | Evidence |
|---|---:|---|
| Q1 Ideation | 15 | Assignment Report pages 1-2 |
| Q2 Program Charter | 15 | Assignment Report pages 3-5 |
| Q3 Design | 10 | Report page 6, architecture diagram, workflow JSON |
| Q3 Core end-to-end | 12 | Approved wiki.md, stories, live screenshots and receipts |
| Q3 Extended capability | 8 | Gap Analysis, RAG context and review gate |
| Q3 Observability | 5 | Native Langflow trace screenshot and captured span details |
| Q3 Baseline tested | 5 | Twelve inputs with outputs/errors and automated checks |
| Q3 Cost/evaluation | 5 | Report page 7, generation token receipt and pricing formula |
| Q4 Reflection | 5 | Assignment Report page 8 |

These are rubric allocations, not self-awarded scores. Q3 is exactly two pages; Q4 is one page.

## Submission files
- 01_Assignments: eight-page report and editable Markdown.
- 02_Presentation: editable detailed PPTX with author name.
- 03_Demo: five-minute MP4 and narration transcript. Synthetic narration describes actual captured evidence; it is not a continuous live screen recording or a recording of Raghavendra's voice.
- 04_Implementation: Langflow/n8n exports, tested baseline export, README, source ZIP and architecture.
- 05_Baseline_Results: summary PDF, official inputs, twelve case files, raw JSON and failed attempt.
- 06_Evidence: actual canvas, PRD in action, GWT story and trace screenshots, plus validation receipts.
- 07_Knowledge_Base: eight detailed fictional product knowledge files and manifest.
- 08_Reviewed_Outputs: complete wiki.md, detailed Mermaid source, Jira CSV, story JSON/Markdown and approved-source receipt.

## Review before submitting
Raghavendra approved extracted requirements, permitting draft generation. Final PRD/deck/reflection review and the main-branch merge remain his decisions. Jira artifacts are import-ready only. The baseline has four passes and eight failures; human semantic review is pending. Direct server-side Drive/GitHub connections and actual fine-tuning remain incomplete. The source kit contains preparation and tested logic, not evidence that these external actions succeeded.

The repository is private. Give the assessor access through GitHub settings if required; no invitations have been sent. Drive uploads preserve the folder's sharing policy. Do not submit an inaccessible link without checking the assessor's access.

## Links

[GitHub feature branch](https://github.com/raghvendrakaushik-del/prd-genie-capstone/tree/Feature/Raghav_IK_Capstone_SEP2026)

[Google Drive submission folder](https://drive.google.com/drive/u/0/folders/1NOfn4t_hZHsP4QaP58lgV3a-CT4J3I_K)
