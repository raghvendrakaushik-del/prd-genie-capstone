# PRD Genie architecture

```mermaid
flowchart TD
  A[PM supplies transcript, brief and notes] --> B{Choose source path}
  B -->|Free-text baseline| C[LLM Requirement Extractor]
  C --> D[Exact quotes and typed evidence validator]
  D --> E[Gap Analyzer and evidence-ID checks]
  E --> F{Actionable evidence?}
  F -->|No| G[Return clarification questions; no draft]
  F -->|Yes| H[Draft PRD and story mapping]
  B -->|Strict reviewed catalog| I[Drive corpus or explicit snapshot]
  I --> J[BM25 context plus pinned current catalog]
  J --> K[Requirement Extractor and completeness checks]
  K --> L[Persist review ID, revision and source hash]
  L --> M[Show extracted requirements in Markdown]
  M --> N{Reviewer resolves missing facts?}
  N -->|Amend| O[Create new revision; invalidate approval]
  O --> L
  N -->|Complete| P{Exact revision approved?}
  P -->|No| M
  P -->|Yes| Q[PRD Generator: approved catalog to ten sections]
  Q --> R[Story Breakdown: epics, stories and GIVEN WHEN THEN]
  R --> S[Validate coverage and reject placeholders]
  S --> T[wiki.md, Jira CSV and provenance receipt]
  T --> U{Scoped GitHub secret configured?}
  U -->|Yes| V[Atomic version commit on feature branch]
  U -->|No| W[Return export and connection prompt]
  V --> X[Human reviews final wiki.md and merges]
  C -.-> Y[Native Langflow root and component traces]
  E -.-> Y
  Q -.-> Y
  R -.-> Y
```

The dashed links represent trace recording. Direct Drive retrieval and server-side GitHub publication require connection setup. The two source paths are explicit; automatic narrative-to-catalog normalization is not claimed.
