# PRD Genie implementation

Author: Raghavendra Kaushik. Submission date: 13 September 2026.

## Import and run
1. Start the existing local Langflow Docker instance at http://localhost:7860 and persist its database on a Docker volume.
2. Import `prd-genie.v2-reviewed.langflow.json` for the strict reviewed RelayOps demonstration. Import `prd-genie.baseline-tested.langflow.json` for the free-text baseline. They are separate paths, not a single automatically normalized pipeline.
3. Select the existing secret variable `GROQ_API_KEY` in each model-enabled component. The tested model is `openai/gpt-oss-120b`; never place keys in chat, exported JSON or Git.
4. In the strict v2 Playground, send `{"action":"extract","product_id":"relayops-pilot-v1"}`. Read the extracted packet and required questions. Answer with the exact review action format displayed by that run. Provide the actual reviewer's name.
5. Review the new revision and approve its exact review ID, revision and hash using the displayed action. Any amendment invalidates earlier approval. Generation is blocked until complete, approved evidence exists.
6. Read the generated wiki.md and GWT stories. Final document approval and merge remain Raghavendra's actions. Replaying an old receipt does not authorize another source revision.
7. For the baseline, send `{"documents":[{"id":"T2","name":"T2","text":"<the exact T2 input>"}]}` using the supplied input file. JSON output mode is preselected. T11 and T12 evaluate actual T1 outputs.

The tested baseline export includes the Gap Analyzer evidence-ID enum repair made after the first T2 failure. The original failed attempt is retained. Other platform exports are included for reference; the n8n flow is inactive and was not live-tested in this submission. n8n is not required for the demonstrated Langflow path.

## Connections and scope
The eight knowledge files are in Drive, but the live v2 run used their embedded snapshot. Direct Drive API retrieval requires server-side credentials and sharing the folder with that identity. Browser sign-in alone is insufficient. GitHub publication code uses atomic tree/commit updates and non-force branch updates; configure a scoped repository secret to enable automatic commits. No live server-side publication is claimed. The browser-based repository upload is a separate completed action.

The kit includes 48 synthetic training, 16 validation and 16 domain-family-separated holdout examples, job scripts and a base-versus-tuned comparison utility. Label review and a supported training connection are required. No training job, fine-tuned model or measured training improvement exists yet. Prompt refinement is not model fine-tuning.

## Verification
The v2 review/export software suite passed 22 tests. The complete reviewed output has ten template sections, eight functional requirements, four NFRs, sixteen GWT scenarios and eight stories under three epics. The official free-text baseline has 4 automated passes and 8 failures (including 2 execution errors); all 12 supplied inputs and recorded outputs are included. A pass is not a semantic human sign-off. The product is a capstone prototype, with quality and connection work required before broader rollout.

## Repository
https://github.com/raghvendrakaushik-del/prd-genie-capstone/tree/Feature/Raghav_IK_Capstone_SEP2026

Complete implementation source is packaged in PRD-Genie-Build-Kit.zip. The private repository requires assessor access. Its feature branch is not merged into main.
